window.g = {
  VITE_API_BASE_URL: "https://api-shuadan.pigk.xyz/api",
  VITE_API_IMG_URL: "https://api-shuadan.pigk.xyz",
  VITE_TITLE: "algofy",
  VITE_PC_MAX_WIDTH: "375px",
};
