<template>
    <section class="algofy-home">
        <div class="algofy-top-promo">
            ⚡ Free Growth Plan ($5K Value) - Apply Here
        </div>

        <header class="algofy-header">
            <div class="algofy-brand-mark" aria-label="Algofy placeholder logo">
                <img src="@/static/images/logo.svg" />
            </div>
            <!-- <button class="algofy-book" type="button">Book a Call</button>
            <button class="algofy-menu" type="button" aria-label="Menu">
                <span></span><span></span><span></span>
            </button> -->
        </header>

        <section class="algofy-hero">
            <div class="orbit orbit-one"></div>
            <div class="orbit orbit-two"></div>
            <div
                v-for="brand in heroBrands"
                :key="brand.name"
                class="floating-brand"
                :class="brand.className"
            >
                <span v-if="brand.icon" class="floating-brand__icon">{{
                    brand.icon
                }}</span>
                <span class="floating-brand__name">{{ brand.name }}</span>
            </div>
            <p class="eyebrow">
                Amazon &amp; DTC Growth That’s Fast, Strategic<br />&amp;
                Performance-Driven
            </p>
            <h1>
                Scaling Brands with
                <span>360°<br />Services &amp; Advanced AI</span>
            </h1>
            <button class="hero-cta" type="button">Let’s Talk</button>
        </section>

        <section class="algofy-trusted">
            <p>Trusted by 300+ Brands Over 6 Years</p>
            <div class="trusted-track">
                <div
                    v-for="logo in trustedLogos"
                    :key="logo"
                    class="trusted-logo"
                >
                    {{ logo }}
                </div>
            </div>
        </section>

        <section class="algofy-function-zone">
            <slot name="reward"></slot>
        </section>

        <section class="success-section">
            <div class="case-card">
                <div class="case-logo">PUFFIN<br /><span>drinkwear</span></div>
                <div class="case-author">
                    <div class="case-avatar"></div>
                    <p>
                        <strong>Rick Lee</strong> - Director of Digital,<br />Puffin
                        Drinkwear
                    </p>
                </div>
                <blockquote>
                    “Algofy has been
                    <strong
                        >an incredible extension of our marketing team.</strong
                    >
                    Their
                    <strong
                        >flexibility and ability to plug in wherever we need
                        support</strong
                    >
                    make them indispensable.”
                </blockquote>
                <div class="case-stats">
                    <p><strong>+441%</strong> TRAFFIC</p>
                    <p><strong>+382%</strong> REVENUE</p>
                    <p><strong>+226%</strong> TRANSACTIONS</p>
                </div>
                <button class="case-arrow case-arrow--left" type="button">
                    ←
                </button>
                <button class="case-arrow case-arrow--right" type="button">
                    →
                </button>
            </div>
            <button class="blue-button" type="button">
                View Success Stories
            </button>
            <div class="mini-logo-row">
                <span>CLUTCH</span><span>Google</span><span>Klaviyo</span>
            </div>
        </section>

        <section class="clients-section">
            <h2>Unified Growth Across<br />Amazon + DTC</h2>
            <p>
                We combine media buying, marketplace operations, creative
                strategy, CRO and analytics into one accountable growth team.
            </p>
            <div class="client-grid">
                <article v-for="item in growthCards" :key="item.title">
                    <div class="client-thumb">{{ item.initial }}</div>
                    <h3>{{ item.title }}</h3>
                    <p>{{ item.copy }}</p>
                </article>
            </div>
        </section>

        <section class="formula-section">
            <p class="label">OUR ADVANTAGE</p>
            <h2>The Formula Behind It</h2>
            <p>
                Every placeholder block can be replaced with your final video
                images, client screenshots or brand assets later.
            </p>
            <div class="formula-card">
                <div class="formula-media"></div>
                <h3>Better Strategy,<br />Smarter Execution.</h3>
                <ul>
                    <li>Marketplace + Shopify growth planning</li>
                    <li>Creative testing and ad optimization</li>
                    <li>Reporting, automation and AI insights</li>
                </ul>
                <button class="blue-button" type="button">
                    Watch Our Full Strategy
                </button>
            </div>
        </section>

        <section class="specialists-section">
            <h2>One Specialized Team, Every Channel.</h2>
            <div class="specialist-icons">
                <div v-for="item in channelItems" :key="item.label">
                    <span>{{ item.icon }}</span>
                    <p>{{ item.label }}</p>
                </div>
            </div>
            <button class="blue-button" type="button">See Our Services</button>
        </section>

        <section class="performance-section">
            <h2>Ready to performance market?</h2>
            <p>
                Use this area for the original site’s final CTA, brand proof and
                footer content.
            </p>
            <button class="hero-cta" type="button">Let’s Talk</button>
        </section>
    </section>
</template>

<script setup>
const heroBrands = [
    { name: "Amazon", icon: "◎", className: "brand-amazon" },
    { name: "ALGOFY", className: "brand-algofy" },
    { name: "PIXIS", className: "brand-pixis" },
    { name: "CIR", icon: "↻", className: "brand-cir" },
    { name: "CIA", icon: "△", className: "brand-cia" },
    { name: "Motion", icon: "▮", className: "brand-motion" },
];
const trustedLogos = ["ADDAX", "FARM", "MED", "HERO", "SKYE"];
const growthCards = [
    {
        initial: "DTC",
        title: "Shopify Growth",
        copy: "Landing pages, email flows and conversion optimization.",
    },
    {
        initial: "ADS",
        title: "Paid Media",
        copy: "Meta, Google, Amazon and TikTok campaigns.",
    },
    {
        initial: "AI",
        title: "Advanced AI",
        copy: "Smarter analysis, faster iteration and clearer reports.",
    },
];
const channelItems = [
    { icon: "◉", label: "Amazon" },
    { icon: "G", label: "Google" },
    { icon: "✦", label: "Meta" },
    { icon: "⌁", label: "Klaviyo" },
];
</script>

<style scoped>
.algofy-home {
    --algofy-blue: #2450f4;
    --algofy-ink: #11182c;
    --algofy-soft: #eef2ff;
    min-height: 100vh;
    overflow: hidden;
    background: #f4f7ff;
    color: var(--algofy-ink);
    font-family: Inter, Arial, Helvetica, sans-serif;
}
.algofy-top-promo {
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--algofy-blue);
    color: #fff;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: -0.01em;
}
.algofy-header {
    position: sticky;
    top: 0;
    z-index: 20;
    height: 58px;
    display: grid;
    grid-template-columns: 52px 1fr 52px;
    align-items: center;
    padding: 0 16px;
    background: #b9c6ff;
    backdrop-filter: blur(14px);
}
.algofy-brand-mark {
    width: 42px;
    height: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 900;
    font-size: 19px;
    line-height: 1;
}
.algofy-book {
    justify-self: center;
    min-width: 126px;
    height: 45px;
    border: 0;
    border-radius: 0 0 8px 8px;
    background: var(--algofy-blue);
    color: #fff;
    font-size: 17px;
    font-weight: 900;
    box-shadow: 0 8px 16px rgba(36, 80, 244, 0.24);
}
.algofy-menu {
    justify-self: end;
    width: 34px;
    height: 34px;
    border: 0;
    background: transparent;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 5px;
    padding: 0;
}
.algofy-menu span {
    display: block;
    width: 23px;
    height: 2px;
    border-radius: 99px;
    background: var(--algofy-ink);
}
.algofy-hero {
    position: relative;
    min-height: 398px;
    padding: 125px 22px 52px;
    text-align: center;
    background: url("@/static/images/head.png") no-repeat;

    background-position:
        0 0,
        50%,
        50%;
    background-repeat: repeat, no-repeat, no-repeat;
    background-size: auto, cover, cover;
}
.orbit {
    position: absolute;
    left: 50%;
    top: 50%;
    border: 7px solid rgba(255, 255, 255, 0.46);
    border-radius: 50%;
    transform: translate(-50%, -50%);
    pointer-events: none;
}
.orbit-one {
    width: 340px;
    height: 340px;
}
.orbit-two {
    width: 470px;
    height: 470px;
    border-width: 3px;
    opacity: 0.62;
}
.eyebrow {
    position: relative;
    z-index: 2;
    margin: 0 0 14px;
    color: #17213b;
    font-size: 15px;
    font-weight: 900;
    line-height: 1.25;
    letter-spacing: -0.025em;
}
.algofy-hero h1 {
    position: relative;
    z-index: 2;
    margin: 0 auto;
    max-width: 335px;
    color: #111827;
    font-size: 32px;
    font-weight: 950;
    line-height: 1.17;
    letter-spacing: -0.055em;
}
.algofy-hero h1 span {
    color: var(--algofy-blue);
}
.hero-cta,
.blue-button {
    position: relative;
    z-index: 2;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 214px;
    height: 62px;
    margin-top: 32px;
    border: 0;
    border-radius: 10px;
    background: var(--algofy-blue);
    color: #fff;
    font-size: 17px;
    font-weight: 900;
    box-shadow: 0 12px 24px rgba(36, 80, 244, 0.22);
}
.floating-brand {
    position: absolute;
    z-index: 3;
    display: flex;
    min-width: 47px;
    min-height: 38px;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 2px;
    border: 1px solid rgba(199, 205, 225, 0.85);
    border-radius: 7px;
    background: rgba(255, 255, 255, 0.88);
    color: #1f2937;
    font-size: 9px;
    font-weight: 900;
    box-shadow: 0 5px 14px rgba(32, 50, 98, 0.16);
}
.floating-brand__icon {
    color: #ff4a3d;
    font-size: 15px;
    line-height: 1;
}
.brand-amazon {
    top: 78px;
    left: 44px;
}
.brand-algofy {
    top: 24px;
    left: 50%;
    width: 56px;
    height: 48px;
    transform: translateX(-50%);
}
.brand-pixis {
    top: 74px;
    right: 42px;
}
.brand-cir {
    bottom: 56px;
    left: 31px;
}
.brand-cia {
    bottom: 50px;
    right: 35px;
}
.brand-motion {
    bottom: 12px;
    left: 50%;
    width: 56px;
    height: 48px;
    transform: translateX(-50%);
}
.algofy-trusted {
    background: #fff;
    padding: 16px 0 12px;
    text-align: center;
}
.algofy-trusted p {
    margin: 0 0 12px;
    color: #101827;
    font-size: 10px;
    font-weight: 900;
}
.trusted-track {
    display: flex;
    gap: 12px;
    overflow: hidden;
    padding: 0 14px;
}
.trusted-logo {
    flex: 0 0 78px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 7px;
    background: #f6f7fb;
    color: #1c2338;
    font-size: 12px;
    font-weight: 900;
}
.algofy-function-zone {
    background: #fff;
    padding: 22px 14px 26px;
}
.success-section {
    position: relative;
    background: linear-gradient(180deg, #f9fbff 0%, #fff 100%);
    padding: 26px 15px 28px;
    text-align: center;
}
.case-card {
    position: relative;
    min-height: 468px;
    border: 1px solid #d5dae7;
    border-radius: 14px;
    background: rgba(255, 255, 255, 0.92);
    padding: 44px 18px 28px;
    text-align: left;
    box-shadow: 0 8px 28px rgba(22, 35, 75, 0.08);
}
.case-logo {
    margin-bottom: 24px;
    color: #b7bac2;
    font-size: 31px;
    font-weight: 950;
    line-height: 0.72;
    text-align: center;
    letter-spacing: -0.05em;
}
.case-logo span {
    font-size: 15px;
    letter-spacing: -0.02em;
}
.case-author {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 24px;
}
.case-avatar {
    width: 54px;
    height: 54px;
    flex: 0 0 54px;
    border-radius: 50%;
    background: linear-gradient(135deg, #97b5da, #222f42 65%, #efefef);
}
.case-author p {
    margin: 0;
    font-size: 16px;
    line-height: 1.35;
}
.case-card blockquote {
    margin: 0;
    color: #252b3a;
    font-size: 19px;
    line-height: 1.35;
    letter-spacing: -0.02em;
}
.case-stats {
    margin-top: 24px;
}
.case-stats p {
    margin: 0 0 16px;
    color: #727884;
    font-size: 16px;
    font-weight: 800;
}
.case-stats strong {
    color: var(--algofy-blue);
    font-size: 32px;
    font-weight: 950;
    letter-spacing: -0.05em;
}
.case-arrow {
    position: absolute;
    top: 50%;
    width: 40px;
    height: 40px;
    border: 1px solid #121827;
    border-radius: 50%;
    background: #fff;
    color: #1c2337;
    font-size: 24px;
    transform: translateY(-50%);
}
.case-arrow--left {
    left: -20px;
}
.case-arrow--right {
    right: -20px;
}
.success-section .blue-button {
    min-width: 214px;
    height: 50px;
    margin-top: 18px;
    font-size: 13px;
    border-radius: 7px;
}
.mini-logo-row {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 14px;
    margin-top: 18px;
}
.mini-logo-row span {
    height: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 1px solid #e1e5ef;
    border-radius: 5px;
    background: #fff;
    color: #6d7483;
    font-size: 10px;
    font-weight: 900;
}
.clients-section,
.formula-section,
.specialists-section,
.performance-section {
    background: #fff;
    padding: 40px 18px;
    text-align: center;
}
.clients-section h2,
.formula-section h2,
.specialists-section h2,
.performance-section h2 {
    margin: 0 0 14px;
    color: #17213b;
    font-size: 28px;
    font-weight: 950;
    line-height: 1.08;
    letter-spacing: -0.05em;
}
.clients-section > p,
.formula-section > p,
.performance-section > p {
    margin: 0 auto 22px;
    color: #5d6676;
    font-size: 14px;
    line-height: 1.55;
}
.client-grid {
    display: grid;
    gap: 16px;
}
.client-grid article,
.formula-card {
    border: 1px solid #e2e7f3;
    border-radius: 13px;
    background: #f8faff;
    padding: 18px;
    text-align: left;
}
.client-thumb,
.formula-media {
    height: 132px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    background: linear-gradient(135deg, #e5ebff, #ffffff);
    color: var(--algofy-blue);
    font-size: 28px;
    font-weight: 950;
}
.client-grid h3,
.formula-card h3 {
    margin: 14px 0 6px;
    font-size: 18px;
    font-weight: 950;
}
.client-grid p,
.formula-card li {
    color: #667085;
    font-size: 14px;
    line-height: 1.5;
}
.formula-section {
    background: #edf3ff;
}
.formula-section .label {
    margin-bottom: 8px;
    color: var(--algofy-blue);
    font-weight: 950;
    font-size: 11px;
    letter-spacing: 0.14em;
}
.formula-card ul {
    margin: 14px 0 0;
    padding-left: 19px;
}
.formula-card .blue-button {
    width: 100%;
    min-width: 0;
    height: 52px;
    margin-top: 18px;
    font-size: 13px;
}
.specialists-section {
    background: #fff;
}
.specialist-icons {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    margin-top: 22px;
}
.specialist-icons div {
    min-width: 0;
}
.specialist-icons span {
    width: 52px;
    height: 52px;
    margin: 0 auto 7px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: #edf2ff;
    color: var(--algofy-blue);
    font-weight: 950;
}
.specialist-icons p {
    margin: 0;
    font-size: 11px;
    font-weight: 800;
    color: #293247;
}
.specialists-section .blue-button {
    height: 52px;
    min-width: 230px;
    font-size: 13px;
}
.performance-section {
    padding-bottom: 92px;
    background: #121826;
    color: #fff;
}
.performance-section h2 {
    color: #fff;
}
.performance-section p {
    color: rgba(255, 255, 255, 0.7);
}
@media (max-width: 360px) {
    .algofy-hero h1 {
        font-size: 29px;
    }
    .eyebrow {
        font-size: 13px;
    }
    .floating-brand {
        transform: scale(0.9);
    }
    .brand-algofy,
    .brand-motion {
        transform: translateX(-50%) scale(0.9);
    }
}
</style>
