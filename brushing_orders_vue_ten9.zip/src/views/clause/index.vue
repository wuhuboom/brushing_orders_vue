<template>
  <div class="terms-page">
    <PageTopBar title="TERMS &amp; CONDITIONS" show-back @click-left="onClickLeft" />

    <main class="terms-content">
      <p>1) To Optimize And Reset Your Account, You Must First Complete All Ratings With A Minimum Amount Of 50Usd And A Minimum Account Reset Amount Of 100Usd.</p>
      <p>1.1) Users Who Have Completed A Set Of Mission Should Contact Customer Service To Request A Reset For The Next Set Of Tasks</p>
      <p>2) User Withdrawals And System Withdrawal Requirements / Security Of User Funds</p>
      <p>2.1) Each User Needs To Complete All The Optimization Mission Before They Can Meet The System Withdrawal Requirements</p>
      <p>2.2) In Order To Avoid Any Loss Of Funds, All Withdrawals Are Processed Automatically By The System And Not Manually</p>
      <p>2.3) All Users Are Not Allowed To Apply For Withdrawal In The Middle Of Mission To Avoid Affecting The Merchant's Operation</p>
      <p>2.4) Users' Funds Are Completely Safe On The Platform And The Platform Will Be Liable For Any Accidental Loss</p>
      <p>3) Please Do Not Disclose Your Account Password And Withdrawal Password To Others. The Platform Will Not Be Held Responsible For Any Loss Or Damage Caused</p>
      <p>3.1) All Users Are Advised To Keep Their Accounts Secure To Avoid Disclosure</p>
      <p>3.2) The Platform Is Not Responsible For Any Accidental Disclosure Of Accounts</p>
    </main>
  </div>
</template>

<script setup>
import PageTopBar from "@/components/PageTopBar.vue";
const onClickLeft = () => {
  history.back();
};
</script>

<style scoped>
.terms-page {
  min-height: 100vh;
  background: #eef2f8;
  color: #050505;
  font-family: inherit;
}

.design-topbar {
  position: sticky;
  top: 0;
  z-index: 30;
  height: 52px;
  display: grid;
  grid-template-columns: 56px 1fr 56px;
  align-items: center;
  background: #030303;
  color: #fff;
}

.design-title {
  text-align: center;
  font-size: 17px;
  line-height: 22px;
  font-weight: 800;
  letter-spacing: 0.01em;
  text-transform: uppercase;
}

.design-back {
  width: 52px;
  height: 52px;
  border: 0;
  background: transparent;
  position: relative;
}

.design-back::before {
  content: '';
  position: absolute;
  left: 19px;
  top: 18px;
  width: 13px;
  height: 13px;
  border-left: 3px solid #fff;
  border-bottom: 3px solid #fff;
  transform: rotate(45deg);
  border-radius: 1px;
}

.terms-content {
  padding: 20px 20px 30px;
}

.terms-content p {
  margin: 0 0 30px;
  font-size: 15px;
  line-height: 1.27;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.terms-content p:nth-child(1) { margin-bottom: 24px; }
.terms-content p:nth-child(2) { margin-bottom: 52px; }
.terms-content p:nth-child(3) { margin-bottom: 34px; }
.terms-content p:nth-child(4) { margin-bottom: 34px; }
.terms-content p:nth-child(5) { margin-bottom: 34px; }
.terms-content p:nth-child(6) { margin-bottom: 34px; }
.terms-content p:nth-child(7) { margin-bottom: 34px; }
.terms-content p:nth-child(8) { margin-bottom: 34px; }
.terms-content p:nth-child(9) { margin-bottom: 34px; }
</style>
