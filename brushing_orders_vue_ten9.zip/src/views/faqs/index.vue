<template>
  <div class="faqs-design-page">
    <PageTopBar title="FAQS" show-back @click-left="onClickLeft" />

    <main class="faqs-content">
      <h2>Start Product Optimization Missions</h2>
      <p>1.1) Minimum Account Balance Of 50Usd For The First 40 Missions/Set</p>
      <p>1.2) A Minimum Renewal Of 100Usd Is Required To Start The New Missions</p>
      <p>1.3) Users Need To Complete The Missions Before They Can Request A Withdrawal</p>

      <h2>Withdrawal</h2>
      <p>2.1) Users Need To Complete The Missions Before They Can Request A Withdrawal</p>
      <p>2.2) You Cannot Request A Withdrawal Or Refund If You Choose To Give Up Or Withdraw In The Middle Of A Missions Optimization.</p>
      <p>2.3) No Withdrawals Can Be Processed If The User's Withdrawal Request Has Not Been Received.</p>
      <p>2.4) The Maximum Withdrawal Amount For Vip1 Users Is 10000Usd , For Vip2 Users It Is 30000Usd. No Maximum Withdrawal Limit For Vip3 And Above</p>
      <p>2.5) The User Account Has Insufficient Credit Score And Can't Use All Functions Of The Platform Normally.</p>

      <h2>Funds</h2>
      <p>3.1) All Funds Will Be Held Securely In The User's Account And Can Be Requested In Full Once All Data Has Been Completed</p>
      <p>3.2) To Avoid Any Loss Of Funds, All Data Will Be Processed By The System And Not</p>
    </main>
  </div>
</template>

<script setup>
import PageTopBar from "@/components/PageTopBar.vue";
const onClickLeft = () => {
  history.back();
};
</script>

<style scoped>
.faqs-design-page {
  min-height: 100vh;
  background: #eef2f8;
  color: #050505;
  font-family: inherit;
}

.design-topbar {
  position: sticky;
  top: 0;
  z-index: 30;
  height: 52px;
  display: grid;
  grid-template-columns: 56px 1fr 56px;
  align-items: center;
  background: #030303;
  color: #fff;
}

.design-title {
  text-align: center;
  font-size: 17px;
  line-height: 22px;
  font-weight: 800;
  letter-spacing: 0.01em;
  text-transform: uppercase;
}

.design-back {
  width: 52px;
  height: 52px;
  border: 0;
  background: transparent;
  position: relative;
}

.design-back::before {
  content: '';
  position: absolute;
  left: 19px;
  top: 18px;
  width: 13px;
  height: 13px;
  border-left: 3px solid #fff;
  border-bottom: 3px solid #fff;
  transform: rotate(45deg);
  border-radius: 1px;
}

.faqs-content {
  padding: 27px 19px 30px;
}

.faqs-content h2 {
  margin: 0 0 26px;
  font-size: 16px;
  line-height: 22px;
  font-weight: 800;
}

.faqs-content p {
  margin: 0 0 33px;
  font-size: 14px;
  line-height: 1.3;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.faqs-content p:nth-of-type(3) { margin-bottom: 52px; }
.faqs-content p:nth-of-type(8) { margin-bottom: 54px; }
</style>
