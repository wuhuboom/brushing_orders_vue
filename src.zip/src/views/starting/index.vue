<template>
  <div class="w-full min-h-[100vh] bg-[#f4f4f5]">
    <HeaderTop></HeaderTop>
    <div class="flex w-[90%] mx-auto justify-between my-2 items-center">
      <div class="flex">
        <div>
          <!-- 接口还没返回 avatar 字段（请求中） -->
          <div
            v-if="userInfo.avatar === undefined"
            class="w-[35px] h-[35px] rounded-full ml-[5px] bg-gray-200 animate-pulse"
          ></div>

          <!-- 接口返回 null / 空字符串 → 直接显示默认头像（不会闪） -->
          <img
            v-else-if="!userInfo.avatar"
            :src="userImg"
            class="w-[35px] h-[35px] rounded-full ml-[5px] object-cover"
            alt=""
          />

          <!-- 接口返回头像 URL → 直接渲染用户头像；加载失败再回退到默认头像 -->
          <img
            v-else
            :src="userInfo.avatar"
            class="w-[35px] h-[35px] rounded-full ml-[5px] object-cover"
            alt=""
            @error="(e) => (e.target.src = userImg)"
          />
        </div>
        <div class="flex items-center ml-[15px]">
          <div class="text-black font-semibold">
            Hi, {{ userInfo.username }}
          </div>
        </div>
      </div>
      <div class="text-black font-semibold">{{ userLevel }}</div>
    </div>
    <div class="w-full grid grid-cols-2 rounded-xl gap-4 p-2 bg-white border-[3px] border-[#f1894c] shadow-sm">
      <div class="col-span-2 pb-2 border-b-[1px] border-dashed border-[#888] flex flex-col text-center">
        <img src="@/static/images/icon-25.png" class="w-10 h-10 mx-auto" alt="">
        <div class="text-sm mt-4 text-[#00bea3]">{{ $t("当日佣金") }}</div>
        <div class="text-xl font-semibold text-black my-1">{{ userInfo.commission }} USD</div>
        <div class="text-sm text-[#black]">{{ $t("每日赚取佣金") }}</div>
      </div>
      <div class="col-span-1 flex flex-col text-cente px-3 rounded-xl">
        <div class="w-full">
          <img src="@/static/images/icon-26.png" class="w-10 h-10 mx-auto" alt="">
          <div class="w-full text-base text-center font-bold mt-1 text-[#000]">{{ $t("钱包余额") }}</div>
          <div class="text-base text-center font-semibold text-black my-1">{{ userInfo.balance }} USD</div>
          <div class="text-sm text-[#000] text-center"> {{ $t("佣金将在此处添加") }}</div>
        </div>

      </div>
      <div class="col-span-1 flex flex-col text-cente px-3 rounded-xl">
        <div class="w-full">
          <img src="@/static/images/icon-27.png" class="w-10 h-10 mx-auto" alt="">
          <div class="w-full text-base text-center font-bold mt-1 text-[#000]">{{ $t("持有金额") }}</div>
          <div class="text-base text-center font-semibold text-black my-1">{{ userInfo.frozenBalance }} USD</div>
          <div class="text-sm text-[#000] text-center">{{ $t("如有疑问，请联系客服") }}</div>
        </div>

      </div>

    </div>

    <!-- <div class="w-full px-5 mx-auto bg-[#206645] rounded-b-[20px]">
      <div class="w-full pt-6 flex justify-between">
        <div class="text-[#fff]">webworks</div>
        <img
          src="@/static/images/user3.png"
          class="w-[24px]"
          alt=""
          @click="toMy"
        />
      </div>
      <div class="w-full h-full py-5">
        <div class="flex justify-between mt-4 mb-4 items-center">
          <div class="flex">
            <div class="flex items-center pl-2">
              <div class="text-[#fff]">
                <div class="text-xl">Hi, {{ userInfo.username }}</div>
                <div
                  class="text-[rgba(255,255,255,0.8)] text-sm text-inherits pt-2"
                >
                  Welcome back
                </div>
              </div>
            </div>
          </div>
          <div
            class="text-[#fff] w-[62px] h-[36px] flex justify-center items-center bg-[rgba(255,255,255,0.2)] rounded-[20px]"
          >
            VIP{{ userInfo.levelId }}
          </div>
        </div>
      </div>
    </div> -->

    <div class="w-full bg-[#f8f8f8] relative pt-[15px]">
      <div class="w-[100%] px-4 mx-auto">
        <!-- <div class="grid grid-cols-1 gap-3">
          <div
            class="w-full col-span-1 flex p-3 box-border rounded-xl bg-[#fff] border-[1px] border-[#EDEDEE]"
          >
            <div class="w-full flex justify-between">
              <div class="flex items-center">
                <img
                  class="w-10 h-10 mr-3"
                  src="@/static/images/icon-21.png"
                  alt=""
                />
                <div class="flex flex-col justify-around">
                  <div class="text-[#000] text-sm mb-1">
                    {{ $t("钱包余额") }}
                  </div>
                  <div class="text-[#999] text-[10px]">
                    {{ $t("佣金将在此处添加") }}
                  </div>
                </div>
              </div>
              <div class="flex flex-col justify-end text-right">
                <div class="text-sm text-[#000] font-bold mb-1">
                  {{ userInfo.balance }}
                </div>
                <div class="text-[#999] text-xs">USD</div>
              </div>
            </div>
          </div>
          <div
            class="w-full col-span-1 flex p-3 box-border rounded-xl bg-[#fff] border-[1px] border-[#EDEDEE]"
          >
            <div class="w-full flex justify-between">
              <div class="flex items-center">
                <img
                  class="w-10 h-10 mr-3"
                  src="@/static/images/icon-22.png"
                  alt=""
                />
                <div class="flex flex-col justify-around">
                  <div class="text-[#000] text-sm mb-1">
                    {{ $t("持有金额") }}
                  </div>
                  <div class="text-[#999] text-[10px]">
                    {{ $t("如有疑问，请联系客服") }}
                  </div>
                </div>
              </div>
              <div class="flex flex-col justify-end text-right">
                <div class="text-sm text-[#000] font-bold mb-1">
                  {{ userInfo.frozenBalance }}
                </div>
                <div class="text-[#999] text-xs">USD</div>
              </div>
            </div>
          </div>
          <div
            class="w-full col-span-1 flex p-3 box-border rounded-xl bg-[#fff] border-[1px] border-[#EDEDEE]"
          >
            <div class="w-full flex justify-between">
              <div class="flex items-center">
                <img
                  class="w-10 h-10 mr-3"
                  src="@/static/images/icon-20.png"
                  alt=""
                />
                <div class="flex flex-col justify-around">
                  <div class="text-[#000] text-sm mb-1">
                    {{ $t("当日佣金") }}
                  </div>
                  <div class="text-[#999] text-[10px]">
                    {{ $t("每日赚取佣金") }}
                  </div>
                </div>
              </div>
              <div class="flex flex-col justify-end text-right">
                <div class="text-sm text-[#000] font-bold mb-1">
                  {{ userInfo.commission }}
                </div>
                <div class="text-[#999] text-xs">USD</div>
              </div>
            </div>
          </div>
        </div> -->
        <div class="flex justify-between text-black font-bold text-base">
          <div>{{$t('start.optimization.str')}}</div>
          <div>
            <span class="text-[var(--main-color)]">{{
              userInfo.dealCount
            }}</span
            >/<span>{{ orderCount }}</span>
          </div>
        </div>
        <div class="mt-5 flex flex-col p-4 box-border bg-[#f1f1f1] rounded-xl">
          <div class="mt-5 flex flex-col box-border bg-[#f1f1f1] rounded-xl">
            <div class="w-full grid grid-cols-3 gap-6">
              <template v-for="(item, index) in totalCount" :key="index">
                <div
                  v-if="index === 4"
                  class="grid-span-1 text-center text-xs font-normal"
                  @click="handleClick"
                >
                  <div
                    class="flex items-center justify-center overflow-hidden rounded-xl bg-cover text-lg text-white font-medium relative"
                  >
                    <div class="overflow-hidden">
                      <img
                        src="@/static/images/start-button.png"
                        class="w-[100%] shadow"
                        alt=""
                      />
                      <div class="absolute"></div>
                    </div>
                  </div>
                </div>
                <div
                v-else
                  class="grid-span-1 text-[#666666] text-center text-xs font-normal"
                >
                  <div
                    class="p-2 overflow-hidden"
                    style="
                      background-image: radial-gradient(
                        circle at 100% 0%,
                        rgb(247, 247, 247) 0%,
                        rgb(252, 252, 252) 106%
                      );
                      border-radius: 8px;
                    "
                  >
                    <div class="overflow-hidden">
                      <!-- <img
                        :src="`${url}${getImageByIndex(index)}`"
                        class="w-[100px] h-[100px] lg:w-[296px] lg:h-[296px]"
                        alt=""
                      /> -->
                      <van-image
                        fit="contain"
                        :src="`${url}${getImageByIndex(index)}`"
                      />
                    </div>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </div>

        <!-- <div
          class="mt-5 flex justify-center items-center text-black text-base h-[60px] bg-[#FACC15] rounded-[20px]"
          @click="handleClick"
        >
          Start
          <span class="pl-2">({{ userInfo.dealCount }}</span
          >/<span>{{ orderCount }})</span>
        </div> -->
      </div>
      <div class="w-[90%] mx-auto pt-5">
        <div class="mt-4 rounded-lg  bg-[#1f2732]">
          <div class="flex flex-col p-4 box-border relative rounded-[10px]">
            <div class="mb-1 text-base text-[#fff]">{{$t('start.notice.str')}}</div>
            <div class="text-[#fff] text-[12px]">
              {{$t('start.notice.desc1.str')}} {{ TradeInfor?.workTimeStart || "--:--" }} -
              {{ TradeInfor?.workTimeEnd || "--:--" }} <br />
             {{$t('start.notice.desc2.str')}}
            </div>
          </div>
        </div>
      </div>
      <div class="mt-6 pb-4"></div>
    </div>
    <Footer name="/starting"></Footer>
    <van-popup
      v-model:show="showCenter"
      round
      closeable
      :style="{ width: '80%' }"
    >
      <div class="w-[5rem] mx-auto mt-6">
        <van-image
          width="6rem"
          height="6rem"
          fit="contain"
          :src="url + goods.coverUrl"
        />
      </div>
      <div class="w-full mt-[-3rem] pt-[4rem] text-[#000] p-4 rounded-lg">
        <div class="w-[100%] mx-auto text-center text-sm font-semibold">
          {{ goods.goodsName }}
        </div>
        <div class="flex w-full items-center pt-4 pb-4 mt-4">
          <div
            class="w-[50%] mr-2 flex flex-col py-4 bg-[#d8d8d8] justify-center items-center"
          >
            <div class="text-[#000] font-semibold">{{ $t("价格") }}</div>
            <div class="text-xs text-[#000] mt-1">
              <span class="text-sm mr-1 text-[#000] font-semibold">{{
                goods.price
              }}</span>
              USD
            </div>
          </div>
          <div
            class="w-[50%] mr-2 flex flex-col py-4 bg-[#d8d8d8] justify-center items-center"
          >
            <div class="text-[#000] font-semibold">{{ $t("佣金") }}</div>
            <div class="text-xs text-[#000] mt-1">
              <span class="text-sm mr-1 text-[#000] font-semibold">{{
                goods.commission
              }}</span>
              USD
            </div>
          </div>
        </div>
        <div class="bg-[#d8d8d8] p-4">
          <div class="flex justify-between items-center box-border">
            <div class="text-[#000] text-sm">{{ $t("创建时间") }}</div>
            <div class="text-[#000] text-sm font-bold">
              {{
                formatWithTimezone(
                  goods.createTime,
                  userStore.zoneActive.tzName
                )
              }}
            </div>
          </div>
          <div class="flex justify-between items-center box-border mt-2">
            <div class="whitespace-nowrap text-[#000] text-sm">
              {{ $t("编号") }}
            </div>
            <div class="text-[#000] text-xs font-bold">
              {{ goods.orderNo }}
            </div>
          </div>
        </div>
        <div class="w-full mt-4">
          <van-button color="#007513" class="w-full" @click="submitForm">{{
            $t("提交")
          }}</van-button>
        </div>
      </div>
    </van-popup>
    <van-popup
      v-model:show="showImg"
      round
      :style="{ width: '80%', background: 'transparent' }"
    >
      <img
        @click="closeImg"
        class="w-[100%] mb-5"
        src="../../static/images/super.png"
        alt=""
      />
      <van-button color="#ff497c" round class="w-full" @click="closeImg">OK</van-button>
      <!-- <img
        @click="closeImg"
        class="w-[30px] h-[30px] m-auto"
        src="../../static/images/cloed.png"
        alt=""
      /> -->
    </van-popup>
  </div>
</template>
<script setup>
import { onMounted, ref, onUnmounted } from "vue";
import HeaderTop from "@/components/HeaderTop.vue";
import Footer from "@/components/Footer.vue";
import {
  showLoadingToast,
  closeToast,
  showFailToast,
  showSuccessToast,
  showToast,
} from "vant";
import { useI18n } from "vue-i18n";
import {
  userGetInfo,
  getGoodsList,
  createOrder,
  submitOrder,
  getTradeConfig,
} from "../../api/apis";
const url = window.g.VITE_API_IMG_URL;
const userStore = useUserStore();
import { formatWithTimezone } from "../../util/utils";
import { useUserStore } from "@/store/modules/user";
import { useRouter } from "vue-router";
import { errorMessages } from "../../api/errorCodeMap";
const userImg = new URL("@/static/images/userImg.png", import.meta.url).href;
const router = useRouter();
const { t } = useI18n();
const userInfo = ref({});
const avatarUrl = ref("");

let timer = null;
const goodsList = ref([]);
const showCenter = ref(false);
const showImg = ref(false);
const goods = ref({});
const totalCount = ref(0); // 插入一个“开始按钮”
const getList = async () => {
  // let res = await getGoodsList();
  // goodsList.value = res.data;
  try {
    const res = await getGoodsList();
    goodsList.value = res.data;
    totalCount.value = goodsList.value.length + 1; // 插入一个“开始按钮”
  } catch (e) {
    console.error("获取商品列表失败:", e);
  } finally {
    // 每次请求完成后再等 10 秒再发下一次，避免堆积
    timer = setTimeout(getList, 10000);
  }
};

const getImageByIndex = (i) => {
  if (i === 4) return null; // 第 5 项是“开始按钮”，不用图
  const realIndex = i < 5 ? i : i - 1;
  console.log(goodsList.value[realIndex]?.coverUrl);
  return goodsList.value[realIndex]?.coverUrl || "";
};

// 抢单
const handleClick = () => {
  if (
    userInfo.value.cardNumber == userInfo.value.dealCount &&
    userInfo.value.dealCount != 0
  ) {
    showImg.value = true;
    // 2. 延时 2 秒后关闭图片，并继续创建订单
    // setTimeout(() => {
    //   showImg.value = false;
    //   doCreateOrder();
    // }, 2000);

    return;
  }
  // 不满足条件时，直接创建订单
  doCreateOrder();
};

const closeImg = () => {
  showImg.value = false;
};

const doCreateOrder = () => {
  showLoadingToast({
    message: t("创建中..."),
    forbidClick: true,
    duration: 0,
  });

  createOrder()
    .then((res) => {
      closeToast();
      showToast(t("创建成功"));
      showCenter.value = true;
      userGetInfoMethods();
      goods.value = res.data;
    })
    .catch((err) => {
      closeToast();
      if (err.code == 906) {
        showToast("Transaction failed");
      } else {
        showToast(t(errorMessages[err.code] || "创建失败"));
      }
    });
};

const submitForm = () => {
  submitOrder(goods.value.id)
    .then((res) => {
      showSuccessToast(t("提交成功"));
      userGetInfoMethods();
      if (res.code == 201) {
        goods.value = res.data;
      } else {
        showCenter.value = false;
      }
    })
    .catch((err) => {
      if (err.code == 916) {
        router.push("/deposit");
      }
      if (err.code == 906) {
        if (userInfo.value.balance <= 0) {
          showToast("Transaction failed");
        } else {
          showToast(t(errorMessages[err.code] || "Failed to create"));
        }
      } else {
        showToast(t(errorMessages[err.code] || "Failed to create"));
      }
    });
};
const toMy = () => {
  router.push({ path: "/my" });
};
const TradeInfor = ref({});
const tradeConfig = async () => {
  let res = await getTradeConfig();
  TradeInfor.value = res.data;
};

onUnmounted(() => {
  // 清除定时器，防止组件卸载后还在请求
  if (timer) clearTimeout(timer);
});

const userLevel = ref({})
const userGetInfoMethods = () => {
  userGetInfo().then((res) => {
    userInfo.value = res.data;
    avatarUrl.value = `${url}${res.data.userLevel.icon}`;
    orderCount.value = res.data.userLevel.orderCount;
    userLevel.value = res.data.userLevel.nameEn
  });
};

const orderCount = ref(0);
onMounted(() => {
  getList();
  userGetInfoMethods();
  tradeConfig();
});
</script>
