<template>
    <div class="starting-page algofy-starting-page">
        <div class="algofy-starting-shell">
            <header class="algofy-starting-header">
                <div class="algofy-starting-header__title">VIP</div>
            </header>

            <section class="algofy-user-strip">
                <div class="algofy-user-avatar-wrap">
                    <img
                        v-if="avatarUrl"
                        class="algofy-user-avatar"
                        :src="avatarUrl"
                        alt=""
                    />
                    <img
                        v-else
                        class="algofy-user-avatar"
                        src="@/static/images/vip_design/avatar.png"
                        alt=""
                    />
                </div>
                <div class="algofy-user-copy">
                    <div class="algofy-user-welcome">Welcome Back,</div>
                    <div class="algofy-user-name">{{ displayName }}</div>
                </div>
                <img
                    class="algofy-user-vip"
                    src="@/static/images/vip_design/vip1.png"
                    alt=""
                />
            </section>

            <main class="algofy-starting-content">
                <section class="algofy-product-section">
                    <div class="algofy-product-gallery">
                        <div
                            class="algofy-product-thumbs algofy-product-thumbs--left"
                        >
                            <div class="algofy-thumb-card">
                                <img
                                    v-if="galleryGoods[0]?.coverUrl"
                                    :src="getBlindBoxCoverUrl(galleryGoods[0])"
                                    alt=""
                                />
                            </div>
                            <div class="algofy-thumb-card">
                                <img
                                    v-if="galleryGoods[1]?.coverUrl"
                                    :src="getBlindBoxCoverUrl(galleryGoods[1])"
                                    alt=""
                                />
                            </div>
                        </div>

                        <div class="algofy-product-main-img">
                            <img
                                v-if="featuredGoods?.coverUrl"
                                :src="getBlindBoxCoverUrl(featuredGoods)"
                                alt=""
                            />
                        </div>

                        <div
                            class="algofy-product-thumbs algofy-product-thumbs--right"
                        >
                            <div class="algofy-thumb-card">
                                <img
                                    v-if="galleryGoods[3]?.coverUrl"
                                    :src="getBlindBoxCoverUrl(galleryGoods[3])"
                                    alt=""
                                />
                            </div>
                            <div
                                class="algofy-thumb-card algofy-thumb-card--dark"
                            >
                                <img
                                    v-if="galleryGoods[4]?.coverUrl"
                                    :src="getBlindBoxCoverUrl(galleryGoods[4])"
                                    alt=""
                                />
                            </div>
                        </div>
                    </div>

                    <h1 class="algofy-product-title">
                        {{
                            featuredGoods.goodsName ||
                            "NIKE Dunk Low Retro Men's Shoe"
                        }}
                    </h1>
                    <!-- <div class="algofy-product-rating">
                        <span class="algofy-rating-star">★</span>
                        <strong>{{ productScoreText }}</strong>
                        <span>{{ productReviewText }}</span>
                    </div> -->
                    <div class="algofy-product-price">
                        <span>Price:</span>
                        <strong>USD {{ productPriceText }}</strong>
                    </div>
                    <button
                        type="button"
                        class="algofy-start-btn"
                        :disabled="!isBlindBoxReady"
                        @click="handleClick"
                    >
                        START NOW ({{ userInfo.dealCount || 0 }}/{{
                            orderCount || 0
                        }})
                    </button>
                </section>

                <section class="algofy-balance-card">
                    <img
                        class="algofy-commission-icon"
                        src="@/static/images/starting-design/commission-icon.png"
                        alt=""
                    />
                    <div class="algofy-commission-label">
                        Today's Commission
                    </div>
                    <div class="algofy-commission-amount">
                        USD {{ userInfo.commission || "456.78" }}
                    </div>
                    <div class="algofy-commission-desc">
                        The Displayed Amount Reflects The<br />Commissions
                        Earned Today As An Indication.
                    </div>
                    <div class="algofy-balance-grid">
                        <div class="algofy-mini-balance">
                            <img
                                src="@/static/images/starting-design/wallet-icon.png"
                                alt=""
                            />
                            <div class="algofy-mini-title">Account Balance</div>
                            <div class="algofy-mini-amount">
                                USD {{ userInfo.balance || "123.45" }}
                            </div>
                            <p>
                                The Total Balance Reflects<br />Both The
                                Deposited<br />Amount And<br />Commissions
                                Earned.
                            </p>
                        </div>
                        <div class="algofy-mini-balance">
                            <img
                                src="@/static/images/starting-design/freeze-icon.png"
                                alt=""
                            />
                            <div class="algofy-mini-title">Freeze Amount</div>
                            <div class="algofy-mini-amount">
                                USD
                                {{
                                    userInfo.freezeAmount ||
                                    userInfo.frozenAmount ||
                                    "1,234.56"
                                }}
                            </div>
                            <p>
                                Pinned Balance<br />Where There Is A<br />Pending
                                Combination<br />Product In Process.
                            </p>
                        </div>
                    </div>
                </section>

                <section class="algofy-notice-card">
                    <h2>Important Notice:</h2>
                    <p>
                        Online Support Hours
                        {{ TradeInfor?.workTimeStart || "10:00" }} -
                        {{ TradeInfor?.workTimeEnd || "23:00" }}<br />
                        Please contact online support for your assistance!
                    </p>
                </section>

                <footer class="algofy-copyright-card">
                    <img
                        src="@/static/images/starting-design/footer-logo.png"
                        alt=""
                    />
                    <p>Copyright © 2025 ALGOFY Company.</p>
                    <p>All Rights Reserved.</p>
                </footer>
            </main>

            <MissionSubmissionPopup
                v-model="showMissionDialog"
                :product-name="missionProductTitle"
                :cover-url="missionCoverUrl"
                :score-text="missionScoreText"
                :review-text="missionReviewText"
                :price-text="missionPriceText"
                :total-amount-text="missionTotalAmountText"
                :commission-text="missionCommissionText"
                :create-time-text="missionCreateTimeText"
                :order-no-text="missionOrderNoText"
                :submitting="isMissionSubmitting"
                @back="closeMissionDialog"
                @submit="submitForm"
            />

            <van-popup
                v-model:show="showImg"
                class="lucky-draw-van-popup"
                overlay-class="lucky-draw-popup-overlay"
                :style="{ background: 'transparent' }"
            >
                <div class="lucky-draw-popup" @click="closeImg">
                    <img
                        class="lucky-draw-popup__panel"
                        src="@/static/images/popup-design/lucky-draw-panel.png"
                        alt=""
                    />
                    <div class="lucky-draw-popup__content">
                        <div class="lucky-draw-popup__title">
                            <span
                                v-for="(line, index) in luckyDrawTitleLines"
                                :key="index"
                            >
                                {{ line }}
                            </span>
                        </div>
                        <div class="lucky-draw-popup__desc">
                            {{ $t("lucky_draw_desc_before") }}
                            <span class="lucky-draw-popup__amount">
                                {{ $t("lucky_draw_amount") }}
                            </span>
                        </div>
                        <div class="lucky-draw-popup__claim">
                            {{ $t("lucky_draw_claim_text") }}
                        </div>
                        <div class="lucky-draw-popup__disclaimer">
                            {{ $t("lucky_draw_disclaimer") }}
                        </div>
                    </div>
                </div>
            </van-popup>
        </div>
    </div>
</template>

<script setup>
import { computed, onMounted, ref, onUnmounted } from "vue";
import {
    showLoadingToast,
    closeToast,
    showToast,
    showSuccessToast,
} from "@/util/message";
import { useI18n } from "vue-i18n";
import {
    getGoodsListTwo,
    createOrder,
    submitOrder,
    getTradeConfig,
} from "../../api/apis";
import { formatWithTimezone } from "../../util/utils";
import { useUserStore } from "@/store/modules/user";
import { useRouter } from "vue-router";
import { errorMessages } from "../../api/errorCodeMap";
import MissionSubmissionPopup from "@/components/MissionSubmissionPopup.vue";

const userStore = useUserStore();
const router = useRouter();
const { t, locale } = useI18n();

const userInfo = ref({});
const VITE_API_IMG_URL = window.g.VITE_API_IMG_URL
    ? window.g.VITE_API_IMG_URL
    : import.meta.env.VITE_API_IMG_URL;
const url = VITE_API_IMG_URL;
const avatarUrl = ref("");
let timer = null;
let luckyDrawTimer = null;

const goodsList = ref([]);
const visibleGoodsSource = ref([]);
const showMissionDialog = ref(false);
const showImg = ref(false);
const goods = ref({});
const isMissionSubmitting = ref(false);

const blindBoxAnimationClass = ref("blind-box-item--anim-rise");
const blindBoxRenderSeed = ref(0);
const blindBoxAnimationClasses = [
    "blind-box-item--anim-rise",
    "blind-box-item--anim-pop",
    "blind-box-item--anim-flip",
    "blind-box-item--anim-slide-left",
    "blind-box-item--anim-slide-right",
    "blind-box-item--anim-zoom",
    "blind-box-item--anim-swing",
    "blind-box-item--anim-rotate",
    "blind-box-item--anim-drop",
    "blind-box-item--anim-blur",
];
let blindBoxAnimationQueue = [];

const shuffleBlindBoxAnimations = () => {
    const pool = [...blindBoxAnimationClasses];
    for (let i = pool.length - 1; i > 0; i -= 1) {
        const j = Math.floor(Math.random() * (i + 1));
        [pool[i], pool[j]] = [pool[j], pool[i]];
    }
    return pool;
};

const nextBlindBoxAnimationClass = () => {
    if (!blindBoxAnimationQueue.length) {
        blindBoxAnimationQueue = shuffleBlindBoxAnimations();
    }

    const nextClass = blindBoxAnimationQueue.shift();
    if (
        nextClass === blindBoxAnimationClass.value &&
        blindBoxAnimationQueue.length
    ) {
        blindBoxAnimationQueue.push(nextClass);
        return blindBoxAnimationQueue.shift();
    }

    return nextClass || blindBoxAnimationClasses[0];
};

const displayName = computed(() => {
    return userInfo.value.username || userStore.userInfo?.username || "--";
});

const BLIND_BOX_VISIBLE_COUNT = 9;
const isBlindBoxReady = ref(false);
let blindBoxPreloadToken = 0;
let lastBlindBoxGoodsKey = "";
let isStartingPageUnmounted = false;

const normalizeBlindBoxList = (list) => {
    return (Array.isArray(list) ? list : []).slice(0, BLIND_BOX_VISIBLE_COUNT);
};

const getBlindBoxCoverUrl = (item) => {
    return item?.coverUrl ? `${url}${item.coverUrl}` : "";
};

const getBlindBoxGoodsKey = (list) => {
    return normalizeBlindBoxList(list)
        .map((item, index) =>
            [
                item?.id || "",
                item?.orderNo || "",
                item?.coverUrl || "",
                index,
            ].join("|"),
        )
        .join("||");
};

const galleryGoods = computed(() =>
    normalizeBlindBoxList(visibleGoodsSource.value).filter(
        (item) => item?.coverUrl,
    ),
);

const featuredGoods = computed(
    () => galleryGoods.value[2] || galleryGoods.value[0] || {},
);

const productPriceText = computed(() => {
    const amount = Number(
        featuredGoods.value?.price || goods.value?.price || 0,
    );
    return amount.toFixed(2);
});

const productScoreText = computed(
    () => featuredGoods.value?.score || featuredGoods.value?.rate || "4.9",
);

const productReviewText = computed(() => {
    const reviewCount =
        featuredGoods.value?.reviewCount ??
        featuredGoods.value?.commentCount ??
        featuredGoods.value?.saleCount ??
        123;
    return `${reviewCount} ${t("reviews")}`;
});

const missionCoverUrl = computed(() => {
    if (goods.value?.coverUrl) return `${url}${goods.value.coverUrl}`;
    return featuredGoods.value?.coverUrl
        ? `${url}${featuredGoods.value.coverUrl}`
        : "";
});

const missionProductTitle = computed(
    () =>
        goods.value?.goodsName ||
        featuredGoods.value?.goodsName ||
        "NIKE Dunk Low Retro Men's Shoe",
);
const missionScoreText = computed(
    () =>
        goods.value?.score ||
        featuredGoods.value?.score ||
        featuredGoods.value?.rate ||
        "4.9",
);
const missionReviewText = computed(() => productReviewText.value);
const missionPriceText = computed(() => {
    const amount = Number(
        goods.value?.price || featuredGoods.value?.price || 0,
    );
    return amount.toFixed(2);
});
const missionTotalAmountText = computed(() => {
    const amount = Number(goods.value?.price || 0);
    return amount ? amount.toFixed(2) : "456.78";
});
const missionCommissionText = computed(() => {
    const amount = Number(goods.value?.commission || 0);
    return amount ? amount.toFixed(2) : "46.78";
});
const missionCreateTimeText = computed(() => {
    if (!goods.value?.createTime) return "2025-06-15 19:38:44";
    return formatWithTimezone(
        goods.value.createTime,
        userStore.zoneActive?.tzName,
    );
});
const missionOrderNoText = computed(
    () => goods.value?.orderNo || "202506157896541230123",
);

const luckyDrawTitleLines = computed(() => {
    const title = t("lucky_draw_title");
    if (!title) return [];
    if (title.includes("\n")) {
        return title
            .split("\n")
            .map((item) => item.trim())
            .filter(Boolean);
    }
    if (locale.value === "en" || /Lucky Draw/i.test(title)) {
        return ["You Have Won The", "Lucky Draw!"];
    }
    return [title];
});

const loadBlindBoxImage = async (src) => {
    return new Promise((resolve) => {
        if (!src) {
            resolve();
            return;
        }
        const image = new Image();
        let settled = false;
        const done = () => {
            if (settled) return;
            settled = true;
            resolve();
        };
        image.onload = async () => {
            try {
                if (typeof image.decode === "function") {
                    await image.decode();
                }
            } catch (error) {}
            done();
        };
        image.onerror = done;
        image.src = src;
    });
};

const preloadBlindBoxImages = async (list) => {
    const normalizedList = normalizeBlindBoxList(list);
    const nextGoodsKey = getBlindBoxGoodsKey(normalizedList);
    if (isBlindBoxReady.value && nextGoodsKey === lastBlindBoxGoodsKey) return;

    const nextToken = ++blindBoxPreloadToken;
    const imageUrls = Array.from(
        new Set(normalizedList.map(getBlindBoxCoverUrl).filter(Boolean)),
    );
    await Promise.all(imageUrls.map(loadBlindBoxImage));

    if (nextToken !== blindBoxPreloadToken || isStartingPageUnmounted) return;

    blindBoxAnimationClass.value = nextBlindBoxAnimationClass();
    blindBoxRenderSeed.value += 1;
    visibleGoodsSource.value = normalizedList;
    lastBlindBoxGoodsKey = nextGoodsKey;
    isBlindBoxReady.value = true;
};

const getList = async () => {
    try {
        const res = await getGoodsListTwo();
        const nextList = Array.isArray(res.data) ? res.data : [];
        goodsList.value = nextList;
        await preloadBlindBoxImages(nextList);
    } catch (e) {
        console.error("获取商品列表失败:", e);
    } finally {
        if (!isStartingPageUnmounted) {
            timer = setTimeout(getList, 10000);
        }
    }
};

const handleClick = () => {
    doCreateOrder();
};

const closeImg = () => {
    showImg.value = false;
    if (luckyDrawTimer) {
        clearTimeout(luckyDrawTimer);
        luckyDrawTimer = null;
    }
};

const closeMissionDialog = () => {
    if (isMissionSubmitting.value) return;
    showMissionDialog.value = false;
};

const doCreateOrder = () => {
    showLoadingToast({
        message: t("creating"),
        forbidClick: true,
        duration: 0,
    });

    createOrder()
        .then((res) => {
            closeToast();
            goods.value = res.data || {};
            showMissionDialog.value = true;
            userGetInfoMethods({ force: true });
        })
        .catch((err) => {
            closeToast();
            if (err.code == 2000) {
                showImg.value = true;
                if (luckyDrawTimer) clearTimeout(luckyDrawTimer);
                luckyDrawTimer = setTimeout(() => {
                    showImg.value = false;
                    luckyDrawTimer = null;
                }, 15000);
            } else if (err.code == 909) {
                showToast(
                    `User has filled in ${err.data} pieces of data. please contact Customer Service to apply for resetting account`,
                );
            } else {
                showToast(t(errorMessages[err.code] || "creation_failed"));
            }
        });
};

const submitForm = () => {
    if (isMissionSubmitting.value || !goods.value?.id) return;
    isMissionSubmitting.value = true;
    submitOrder(goods.value.id)
        .then((res) => {
            closeToast();
            userGetInfoMethods({ force: true });
            if (res.code == 201 && res.data) {
                goods.value = res.data;
            }
            showSuccessToast(t("mission_submitted_completed"));
            showMissionDialog.value = false;
        })
        .catch((err) => {
            if (err.code == 916) {
                showToast(t("insufficient_balance_please"));
                return;
            }
            if (err.code == 906) {
                if (userInfo.value.balance <= 0) {
                    showToast(t("transaction_failed"));
                } else {
                    showToast(t(errorMessages[err.code] || "creation_failed"));
                }
            } else {
                showToast(t(errorMessages[err.code] || "creation_failed"));
            }
        })
        .finally(() => {
            isMissionSubmitting.value = false;
        });
};

const TradeInfor = ref({});
const tradeConfig = async () => {
    const res = await getTradeConfig();
    TradeInfor.value = res.data;
};

const userLevel = ref("");
const orderCount = ref(0);

const syncUserInfo = (info = {}) => {
    userInfo.value = info || {};

    const levelInfo = userInfo.value?.userLevel || {};
    // console.log("userInfo.value", userInfo.value);
    // console.log("userInfo.value.avatar", userInfo.value.avatar);
    avatarUrl.value = userInfo.value.avatar
        ? userInfo.value.avatar
        : levelInfo.icon
          ? `${url}${levelInfo.icon}`
          : "";
    orderCount.value = levelInfo.orderCount || 0;
    userLevel.value = levelInfo.nameEn || "";
};

const userGetInfoMethods = async (options = {}) => {
    const info = await userStore.getUserInfo(options);
    syncUserInfo(info);
    return info;
};

onUnmounted(() => {
    isStartingPageUnmounted = true;
    blindBoxPreloadToken += 1;
    if (timer) clearTimeout(timer);
    if (luckyDrawTimer) clearTimeout(luckyDrawTimer);
});

onMounted(() => {
    getList();
    userGetInfoMethods();
    tradeConfig();
});
</script>
<style scoped>
.algofy-starting-page {
    min-height: 100vh;
    background: #eef2f8;
    color: #111111;
}

.algofy-starting-shell {
    min-height: 100vh;
    background: #eef2f8;
    overflow-x: hidden;
}

.algofy-starting-header {
    position: relative;
    height: 100px;
    background: #191919 url("@/static/images/auth/algofy-register-hero.png") top
        center / cover no-repeat;
    color: #ffffff;
}

.algofy-starting-header__status {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 44px;
    padding: 0 16px 0 24px;
}

.algofy-starting-header__time {
    font-size: 13px;
    line-height: 1;
    font-weight: 700;
}

.algofy-starting-header__status-icons {
    display: flex;
    align-items: center;
    gap: 8px;
}

.algofy-starting-header__signal {
    display: flex;
    align-items: flex-end;
    gap: 2px;
    height: 12px;
}

.algofy-starting-header__signal span {
    display: block;
    width: 3px;
    border-radius: 999px;
    background: #ffffff;
}

.algofy-starting-header__signal span:nth-child(1) {
    height: 5px;
    opacity: 0.7;
}
.algofy-starting-header__signal span:nth-child(2) {
    height: 7px;
    opacity: 0.8;
}
.algofy-starting-header__signal span:nth-child(3) {
    height: 10px;
    opacity: 0.9;
}
.algofy-starting-header__signal span:nth-child(4) {
    height: 12px;
}

.algofy-starting-header__wifi {
    position: relative;
    width: 16px;
    height: 11px;
}

.algofy-starting-header__wifi::before,
.algofy-starting-header__wifi::after {
    content: "";
    position: absolute;
    left: 50%;
    border: 2px solid transparent;
    border-top-color: #ffffff;
    border-radius: 50%;
    transform: translateX(-50%) rotate(180deg);
}

.algofy-starting-header__wifi::before {
    top: 1px;
    width: 16px;
    height: 12px;
}

.algofy-starting-header__wifi::after {
    top: 4px;
    width: 9px;
    height: 7px;
}

.algofy-starting-header__battery {
    position: relative;
    width: 24px;
    height: 12px;
    border: 1.8px solid #ffffff;
    border-radius: 3px;
    box-sizing: border-box;
}

.algofy-starting-header__battery::after {
    content: "";
    position: absolute;
    top: 3px;
    right: -3px;
    width: 2px;
    height: 4px;
    border-radius: 0 1px 1px 0;
    background: #ffffff;
}

.algofy-starting-header__battery-level {
    position: absolute;
    inset: 2px;
    border-radius: 1px;
    background: #ffffff;
}

.algofy-starting-header__title {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 56px;
    font-size: 18px;
    line-height: 1;
    font-weight: 800;
    letter-spacing: 0.5px;
}

.algofy-user-strip {
    height: 93px;
    padding: 18px 16px 16px;
    background: linear-gradient(180deg, #3e86ff 0%, #2554de 100%);
    display: flex;
    align-items: center;
    color: #ffffff;
}

.algofy-user-avatar-wrap {
    width: 54px;
    height: 54px;
    flex: 0 0 54px;
    border-radius: 50%;
    overflow: hidden;
    background: #d7ecff;
}

.algofy-user-avatar {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.algofy-user-copy {
    flex: 1;
    min-width: 0;
    padding-left: 12px;
}

.algofy-user-welcome {
    font-family: Montserrat, Montserrat;
    font-weight: 500;
    font-size: 14px;
    color: #ffffff;
    text-align: left;
    font-style: normal;
    text-transform: none;
}

.algofy-user-name {
    margin-top: 8px;
    font-family: Montserrat, Montserrat;
    font-weight: 600;
    font-size: 16px;
    color: #ffffff;
    text-align: left;
    font-style: normal;
    text-transform: none;
}

.algofy-user-vip {
    width: 48px;
    height: 48px;
    object-fit: contain;
    margin-left: 8px;
}

.algofy-starting-content {
    padding: 0 0 10px;
    background: #eef2f8;
}

.algofy-product-section {
    position: relative;
    background: #ffffff;
    padding: 26px 16px 24px;
    overflow: hidden;
}

.algofy-product-section::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 42px;
    background: #eef2f8;
    clip-path: polygon(0 0, 100% 0, 100% 31%, 0 100%);
}

.algofy-product-gallery {
    position: relative;
    z-index: 1;
    display: grid;
    grid-template-columns: 85px 1fr 73px;
    gap: 12px;
    align-items: center;
    min-height: 190px;
}

.algofy-product-thumbs {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.algofy-thumb-card {
    width: 78px;
    height: 78px;
    border-radius: 6px;
    background: #f3f5f8;
    overflow: hidden;
}

.algofy-thumb-card--dark {
    background: #111111;
}

.algofy-thumb-card img,
.algofy-product-main-img img {
    width: 100%;
    height: 100%;
    display: block;
    object-fit: cover;
}

.algofy-product-main-img {
    height: 178px;
    border: 2px solid #7592ff;
    border-radius: 8px;
    background: #f8f8f8;
    overflow: hidden;
}

.algofy-product-title {
    margin: 18px auto 0;
    font-family: Montserrat, Montserrat;
    font-weight: 600;
    font-size: 16px;
    color: #000000;
    line-height: 20px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-product-rating {
    margin-top: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    color: #6f7787;
    font-size: 16px;
    line-height: 1;
}

.algofy-product-rating strong {
    color: #111111;
    font-weight: 800;
}

.algofy-rating-star {
    color: #f5b400;
    font-size: 22px;
    line-height: 1;
}

.algofy-product-price {
    margin-top: 18px;
    display: flex;
    align-items: baseline;
    justify-content: center;
    gap: 6px;

    font-family: Montserrat, Montserrat;
    font-weight: 600;
    font-size: 16px;
    line-height: 20px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-product-price strong {
    color: #3043e3;
}

.algofy-start-btn {
    width: 100%;
    height: 52px;
    margin-top: 25px;
    border: 0;
    border-radius: 8px;
    background: #3043e3;
    font-family: Montserrat, Montserrat;
    font-weight: 600;
    font-size: 16px;
    color: #fafafa;
    line-height: 24px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-start-btn:disabled {
    opacity: 0.72;
}

.algofy-balance-card {
    margin: 0 16px;
    padding: 28px 18px 26px;
    border-radius: 8px;
    background: #243f90;
    color: #ffffff;
    text-align: center;
}

.algofy-commission-icon {
    width: 54px;
    height: 54px;
    object-fit: contain;
    margin: 0 auto 12px;
}

.algofy-commission-label {
    color: #ffcf17;
    font-family: Montserrat, Montserrat;
    font-weight: 600;
    font-size: 14px;
    color: #facc15;
    line-height: 20px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-commission-amount {
    margin-top: 12px;
    font-family: Montserrat, Montserrat;
    font-weight: 600;
    font-size: 30px;
    color: #ffffff;
    line-height: 36px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-commission-desc {
    margin-top: 12px;
    font-family: Montserrat, Montserrat;
    font-weight: 500;
    font-size: 12px;
    color: #bfdbfe;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-balance-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;
    margin-top: 17px;
}

.algofy-mini-balance img {
    width: 53px;
    height: 53px;
    object-fit: contain;
    margin: 0 auto;
}

.algofy-mini-title {
    color: #ffcf17;
    font-family: Montserrat, Montserrat;
    font-weight: 600;
    font-size: 14px;
    color: #facc15;
    line-height: 20px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-mini-amount {
    margin-top: 5px;
    font-family: Montserrat, Montserrat;
    font-weight: 600;
    font-size: 20px;
    color: #ffffff;
    line-height: 28px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-mini-balance p {
    margin: 13px 0 0;
    font-family: Montserrat, Montserrat;
    font-weight: 500;
    font-size: 12px;
    color: #bfdbfe;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-notice-card {
    margin: 16px 16px 0;
    padding: 18px 12px 20px;
    border-radius: 8px;
    background: #e5e7eb;
    text-align: center;
}

.algofy-notice-card h2 {
    margin: 0;
    font-family: Montserrat, Montserrat;
    font-weight: 600;
    font-size: 14px;
    color: #000000;
    line-height: 20px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-notice-card p {
    margin: 6px 0 0;
    font-family: Montserrat, Montserrat;
    font-weight: 500;
    font-size: 12px;
    color: #4b5563;
    line-height: 23px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.algofy-copyright-card {
    margin-top: 18px;
    padding: 26px 16px 26px;
    background: #111827;
    color: #ffffff;
    text-align: center;
}

.algofy-copyright-card img {
    display: block;
    width: 53px;
    height: 53px;
    object-fit: contain;
    margin: 0 auto 12px;
}

.algofy-copyright-card p {
    margin: 0;
    font-family: Geist-Regular, Geist-Regular;
    font-weight: normal;
    font-size: 12px;
    color: #ffffff;
    line-height: 16px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.task-panel {
    padding: 20px 18px;
    border-radius: 18px;
    background: #ffffff;
}

.task-panel__title {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 16px;
    line-height: 1.2;
}

.task-panel__title--warn {
    color: #bf7d1d;
}

.task-panel__instructions {
    margin-top: 18px;
    color: #516b53;
    font-size: 15px;
    line-height: 1.9;
}

.task-panel__heading {
    text-align: center;
    color: #1c261d;
    font-size: 18px;
    font-weight: 500;
}

.task-order-card {
    margin-top: 18px;
    padding: 18px;
    border: 1px solid #b8debf;
    border-radius: 16px;
    background: #f3fbf5;
    text-align: center;
}

.task-order-card__label {
    color: #495e4b;
    font-size: 16px;
}

.task-order-card__id {
    margin-top: 12px;
    color: #17a445;
    font-size: 17px;
    font-weight: 600;
    word-break: break-all;
}

.task-order-card__time {
    margin-top: 22px;
    text-align: center;
    color: #6a7e6b;
    font-size: 14px;
    line-height: 1.5;
}

.lucky-draw-van-popup {
    background: transparent;
    overflow: visible;
}

:deep(.lucky-draw-popup-overlay) {
    background: rgba(0, 0, 0, 0.55);
}

.lucky-draw-popup {
    position: relative;
    width: 286px;
    text-align: center;
}

.lucky-draw-popup__panel {
    display: block;
    width: 100%;
    height: auto;
}

.lucky-draw-popup__content {
    position: absolute;
    inset: 152px 20px 24px;
    display: flex;
    flex-direction: column;
    align-items: center;
    overflow: hidden;
}

.lucky-draw-popup__title {
    margin: 0;
    max-width: 224px;
    color: #ffffff;
    font-size: 17px;
    line-height: 1.28;
    font-weight: 800;
    letter-spacing: 0.01em;
}

.lucky-draw-popup__title span {
    display: block;
    font-family: Montserrat, Montserrat;
    font-weight: 600;
    font-size: 18px;
    color: #ffffff;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.lucky-draw-popup__desc,
.lucky-draw-popup__claim,
.lucky-draw-popup__disclaimer {
    margin: 12px 0 0;
    color: #ffffff;
    font-size: 10.5px;
    font-weight: 500;
    word-break: break-word;
}

.lucky-draw-popup__desc {
    max-width: 224px;

    font-family: Montserrat, Montserrat;
    font-size: 14px;
    color: #ffffff;
    line-height: 20px;
    text-align: center;
    font-style: normal;
    text-transform: none;
}

.lucky-draw-popup__claim {
    max-width: 218px;
    margin-top: 12px;
}

.lucky-draw-popup__disclaimer {
    max-width: 236px;
    margin-top: 10px;
    padding-bottom: 6px;
    line-height: 1.25;
}

.lucky-draw-popup__amount {
    font-weight: 600;
    font-size: 14px;
    color: #ffed12;
}

.mission-submission-van-popup {
    background: #edeef5;
}

:deep(.mission-submission-popup-overlay) {
    background: rgba(0, 0, 0, 0.45);
}

.mission-submission-popup {
    min-height: 100vh;
    min-height: 100dvh;
    background: #e9ebf2;
}

.mission-submission-header {
    background: #000000;
    color: #ffffff;
}

.mission-submission-header__status {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 44px;
    padding: 0 16px 0 24px;
}

.mission-submission-header__time {
    font-size: 13px;
    line-height: 1;
    font-weight: 700;
}

.mission-submission-header__status-icons {
    display: flex;
    align-items: center;
    gap: 8px;
}

.mission-submission-header__signal {
    display: flex;
    align-items: flex-end;
    gap: 2px;
    height: 12px;
}

.mission-submission-header__signal span {
    display: block;
    width: 3px;
    border-radius: 999px;
    background: #ffffff;
}

.mission-submission-header__signal span:nth-child(1) {
    height: 5px;
    opacity: 0.7;
}
.mission-submission-header__signal span:nth-child(2) {
    height: 7px;
    opacity: 0.8;
}
.mission-submission-header__signal span:nth-child(3) {
    height: 10px;
    opacity: 0.9;
}
.mission-submission-header__signal span:nth-child(4) {
    height: 12px;
}

.mission-submission-header__wifi {
    position: relative;
    width: 16px;
    height: 11px;
}

.mission-submission-header__wifi::before,
.mission-submission-header__wifi::after {
    content: "";
    position: absolute;
    left: 50%;
    border: 2px solid transparent;
    border-top-color: #ffffff;
    border-radius: 50%;
    transform: translateX(-50%) rotate(180deg);
}

.mission-submission-header__wifi::before {
    top: 1px;
    width: 16px;
    height: 12px;
}

.mission-submission-header__wifi::after {
    top: 4px;
    width: 9px;
    height: 7px;
}

.mission-submission-header__battery {
    position: relative;
    width: 22px;
    height: 11px;
    border: 1.8px solid #ffffff;
    border-radius: 3px;
}

.mission-submission-header__battery::after {
    content: "";
    position: absolute;
    top: 2px;
    right: -3px;
    width: 2px;
    height: 5px;
    border-radius: 1px;
    background: #ffffff;
}

.mission-submission-header__battery-level {
    position: absolute;
    inset: 1px;
    border-radius: 2px;
    background: #ffffff;
}

.mission-submission-header__bar {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 64px;
}

.mission-submission-header__back {
    position: absolute;
    left: 12px;
    top: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    padding: 0;
    border: 0;
    background: transparent;
    transform: translateY(-50%);
}

.mission-submission-header__title {
    font-size: 16px;
    letter-spacing: 0.02em;
}

.mission-submission-body {
    padding: 22px 16px 30px;
}

.mission-card {
    border-radius: 22px;
    background: #28459b;
    padding: 22px 20px 24px;
    box-shadow: 0 8px 18px rgba(30, 51, 114, 0.08);
}

.mission-card__image-wrap {
    width: 212px;
    height: 212px;
    margin: 0 auto;
    border-radius: 18px;
    overflow: hidden;
    background: #c52b31;
}

.mission-card__image {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.mission-card__title {
    margin: 22px 0 0;
    color: #ffffff;
    font-size: 25px;
    line-height: 1.22;
    font-weight: 600;
    text-align: center;
}

.mission-card__rating {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    margin-top: 18px;
    color: #ffffff;
    font-size: 18px;
}

.mission-card__rating strong {
    font-size: 21px;
    font-weight: 600;
}

.mission-card__star {
    color: #ffcc21;
    font-size: 28px;
    line-height: 1;
}

.mission-card__price {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    margin-top: 18px;
    color: #ffffff;
    font-size: 24px;
    font-weight: 500;
}

.mission-card__price strong {
    font-size: 24px;
    font-weight: 700;
}

.mission-card__summary-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 16px;
    margin-top: 26px;
}

.mission-card__summary-box,
.mission-card__meta-box {
    border-radius: 14px;
    background: #08153c;
    color: #ffffff;
}

.mission-card__summary-box {
    min-height: 128px;
    padding: 18px 18px 16px;
}

.mission-card__summary-label {
    color: #ffd835;
    font-size: 16px;
    line-height: 1.25;
}

.mission-card__summary-value {
    margin-top: 18px;
    font-size: 30px;
    line-height: 1;
    font-weight: 300;
}

.mission-card__summary-value--large {
    margin-top: 18px;
    font-size: 30px;
    line-height: 1.1;
    font-weight: 300;
}

.mission-card__meta-box {
    margin-top: 18px;
    padding: 16px 18px;
}

.mission-card__meta-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    color: rgba(255, 255, 255, 0.96);
    font-size: 16px;
    line-height: 1.5;
}

.mission-card__meta-row + .mission-card__meta-row {
    margin-top: 14px;
}

.mission-card__meta-row strong {
    font-size: 16px;
    font-weight: 500;
    text-align: right;
}

.mission-card__submit {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 58px;
    margin-top: 30px;
    border: 0;
    border-radius: 14px;
    background: #3b48e8;
    color: #ffffff;
    font-size: 22px;
    font-weight: 700;
    letter-spacing: 0.03em;
}

.mission-card__submit:disabled {
    opacity: 0.7;
}

.mission-card__submit-spinner {
    width: 24px;
    height: 24px;
    border: 3px solid rgba(255, 255, 255, 0.35);
    border-top-color: #ffffff;
    border-radius: 50%;
    animation: mission-submit-spin 0.8s linear infinite;
}

@keyframes mission-submit-spin {
    to {
        transform: rotate(360deg);
    }
}

.mission-submission-footer {
    padding: 26px 0 8px;
    color: #6c7892;
    font-size: 17px;
    line-height: 1.45;
    text-align: center;
}

.lucky-draw-popup__content {
    inset: 148px 24px 26px;
}

.lucky-draw-popup__title {
    max-width: 218px;
    font-size: 17px;
    line-height: 1.2;
}

.lucky-draw-popup__disclaimer {
    max-width: 218px;
    margin-top: 12px;
    line-height: 1.22;
}

/* starting top: remove fake status bar and keep compact header */
.algofy-starting-header {
    height: 78px !important;
    display: flex !important;
    align-items: flex-end !important;
    justify-content: center !important;
    padding-bottom: 17px !important;
    box-sizing: border-box !important;
}

.algofy-starting-header__status,
.algofy-starting-header__time,
.algofy-starting-header__status-icons,
.algofy-starting-header__signal,
.algofy-starting-header__wifi,
.algofy-starting-header__battery {
    display: none !important;
}

.algofy-starting-header__title {
    height: auto !important;
}

/* final starting header adjustment: no fake phone status bar */
.algofy-starting-header {
    height: 78px !important;
}
.algofy-starting-header__status,
.algofy-starting-header__time,
.algofy-starting-header__status-icons,
.algofy-starting-header__signal,
.algofy-starting-header__wifi,
.algofy-starting-header__battery,
.algofy-starting-header__battery-level {
    display: none !important;
}
</style>
