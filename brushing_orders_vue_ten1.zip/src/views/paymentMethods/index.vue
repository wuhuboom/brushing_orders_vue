<template>
  <div class="payment-method-page min-h-screen bg-[#eef2fb]">
    <PageTopBar :title="$t('payment_method')" show-back @click-left="onClickLeft">
      <template #right>
        <div class="history-text">History</div>
      </template>
    </PageTopBar>

    <div class="payment-method-page__body">
      <section class="payment-method-page__amount-card">
        <div class="payment-method-page__amount-label">Account Amount</div>
        <div class="payment-method-page__amount-value">{{ accountAmountText }}</div>
      </section>

      <div class="payment-method-page__form">
        <div class="field-group">
          <div class="field-title">Wallet name</div>
          <div class="field-box field-box--select">
            <van-field
              v-model="form.withdrawName"
              label=""
              :placeholder="$t('wallet')"
              label-align="top"
              class="custom-field"
            />
            <van-icon name="arrow-down" size="20" color="#1F1F1F" />
          </div>
        </div>

        <div class="field-group">
          <div class="field-title">Network</div>
          <div class="field-box">
            <van-field
              v-model="form.withdrawType"
              label=""
              :placeholder="$t('network')"
              label-align="top"
              class="custom-field"
            />
          </div>
        </div>

        <div class="field-group">
          <div class="field-title">Wallet address</div>
          <div class="field-box">
            <van-field
              v-model="form.withdrawAddress"
              label=""
              :placeholder="$t('address')"
              label-align="top"
              class="custom-field"
            />
          </div>
        </div>

        <div class="notice-text">
          You will receive your withdrawal within an hour
        </div>

        <van-button
          class="submit-btn"
          :class="{ 'submit-btn--active': isFormReady }"
          block
          @click="submitForm"
        >
          {{ $t("confirm") }}
        </van-button>
      </div>
    </div>
  </div>
</template>
<script setup>
import { computed, onMounted, reactive } from "vue";
import { addWithdrawalMethod } from "../../api/apis";
import { useUserStore } from "@/store/modules/user";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import { showToast } from "@/util/message";
const userStore = useUserStore();
const router = useRouter();
const { t } = useI18n();
const form = reactive({
  withdrawName: "",
  withdrawAddress: "",
  withdrawType: "",
});
const accountAmountText = computed(() => {
  const amount = Number(userStore.userInfo?.balance || 0);
  return amount.toFixed(2);
});
const isFormReady = computed(
  () =>
    !!String(form.withdrawName || "").trim() &&
    !!String(form.withdrawAddress || "").trim() &&
    !!String(form.withdrawType || "").trim(),
);
const submitForm = async () => {
  if (!form.withdrawName) return showToast(t("please_enter_wallet_name"));
  if (!form.withdrawAddress) return showToast(t("please_enter_network"));
  if (!form.withdrawAddress) return showToast(t("please_enter_address"));
  let res = await addWithdrawalMethod(form);
  showToast(t("added_successfully"));
  router.push({ path: "/my" });
};

const onClickLeft = () => {
  router.push({ path: "/my" });
};
onMounted(async () => {
  await userStore.getUserInfo();
  form.withdrawName = userStore.userInfo.withdrawName;
  form.withdrawAddress = userStore.userInfo.withdrawAddress;
  form.withdrawType = userStore.userInfo.withdrawType;
});
</script>

<style scoped>
.payment-method-page__body {
  padding: 92px 20px 36px;
}

.history-text {
  color: #ffffff;
  font-size: 16px;
  font-weight: 500;
}

.payment-method-page__amount-card {
  position: relative;
  overflow: hidden;
  padding: 28px 26px 34px;
  border-radius: 18px;
  background: linear-gradient(90deg, #2d49a6 0%, #4485f5 100%);
}

.payment-method-page__amount-card::before,
.payment-method-page__amount-card::after {
  content: "";
  position: absolute;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.08);
}

.payment-method-page__amount-card::before {
  top: -34px;
  right: -10px;
  width: 150px;
  height: 150px;
}

.payment-method-page__amount-card::after {
  right: 92px;
  bottom: -48px;
  width: 188px;
  height: 188px;
}

.payment-method-page__amount-label,
.payment-method-page__amount-value {
  position: relative;
  z-index: 1;
  color: #ffffff;
}

.payment-method-page__amount-label {
  font-size: 22px;
  line-height: 1.2;
  font-weight: 600;
}

.payment-method-page__amount-value {
  margin-top: 26px;
  font-size: 54px;
  line-height: 1;
  font-weight: 700;
  letter-spacing: -0.03em;
}

.payment-method-page__form {
  margin-top: 34px;
}

.field-group + .field-group {
  margin-top: 28px;
}

.field-title {
  margin-bottom: 14px;
  color: #0f1115;
  font-size: 22px;
  line-height: 1.2;
  font-weight: 500;
}

.field-box {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 94px;
  padding: 0 22px;
  border: 1px solid #d8e0ee;
  border-radius: 18px;
  background: #ffffff;
}

.field-box--select {
  padding-right: 18px;
}

.custom-field {
  flex: 1;
  padding: 0;
  background: transparent;
}

.payment-method-page :deep(.custom-field.van-cell) {
  padding: 0;
  background: transparent;
}

.payment-method-page :deep(.custom-field .van-field__body) {
  min-height: 94px;
}

.payment-method-page :deep(.custom-field .van-field__control) {
  color: #111827;
  font-size: 18px;
  min-height: 24px;
}

.payment-method-page :deep(.custom-field .van-field__control::placeholder) {
  color: #596375;
}

.notice-text {
  margin: 44px 4px 0;
  color: #2f5ff4;
  font-size: 18px;
  line-height: 1.45;
}

.submit-btn {
  margin-top: 42px;
  height: 58px;
  border: none;
  border-radius: 16px;
  background: #d1d8f6;
  color: #ffffff;
  font-size: 18px;
  font-weight: 600;
}

.submit-btn--active {
  background: linear-gradient(90deg, #3b45df 0%, #3a4be7 100%);
  box-shadow: none;
  color: #ffffff;
}
</style>
