<template>
    <div class="vip-page min-h-[100vh] bg-[#f5faf6] text-[#14351f]">
        <main class="pb-[24px] pt-0">
            <section class="vip-showcase">
                <div class="vip-showcase__top">
                    <div class="vip-showcase__line vip-showcase__line--one"></div>
                    <div class="vip-showcase__line vip-showcase__line--two"></div>
                    <div class="vip-showcase__title">VIP</div>
                </div>
                <div class="vip-showcase__card">
                    <div class="vip-showcase__avatar-shell">
                        <img :src="userAvatar" class="vip-showcase__avatar" alt="" />
                    </div>
                    <div class="vip-showcase__badge">
                        <img :src="medalIcon(displayLevels[0], currentLevelIndex)" alt="" />
                    </div>
                    <div class="vip-showcase__name">
                        {{ userStore.userInfo?.username || "Wuhu1" }}
                    </div>
                    <div class="vip-showcase__level">{{ currentLevelName }}</div>
                    <p class="vip-showcase__desc">
                        {{ $t("vip_five_star_desc") }}
                    </p>
                </div>
            </section>

            <section class="mt-[16px] px-[14px]">
                <h2
                    class="vip-section-title"
                >
                    {{ $t("vip_level_details_all_expanded") }}
                </h2>

                <div class="mt-[10px] space-y-[12px]">
                    <article
                        v-for="(item, index) in displayLevels"
                        :key="item.id || item.nameEn || index"
                        class="vip-card overflow-hidden bg-white"
                        :class="vipCardBorderClass(item, index)"
                        :style="cardThemeStyle(item, index)"
                    >
                        <div
                            class="vip-card-head relative overflow-hidden px-[14px] py-[14px] text-white"
                            :class="cardTheme(item, index).headClass"
                        >
                            <div class="vip-card-bubble"></div>
                            <div
                                v-if="isCurrentLevel(item, index)"
                                class="absolute right-[14px] top-[12px] rounded-full bg-white/20 px-[8px] py-[3px] text-[8px] font-bold uppercase tracking-[0.5px]"
                            >
                                {{ $t("current") }}
                            </div>
                            <div
                                v-else-if="index === displayLevels.length - 1"
                                class="absolute right-[14px] top-[12px] rounded-full bg-white/20 px-[10px] py-[3px] text-[8px] font-bold uppercase tracking-[0.5px]"
                            >
                                {{ $t("top") }}
                            </div>
                            <div class="relative z-[1] flex items-center">
                                <div class="vip-medal">
                                    <img
                                        :src="medalIcon(item, index)"
                                        class="vip-medal-img"
                                        alt=""
                                    />
                                </div>
                                <div class="ml-[11px] min-w-0">
                                    <div class="text-[18px] font-semibold leading-[22px]">
                                        {{ normalizeLevelName(item, index) }}
                                    </div>
                                    <div class="mt-[2px] text-[9px] leading-[13px] text-white/80">
                                        {{ vipSubtitle(item, index) }}
                                    </div>
                                </div>
                            </div>
                            <div class="vip-head-stats relative z-[1]">
                                <div
                                    v-for="stat in levelStats(item, index)"
                                    :key="stat.label"
                                    class="vip-head-stat"
                                >
                                    <div class="vip-head-stat__label">
                                        {{ stat.label }}
                                    </div>
                                    <div class="vip-head-stat__value">
                                        {{ stat.value }}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="vip-card-body">
                            <div class="vip-feature-panel">
                                <div
                                    class="text-[10px] font-semibold uppercase leading-[14px] tracking-[1px] text-[#333]"
                                >
                                    {{ $t("included_features") }}
                                </div>
                                <div class="mt-[10px] space-y-[7px]">
                                    <div
                                        v-for="feature in includedFeatures(index)"
                                        :key="feature"
                                        class="flex items-start text-[10px] leading-[15px] text-[#222]"
                                    >
                                        <img
                                            :src="featureCheckIcon(index)"
                                            class="vip-feature-icon mr-[7px] mt-[1px] shrink-0"
                                            alt=""
                                        />
                                        <span>{{ feature }}</span>
                                    </div>
                                </div>
                            </div>

                            <div
                                v-if="index === displayLevels.length - 1"
                                class="mt-[10px] rounded-[8px] border border-[#efc76a] bg-[#fff7df] px-[12px] py-[10px] text-center text-[10px] leading-[16px] text-[#7a4b00]"
                            >
                                {{
                                    $t("vip5_exclusive_desc", {
                                        level: highestLevelName,
                                    })
                                }}
                            </div>

                            <button
                                v-if="shouldShowLevelButton(item, index)"
                                class="vip-level-button mt-[12px] h-[36px] w-full rounded-[6px] text-[11px] font-semibold text-white"
                                :class="levelButtonClass(item, index)"
                                :disabled="isLevelButtonDisabled(item, index)"
                                type="button"
                                @click="handleLevelButtonClick(item, index)"
                            >
                                <template v-if="isCurrentLevel(item, index)">
                                    <span
                                        class="inline-flex items-center justify-center"
                                    >
                                        <img
                                            :src="vipIcons.currentLevel"
                                            class="mr-[6px] h-[12px] w-[12px] shrink-0"
                                            alt=""
                                        />
                                        {{ $t("your_current_level") }}
                                    </span>
                                </template>
                                <template v-else>
                                    {{
                                        $t("upgrade_to_level", {
                                            level: normalizeLevelName(
                                                item,
                                                index,
                                            ),
                                        })
                                    }}
                                    <span class="ml-[10px]">→</span>
                                </template>
                            </button>
                        </div>
                    </article>

                    <div
                        v-if="!displayLevels.length && loaded"
                        class="rounded-[10px] border border-[#c7ead0] bg-white px-[16px] py-[28px] text-center text-[13px] text-[#6b8b73]"
                    >
                        {{ $t("no_vip_level_data") }}
                    </div>
                </div>
            </section>

        </main>
    </div>
</template>

<script setup>
import { computed, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import { getLevel } from "@/api/apis";
import { useUserStore } from "@/store/modules/user";

const userStore = useUserStore();
const router = useRouter();
const { t } = useI18n();
const levelList = ref([]);
const loaded = ref(false);

const vipIcons = {
    crownLarge: new URL(
        "@/static/images/design/vip-crown-large.png",
        import.meta.url,
    ).href,
    crownSmall: new URL(
        "@/static/images/design/vip-crown-small.png",
        import.meta.url,
    ).href,
    rocket: new URL("@/static/images/design/vip-rocket.png", import.meta.url)
        .href,
    rocketf: new URL("@/static/images/design/vip-rocketf.png", import.meta.url)
        .href,
    check: new URL("@/static/images/design/vip-check.png", import.meta.url)
        .href,
    star: new URL("@/static/images/design/vip-star.png", import.meta.url).href,
    userbottom: new URL(
        "@/static/images/design/userbottom.png",
        import.meta.url,
    ).href,
    user: new URL("@/static/images/design/vip-user.png", import.meta.url).href,
    level1: new URL("@/static/images/design/vip-level-1.png", import.meta.url)
        .href,
    level2: new URL("@/static/images/design/vip-level-3.png", import.meta.url)
        .href,
    level3: new URL("@/static/images/design/vip-level-2.png", import.meta.url)
        .href,
    currentLevel: new URL(
        "@/static/images/design/vip-current-level-icon.png",
        import.meta.url,
    ).href,
    vip11: new URL("@/static/images/design/vip11.png", import.meta.url).href,
    vip12: new URL("@/static/images/design/vip12.png", import.meta.url).href,
    vip13: new URL("@/static/images/design/vip13.png", import.meta.url).href,
    vip14: new URL("@/static/images/design/vip14.png", import.meta.url).href,
    vip21: new URL("@/static/images/design/vip21.png", import.meta.url).href,
    vip22: new URL("@/static/images/design/vip22.png", import.meta.url).href,
    vip23: new URL("@/static/images/design/vip23.png", import.meta.url).href,
    vip24: new URL("@/static/images/design/vip24.png", import.meta.url).href,
    vip31: new URL("@/static/images/design/vip31.png", import.meta.url).href,
    vip32: new URL("@/static/images/design/vip32.png", import.meta.url).href,
    vip33: new URL("@/static/images/design/vip33.png", import.meta.url).href,
    vip34: new URL("@/static/images/design/vip34.png", import.meta.url).href,
    vipLevel4: new URL(
        "@/static/images/design/vip-level-4.png",
        import.meta.url,
    ).href,
    userFallback: new URL("@/static/images/userImg.png", import.meta.url).href,
};

const levelFallbacks = [
    { nameEn: "VIP1", commissionRatio: 0.5, orderCount: 80, price: 50 },
    { nameEn: "VIP2", commissionRatio: 1, orderCount: 90, price: 200 },
    { nameEn: "VIP3", commissionRatio: 1.5, orderCount: 100, price: 500 },
    { nameEn: "VIP4", commissionRatio: 2, orderCount: 110, price: 1500 },
    { nameEn: "VIP5", commissionRatio: 2.5, orderCount: 120, price: 5000 },
];

const featureGroups = computed(() => [
    [
        t("vip_feature_full_access"),
        t("vip_feature_premium_unlocked"),
        t("vip_feature_invite_team"),
        t("vip_feature_deposit_rebate"),
        t("vip_feature_optimized_income"),
    ],
    [
        t("vip_feature_all_vip1"),
        t("vip_feature_double_rebate"),
        t("vip_feature_priority_queue"),
        t("vip_feature_invite_team"),
        t("vip_feature_deposit_rebate"),
    ],
    [
        t("vip_feature_all_vip2"),
        t("vip_feature_high_value_tasks"),
        t("vip_feature_fast_withdrawal_2_days"),
        t("vip_feature_invite_team"),
        t("vip_feature_deposit_rebate"),
    ],
    [
        t("vip_feature_all_vip3"),
        t("vip_feature_account_manager"),
        t("vip_feature_one_day_withdrawal"),
        t("vip_feature_vip4_pools"),
        t("vip_feature_deposit_rebate"),
    ],
    [
        t("vip_feature_all_vip4"),
        t("vip_feature_highest_rebate"),
        t("vip_feature_same_day_withdrawal"),
        t("vip_feature_top_support"),
        t("vip_feature_vip5_pools"),
    ],
]);

const themes = [
    {
        headClass: "bg-gradient-to-br from-[#2ec363] to-[#0a8934]",
        borderClass: "border-[#159947]",
        headFrom: "#2ec363",
        headTo: "#0a8934",
        borderColor: "#159947",
        statColor: "#19a653",
        statTextClass: "text-[#159947]",
        buttonClass: "vip-level-button--theme",
        iconFilter: "none",
    },
    {
        headClass: "bg-gradient-to-br from-[#62bbea] to-[#2787d7]",
        borderClass: "border-[#2787d7]",
        headFrom: "#62bbea",
        headTo: "#2787d7",
        borderColor: "#2787d7",
        statColor: "#349be0",
        statTextClass: "text-[#349be0]",
        buttonClass: "vip-level-button--theme",
        iconFilter: "none",
    },
    {
        headClass: "bg-gradient-to-br from-[#ffb338] to-[#ff9719]",
        borderClass: "border-[#ff9e2c]",
        headFrom: "#ffb338",
        headTo: "#ff9719",
        borderColor: "#ff9e2c",
        statColor: "#f29a21",
        statTextClass: "text-[#f29a21]",
        buttonClass: "vip-level-button--theme",
        iconFilter: "none",
    },
    {
        headClass: "bg-gradient-to-br from-[#ff6656] to-[#dd3426]",
        borderClass: "border-[#dd3426]",
        headFrom: "#ff6656",
        headTo: "#dd3426",
        borderColor: "#dd3426",
        statColor: "#ef4b3d",
        statTextClass: "text-[#ef4b3d]",
        buttonClass: "vip-level-button--theme",
        iconFilter: "none",
    },
    {
        headClass: "bg-gradient-to-br from-[#8c55ff] to-[#6f39dc]",
        borderClass: "border-[#7340df]",
        headFrom: "#8c55ff",
        headTo: "#6f39dc",
        borderColor: "#7340df",
        statColor: "#7a48e7",
        statTextClass: "text-[#7a48e7]",
        buttonClass: "vip-level-button--theme",
        iconFilter: "hue-rotate(20deg) saturate(1.1) brightness(1.02)",
    },
];

const currentLevelName = computed(() => {
    return (
        userStore.userInfo?.userLevel?.nameEn ||
        userStore.userInfo?.levelName ||
        "VIP1"
    );
});

const userAvatar = computed(
    () => userStore.userInfo?.avatar || vipIcons.userFallback,
);

const currentLevelId = computed(() => userStore.userInfo?.levelId);

const hasCurrentLevel = computed(() =>
    Boolean(
        currentLevelId.value ||
        userStore.userInfo?.userLevel?.nameEn ||
        userStore.userInfo?.levelName,
    ),
);

const displayLevels = computed(() =>
    levelList.value.length ? levelList.value : levelFallbacks,
);

const currentLevelNumber = computed(() =>
    getLevelNumericValue(currentLevelName.value),
);

const currentLevelIdNumber = computed(() => {
    const value = Number(currentLevelId.value);
    return Number.isNaN(value) ? 0 : value;
});

const highestDisplayLevelNumber = computed(() => {
    const levels = displayLevels.value || [];
    const numbers = levels
        .map((item, index) =>
            getLevelNumericValue(normalizeLevelName(item, index)),
        )
        .filter((num) => num > 0);

    if (!numbers.length) return levels.length;
    return Math.max(...numbers);
});

const highestDisplayLevelId = computed(() => {
    const ids = (displayLevels.value || [])
        .map((item) => Number(item?.id))
        .filter((id) => !Number.isNaN(id) && id > 0);

    return ids.length ? Math.max(...ids) : 0;
});

const isCurrentLevelIdAboveDisplay = computed(() => {
    if (!currentLevelIdNumber.value) return false;
    if (!highestDisplayLevelId.value) return false;

    return currentLevelIdNumber.value > highestDisplayLevelId.value;
});

const isCurrentLevelNumberAboveDisplay = computed(() => {
    if (!currentLevelNumber.value) return false;
    if (!highestDisplayLevelNumber.value) return false;

    return currentLevelNumber.value > highestDisplayLevelNumber.value;
});

const isCurrentLevelAboveDisplay = computed(() => {
    if (!hasCurrentLevel.value) return false;
    if (!displayLevels.value.length) return false;

    return (
        isCurrentLevelIdAboveDisplay.value ||
        isCurrentLevelNumberAboveDisplay.value
    );
});

const matchedCurrentLevelIndex = computed(() => {
    const levels = displayLevels.value || [];

    if (isCurrentLevelAboveDisplay.value) {
        return -1;
    }

    const byIdIndex = levels.findIndex(
        (item) =>
            currentLevelId.value &&
            item?.id &&
            String(currentLevelId.value) === String(item.id),
    );
    if (byIdIndex >= 0) return byIdIndex;

    if (currentLevelNumber.value > 0) {
        return levels.findIndex(
            (item, index) =>
                getLevelNumericValue(normalizeLevelName(item, index)) ===
                currentLevelNumber.value,
        );
    }

    return -1;
});

const currentLevelIndex = computed(() => {
    if (isCurrentLevelAboveDisplay.value) {
        return displayLevels.value.length;
    }

    if (matchedCurrentLevelIndex.value >= 0) {
        return matchedCurrentLevelIndex.value;
    }

    if (currentLevelNumber.value > 0) {
        return currentLevelNumber.value - 1;
    }

    return 0;
});

const highestLevelIndex = computed(() =>
    Math.max(displayLevels.value.length - 1, 0),
);

const highestLevelName = computed(() => {
    const index = highestLevelIndex.value;
    return normalizeLevelName(displayLevels.value[index], index);
});

const isCurrentHighestLevel = computed(() => {
    if (!hasCurrentLevel.value) return false;
    if (isCurrentLevelAboveDisplay.value) return true;

    return currentLevelIndex.value >= highestLevelIndex.value;
});

const showVipUpgradeCard = computed(
    () => displayLevels.value.length > 0 && !isCurrentHighestLevel.value,
);

const vipLevelIconSets = [
    {
        medal: vipIcons.level2,
        stats: [vipIcons.vip12, vipIcons.vip13, vipIcons.vip14],
        check: vipIcons.vip11,
    },
    {
        medal: vipIcons.level3,
        stats: [vipIcons.vip22, vipIcons.vip23, vipIcons.vip24],
        check: vipIcons.vip21,
    },
    {
        medal: vipIcons.level1,
        stats: [vipIcons.vip12, vipIcons.vip13, vipIcons.vip14],
        check: vipIcons.vip11,
    },
    {
        medal: vipIcons.vipLevel4,
        stats: [vipIcons.vip32, vipIcons.vip33, vipIcons.vip34],
        check: vipIcons.vip31,
    },
    {
        medal: vipIcons.crownLarge,
        stats: [vipIcons.vip32, vipIcons.vip33, vipIcons.vip34],
        check: vipIcons.vip31,
    },
];

function normalizeLevelName(item, index) {
    return item?.nameEn || item?.name || `VIP${index + 1}`;
}

function getLevelNumericValue(value) {
    const match = String(value || "").match(/\d+/);
    return match ? Number(match[0]) : 0;
}

function shouldShowLevelButton() {
    return true;
}

function isLevelButtonDisabled(item, index) {
    if (isCurrentLevel(item, index)) return true;
    if (isCurrentLevelAboveDisplay.value) return true;

    return index <= currentLevelIndex.value;
}

function levelButtonClass(item, index) {
    if (isCurrentLevel(item, index)) {
        return "vip-level-button--current";
    }

    if (isLevelButtonDisabled(item, index)) {
        return "vip-level-button--disabled";
    }

    return cardTheme(item, index).buttonClass;
}

function handleLevelButtonClick(item, index) {
    if (isLevelButtonDisabled(item, index)) return;

    goDeposit();
}

function goDeposit() {
    router.push({ path: "/deposit" });
}

function isCurrentLevel(item, index) {
    if (!hasCurrentLevel.value) return false;
    if (isCurrentLevelAboveDisplay.value) return false;

    if (currentLevelId.value && item?.id) {
        return String(currentLevelId.value) === String(item.id);
    }

    return index === currentLevelIndex.value;
}

function formatRate(item) {
    const value = item?.commissionRatio ?? item?.rebateRatio ?? item?.rate ?? 0;
    const numeric = Number(value);
    if (Number.isNaN(numeric)) return `${value}`;
    return `${numeric}%`;
}

function formatTaskCount(item, index) {
    return (
        item?.orderCount ??
        item?.taskCount ??
        item?.maxOrderCount ??
        80 + index * 10
    );
}

function formatProductCount(item, index) {
    return (
        item?.productCount ??
        item?.goodsCount ??
        item?.incomeCount ??
        40 + index * 5
    );
}

function formatDeposit(item, index) {
    return item?.price ?? item?.minDeposit ?? levelFallbacks[index]?.price ?? 0;
}

function vipSubtitle(item, index) {
    return `${t("min_deposit")}:$${formatDeposit(item, index)}`;
}

function cardTheme(item, index) {
    const levelNumber = getLevelNumericValue(normalizeLevelName(item, index));

    if (levelNumber > 0 && themes[levelNumber - 1]) {
        return themes[levelNumber - 1];
    }

    return themes[index] || themes[themes.length - 1];
}

function cardThemeStyle(item, index) {
    const theme = cardTheme(item, index);

    return {
        "--vip-head-from": theme.headFrom,
        "--vip-head-to": theme.headTo,
        "--vip-card-border": theme.borderColor,
        "--vip-card-accent": theme.statColor,
        "--vip-card-icon-filter": theme.iconFilter || "none",
    };
}

function vipCardBorderClass(item, index) {
    return [
        cardTheme(item, index).borderClass,
        isCurrentLevel(item, index) ? "vip-card--current" : "",
    ];
}

function getVipIconSet(item, index) {
    const numericLevel = Math.max(
        getLevelNumericValue(normalizeLevelName(item, index)) - 1,
        0,
    );
    return (
        vipLevelIconSets[numericLevel] ||
        vipLevelIconSets[index] ||
        vipLevelIconSets[vipLevelIconSets.length - 1]
    );
}

function medalIcon(item, index) {
    return getVipIconSet(item, index)?.medal || vipIcons.crownSmall;
}

function featureCheckIcon(index) {
    return (
        getVipIconSet(displayLevels.value[index], index)?.check ||
        vipIcons.check
    );
}

function includedFeatures(index) {
    const taskCount = formatTaskCount(displayLevels.value[index], index);
    return [
        ...(featureGroups.value[index] || featureGroups.value[0]),
        t("daily_task_submission_quota", { count: taskCount }),
    ];
}

function levelStats(item, index) {
    const iconSet = getVipIconSet(item, index);
    return [
        {
            icon: iconSet?.stats?.[0] || vipIcons.star,
            value: formatRate(item),
            label: t("rebate_task"),
        },
        {
            icon: iconSet?.stats?.[1] || vipIcons.rocket,
            value: `$ ${formatProductCount(item, index)}`,
            label: t("product_income"),
        },
        {
            icon: iconSet?.stats?.[2] || vipIcons.user,
            value: formatTaskCount(item, index),
            label: t("daily_tasks"),
        },
    ];
}

async function loadLevels() {
    loaded.value = false;
    try {
        const res = await getLevel();
        levelList.value = Array.isArray(res?.data) ? res.data : [];
    } finally {
        loaded.value = true;
    }
}

onMounted(() => {
    if (userStore.token) {
        userStore.getUserInfo();
    }
    loadLevels();
});
</script>

<style scoped>
.vip-page {
    font-family: "Montserrat", "Poppins", sans-serif;
    width: 100%;
    overflow-x: hidden;
    background: #f2f4f8;
    color: #111;
}

.vip-showcase {
    position: relative;
    padding-bottom: 10px;
}

.vip-showcase__top {
    position: relative;
    height: 78px;
    overflow: hidden;
    background:
        radial-gradient(circle at 72% -10%, rgba(74, 134, 255, 0.3) 0, rgba(74, 134, 255, 0.3) 34px, transparent 35px),
        linear-gradient(180deg, #191919 0%, #111111 100%);
}

.vip-showcase__line {
    position: absolute;
    border-radius: 999px;
    opacity: 0.95;
}

.vip-showcase__line--one {
    top: -8px;
    left: 58px;
    width: 252px;
    height: 84px;
    background:
        linear-gradient(145deg, transparent 0 34%, #ffffff 34% 36%, transparent 36% 40%, #ff315e 40% 43%, transparent 43% 56%, #245df0 56% 58%, transparent 58%),
        linear-gradient(165deg, transparent 0 42%, #ffffff 42% 44%, transparent 44% 49%, #245df0 49% 51%, transparent 51% 56%, #ff315e 56% 58%, transparent 58%);
    transform: rotate(-7deg);
}

.vip-showcase__line--two {
    top: 10px;
    right: -28px;
    width: 138px;
    height: 52px;
    background:
        linear-gradient(160deg, transparent 0 22%, #245df0 22% 24%, transparent 24% 29%, #ff315e 29% 32%, transparent 32% 46%, #ffffff 46% 48%, transparent 48%);
    transform: rotate(11deg);
}

.vip-showcase__title {
    position: absolute;
    left: 50%;
    bottom: 12px;
    transform: translateX(-50%);
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 0.3px;
}

.vip-showcase__card {
    position: relative;
    margin: 0 14px;
    margin-top: -2px;
    padding: 18px 18px 16px;
    border-radius: 0;
    background: linear-gradient(135deg, #4d93ff 0%, #2b63ee 100%);
    text-align: center;
    color: #fff;
    box-shadow: none;
}

.vip-showcase__card::after {
    content: "";
    position: absolute;
    right: -20px;
    top: -20px;
    width: 104px;
    height: 104px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.08);
}

.vip-showcase__avatar-shell {
    width: 92px;
    height: 92px;
    margin: 0 auto;
    border-radius: 50%;
    overflow: hidden;
    border: 6px solid rgba(255, 255, 255, 0.22);
    box-shadow: 0 10px 18px rgba(0, 0, 0, 0.14);
}

.vip-showcase__avatar {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.vip-showcase__badge {
    position: absolute;
    top: 26px;
    right: 18px;
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: transparent;
    display: flex;
    align-items: center;
    justify-content: center;
}

.vip-showcase__badge img {
    width: 48px;
    height: 48px;
    object-fit: contain;
}

.vip-showcase__name {
    position: relative;
    z-index: 1;
    margin-top: 12px;
    font-size: 22px;
    font-weight: 700;
    line-height: 28px;
}

.vip-showcase__level {
    position: relative;
    z-index: 1;
    margin-top: 8px;
    color: rgba(255, 255, 255, 0.94);
    font-size: 12px;
    line-height: 18px;
}

.vip-showcase__desc {
    position: relative;
    z-index: 1;
    margin: 16px auto 0;
    max-width: 330px;
    color: rgba(255, 255, 255, 0.86);
    font-size: 10px;
    line-height: 18px;
    font-weight: 500;
}

.vip-section-title {
    display: flex;
    align-items: center;
    color: #404b60;
    font-size: 13px;
    line-height: 18px;
    font-weight: 700;
}

.vip-bubble,
.vip-card-bubble {
    position: absolute;
    border-radius: 9999px;
    background: rgba(255, 255, 255, 0.08);
}

.vip-bubble--top {
    right: -22px;
    top: -43px;
    height: 128px;
    width: 128px;
}

.vip-bubble--bottom {
    bottom: -28px;
    left: -28px;
    height: 86px;
    width: 86px;
}

.vip-bubble--upgrade {
    right: -26px;
    top: -40px;
    height: 104px;
    width: 104px;
}

.benefit-row {
    display: flex;
    align-items: flex-start;
    padding: 4px 0;
}

.benefit-row + .benefit-row {
    margin-top: 6px;
}

.benefit-icon {
    margin-right: 10px;
    display: flex;
    height: 34px;
    width: 34px;
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    background: #eef8f1;
}

.benefit-icon img {
    object-fit: contain;
}

.vip-card {
    border-width: 0;
    border-radius: 8px;
    border-color: transparent;
    box-shadow: 0 10px 24px rgba(31, 41, 55, 0.08);
}

.vip-card--current {
    box-shadow:
        0 10px 24px rgba(31, 41, 55, 0.08),
        0 0 0 2px rgba(255, 255, 255, 0.9);
}

.vip-card-head {
    min-height: 146px;
    background: linear-gradient(
        135deg,
        var(--vip-head-from, #2ec363),
        var(--vip-head-to, #0a8934)
    ) !important;
}

.vip-card-bubble {
    right: -16px;
    top: -16px;
    height: 86px;
    width: 86px;
}

.vip-medal {
    position: relative;
    display: flex;
    height: 38px;
    width: 38px;
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.2);
    box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.18);
}

.vip-medal-num {
    position: absolute;
    bottom: 6px;
    left: 50%;
    min-width: 14px;
    transform: translateX(-50%);
    border-radius: 999px;
    background: rgba(150, 99, 35, 0.72);
    padding: 1px 4px;
    font-size: 8px;
    font-weight: 700;
    line-height: 10px;
}

.vip-head-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
    margin-top: 16px;
}

.vip-head-stat {
    text-align: left;
}

.vip-head-stat__label {
    color: rgba(255, 255, 255, 0.88);
    font-size: 9px;
    line-height: 13px;
}

.vip-head-stat__value {
    margin-top: 3px;
    color: #fff;
    font-size: 20px;
    line-height: 24px;
    font-weight: 700;
}

.vip-card-body {
    padding: 0 0 12px;
}

.vip-feature-panel {
    border-radius: 7px;
    background: #fff;
    margin: 0 16px;
    margin-top: -8px;
    box-shadow: inset 0 0 0 1px #edf1f6;
    padding: 14px 12px;
}

.vip-upgrade-card {
    min-height: 212px;
    border-radius: 10px;
}

.vip-medal-img {
    width: 26px;
    height: 26px;
    object-fit: contain;
    display: block;
    filter: var(--vip-card-icon-filter, none);
}

.vip-feature-icon {
    width: 12px;
    height: 12px;
    object-fit: contain;
    filter: var(--vip-card-icon-filter, none);
}

.vip-level-button {
    margin-left: 16px !important;
    margin-right: 16px !important;
    width: calc(100% - 32px) !important;
}

.vip-level-button--current {
    border: 1px solid rgba(33, 130, 59, 0.28);
    background: linear-gradient(180deg, #f4fff7 0%, #ebfff2 100%) !important;
    color: #219644 !important;
}

.vip-level-button--theme {
    background: linear-gradient(
        135deg,
        var(--vip-head-from, var(--theme-primary)),
        var(--vip-head-to, var(--theme-primary))
    );
}

.vip-level-button:disabled {
    cursor: not-allowed;
    pointer-events: none;
}

.vip-level-button--disabled {
    border: 1px solid rgba(148, 163, 184, 0.24);
    background: linear-gradient(180deg, #f8fafc 0%, #eff3f9 100%) !important;
    color: #7b8494 !important;
    opacity: 0.72;
}

.upgrade-cta {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
}

.upgrade-cta__icon {
    width: 18px;
    height: 18px;
    border-radius: 6px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.upgrade-cta__icon-img {
    width: 12px;
    height: 12px;
    object-fit: contain;
    display: block;
}

.upgrade-cta__icon-inner {
    color: #178c3c;
    font-size: 14px;
    line-height: 1;
    font-weight: 700;
}
</style>
