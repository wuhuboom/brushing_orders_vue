<template>
    <div
        class="auth-shell auth-shell--login-page"
        :class="`auth-shell--lang-${currentLang.code}`"
    >
        <div class="auth-hero auth-hero--login">
            <img
                class="auth-hero__image"
                src="@/static/images/auth/auth-hero.png"
                alt=""
            />
            <div class="auth-lang" @click="handleChangeLang">
                <span class="auth-lang__globe"></span>
                <span class="auth-lang__flag">{{ currentLang.flag }}</span>
                <span class="auth-lang__text">{{ currentLang.name }}</span>
                <span class="auth-lang__arrow"></span>
            </div>
            <div class="auth-brand">
                <img src="@/static/images/logo.png" alt="" />
            </div>
        </div>

        <div class="auth-card auth-card--login">
            <el-form
                ref="ruleFormRef"
                :model="ruleForm"
                status-icon
                :rules="rules"
                label-width="0"
                class="auth-form"
            >
                <div class="auth-field">
                    <div class="auth-field__label">
                        {{ $t("username_phone") }}<span>*</span>
                    </div>
                    <el-form-item prop="">
                        <div class="auth-input">
                            <el-input
                                v-model.trim="ruleForm.username"
                                type="text"
                                :placeholder="$t('username_phone')"
                                autocomplete="off"
                                size="large"
                            />
                        </div>
                    </el-form-item>
                </div>

                <div class="auth-field">
                    <div class="auth-field__label">
                        {{ $t("password") }}<span>*</span>
                    </div>
                    <el-form-item prop="">
                        <div class="auth-input">
                            <el-input
                                v-model="ruleForm.password"
                                :placeholder="$t('password')"
                                :type="showPassword ? 'text' : 'password'"
                                autocomplete="off"
                                size="large"
                            >
                                <template #suffix>
                                    <el-icon
                                        class="auth-eye-icon"
                                        @click.stop="showPassword = !showPassword"
                                    >
                                        <Hide v-if="showPassword" />
                                        <View v-else />
                                    </el-icon>
                                </template>
                            </el-input>
                        </div>
                    </el-form-item>
                </div>
            </el-form>

            <div class="auth-meta auth-meta--login">
                <label class="auth-check">
                    <input v-model="rememberMe" type="checkbox" />
                    <span class="auth-check__box"></span>
                    <span>Remember me</span>
                </label>
                <span class="auth-meta__link">
                    {{ $t("forgot_password_question") }}
                </span>
            </div>

            <div
                class="auth-submit"
                :class="{ 'auth-submit--disabled': !isLoginReady || isSubmitting }"
                :aria-disabled="!isLoginReady || isSubmitting"
                @click="submitForm(ruleFormRef)"
            >
                {{ $t("log_in") }}
            </div>

            <div class="auth-footer">
                <span class="auth-footer__muted">{{
                    $t("don_t_have_an_account")
                }}</span>
                <span class="auth-footer__link" @click="toRegister">
                    {{ $t("register_now") }}
                </span>
            </div>

            <div class="auth-footer auth-footer--help">
                <span class="auth-footer__muted">{{ $t("need_help") }}</span>
                <span class="auth-footer__link" @click="customer">
                    {{ $t("need_help_desc") }}
                </span>
            </div>

            <div class="auth-copyright">
                Copyright © 2025 ALGOFY Company.<br />
                All Rights Reserved.
            </div>
        </div>

        <Lang ref="langRef"></Lang>
        <AppLoadingScreen :visible="isSubmitting || isCustomerLoading" />
    </div>
</template>

<script setup>
import AppLoadingScreen from "@/components/AppLoadingScreen.vue";
import Lang from "@/components/Lang.vue";
import { Hide, View } from "@element-plus/icons-vue";
import { computed, reactive, ref } from "vue";
import { showFailToast, showToast } from "@/util/message";
import { useCommonStore } from "@/store/modules/common";
import { useRouter } from "vue-router";
import { useI18n } from "vue-i18n";
import { login, getTradeConfig } from "../../api/apis";
import { checkWorkTimeLocal } from "../../util/utils";
import { useUserStore } from "@/store/modules/user";
import { LANGS } from "@/config/lang";

const router = useRouter();
const { t } = useI18n();
const ruleFormRef = ref(null);
const userStore = useUserStore();
const langRef = ref(null);
const switchLeaving = ref(false);
const showPassword = ref(false);
const isSubmitting = ref(false);
const isCustomerLoading = ref(false);
const rememberMe = ref(false);
const ruleForm = reactive({
    email: "",
    password: "",
    username: "",
});
const commonStore = useCommonStore();
const rules = computed(() => {
    return {};
});
const currentLang = computed(() => LANGS[commonStore.lang] || LANGS.en);
const isLoginReady = computed(() => Boolean(ruleForm.username && ruleForm.password));

function toRegister() {
    if (switchLeaving.value) return;
    switchLeaving.value = true;
    window.setTimeout(() => {
        router.push({ path: "/account/register" });
    }, 180);
}

function submitForm(formEl) {
    if (isSubmitting.value || !isLoginReady.value) return;
    formEl.validate((valid) => {
        if (valid) {
            const data = {
                username: ruleForm.username,
                password: ruleForm.password,
            };
            isSubmitting.value = true;
            login(data)
                .then((res) => {
                    userStore.setToken(`Bearer ${res.data.token}`);
                    userStore.setUserInfo(res.data.info);
                    return router.push({ path: "/" });
                })
                .catch((err) => {
                    showFailToast(err?.msg || err?.message || t("network_error"));
                })
                .finally(() => {
                    isSubmitting.value = false;
                });
        }
    });
}

function handleChangeLang() {
    langRef.value.open();
}

const TradeInfor = ref({});
const tradeConfig = async () => {
    const res = await getTradeConfig();
    TradeInfor.value = res.data || {};
    return TradeInfor.value;
};

const ensureTradeConfig = async () => {
    return tradeConfig();
};

const showSupportHoursToast = () => {
    showToast({
        content: t("supportHours"),
        key: "customer-support-hours",
    });
};

const customer = async () => {
    if (isCustomerLoading.value) return;

    isCustomerLoading.value = true;
    try {
        const tradeInfo = await ensureTradeConfig();

        if (tradeInfo?.workTimeStart && tradeInfo?.workTimeEnd) {
            const time = checkWorkTimeLocal(
                tradeInfo.workTimeStart,
                tradeInfo.workTimeEnd,
                userStore.zoneActive?.tzName,
            );

            if (!time) {
                showSupportHoursToast();
                return;
            }
        }

        await router.push({
            path: "/customer",
        });
    } catch (error) {
        showToast(error?.msg || error?.message || t("network_error"));
    } finally {
        isCustomerLoading.value = false;
    }
};
</script>

<style scoped>
.auth-shell {
    min-height: 100vh;
    background: #161616;
    position: relative;
    overflow: hidden;
    color: #ffffff;
}

.auth-hero {
    position: relative;
    height: 280px;
}

.auth-hero__image {
    width: 100%;
    height: 280px;
    object-fit: cover;
    display: block;
    opacity: 0.92;
}

.auth-lang {
    position: absolute;
    top: 18px;
    right: 18px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 34px;
    min-width: 118px;
    padding: 0 10px;
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.08);
    color: #f3f5fb;
    font-size: 12px;
    font-weight: 600;
    z-index: 2;
}

.auth-lang__globe {
    width: 20px;
    height: 20px;
    flex: 0 0 20px;
    background: url("@/static/images/lang/globe.png") center / contain no-repeat;
    font-size: 0;
    line-height: 0;
}

.auth-lang__flag {
    width: 20px;
    height: 14px;
    border-radius: 2px;
    overflow: hidden;
    background: center / contain no-repeat;
    box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.12);
    flex: 0 0 20px;
    font-size: 0;
    line-height: 0;
}

.auth-shell--lang-en .auth-lang__flag {
    background-image: url("@/static/images/lang/en.png");
}

.auth-shell--lang-zh .auth-lang__flag {
    background-image: url("@/static/images/lang/zh.png");
}

.auth-shell--lang-id .auth-lang__flag {
    background-image: url("@/static/images/lang/id.png");
}

.auth-shell--lang-th .auth-lang__flag {
    background-image: url("@/static/images/lang/th.png");
}

.auth-shell--lang-ko .auth-lang__flag {
    background:
        radial-gradient(
            circle at 50% 50%,
            #d83b3b 0 3px,
            #2462b8 3px 6px,
            transparent 6px
        ),
        #ffffff;
}

.auth-lang__text {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.auth-lang__arrow {
    width: 8px;
    height: 8px;
    flex: 0 0 8px;
    margin-left: 1px;
    border-right: 2px solid rgba(255, 255, 255, 0.76);
    border-bottom: 2px solid rgba(255, 255, 255, 0.76);
    transform: rotate(45deg) translateY(-2px);
}

.auth-brand {
    position: absolute;
    left: 50%;
    top: 88px;
    transform: translateX(-50%);
    width: 220px;
    z-index: 1;
}

.auth-brand img {
    display: block;
    width: 100%;
    object-fit: contain;
}

.auth-card {
    position: relative;
    margin: -2px 20px 0;
    padding: 0 0 36px;
}

.auth-card--login {
    min-height: calc(100vh - 278px);
}

.auth-form :deep(.el-form-item) {
    margin-bottom: 0;
}

.auth-form :deep(.el-form-item__content) {
    line-height: normal;
}

.auth-field + .auth-field {
    margin-top: 22px;
}

.auth-field__label {
    margin-bottom: 10px;
    color: #dde1ef;
    font-size: 16px;
    line-height: 22px;
}

.auth-field__label span {
    color: #ff2c2c;
}

.auth-input {
    display: flex;
    align-items: center;
    width: 100%;
    height: 58px;
    padding: 0 18px;
    border: 1px solid #c9d0df;
    border-radius: 16px;
    background: #fff;
    overflow: hidden;
}

.auth-input :deep(.el-input) {
    flex: 1;
    min-width: 0;
}

.auth-input :deep(.el-input__wrapper) {
    box-shadow: none !important;
    padding: 0 !important;
    background: transparent !important;
    border: 0 !important;
    border-radius: 0 !important;
}

.auth-input :deep(.el-input__inner) {
    height: 56px;
    font-size: 18px;
    color: #1a1f29;
    border: 0 !important;
    background: transparent !important;
    box-shadow: none !important;
    outline: none !important;
}

.auth-input :deep(.el-input__inner::placeholder) {
    color: #b4bac8;
}

.auth-input :deep(.el-input__wrapper.is-focus) {
    box-shadow: none !important;
}

.auth-input :deep(.el-input__suffix),
.auth-input :deep(.el-input__prefix) {
    display: flex;
    align-items: center;
}

.auth-input :deep(.el-input__suffix-inner) {
    color: #6d7482;
}

.auth-eye-icon {
    font-size: 18px;
    color: #6d7482;
    cursor: pointer;
}

.auth-meta,
.auth-footer {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    gap: 6px;
    font-size: 14px;
    line-height: 20px;
}

.auth-meta {
    margin: 26px 0 24px;
    justify-content: space-between;
}

.auth-footer {
    margin-top: 22px;
}

.auth-meta__muted,
.auth-footer__muted {
    color: #d8dcea;
}

.auth-meta__link,
.auth-footer__link {
    color: #6d84ff;
}

.auth-check {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    color: #d8dcea;
    font-size: 14px;
}

.auth-check input {
    position: absolute;
    opacity: 0;
    pointer-events: none;
}

.auth-check__box {
    width: 22px;
    height: 22px;
    border: 2px solid #dde1ef;
    border-radius: 6px;
    background: transparent;
    box-sizing: border-box;
    position: relative;
}

.auth-check input:checked + .auth-check__box::after {
    content: "";
    position: absolute;
    left: 5px;
    top: 1px;
    width: 7px;
    height: 12px;
    border-right: 2px solid #506eff;
    border-bottom: 2px solid #506eff;
    transform: rotate(40deg);
}

.auth-submit {
    height: 60px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3552ea;
    color: #fff;
    font-size: 18px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
}

.auth-submit--disabled {
    pointer-events: none;
    cursor: not-allowed;
    background: rgba(53, 82, 234, 0.4);
    color: #ffffff;
    opacity: 1;
}

.auth-copyright {
    margin-top: 210px;
    color: rgba(216, 220, 234, 0.42);
    font-size: 12px;
    line-height: 20px;
    text-align: center;
}
</style>
