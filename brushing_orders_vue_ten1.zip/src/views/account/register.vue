<template>
    <div
        class="auth-shell auth-shell--register"
        :class="`auth-shell--lang-${currentLang.code}`"
    >
        <div class="auth-hero auth-hero--register">
            <img
                class="auth-hero__image"
                src="@/static/images/auth/auth-hero.png"
                alt=""
            />
            <button class="auth-back" type="button" @click="toLogin">
                <van-icon name="arrow-left" size="28" color="#ffffff" />
            </button>
            <div class="auth-register-title">{{ $t("register") }}</div>
            <div class="auth-lang" @click="handleChangeLang">
                <span class="auth-lang__globe"></span>
                <span class="auth-lang__flag">{{ currentLang.flag }}</span>
                <span class="auth-lang__text">{{ currentLang.name }}</span>
                <span class="auth-lang__arrow"></span>
            </div>
        </div>

        <div class="auth-card auth-card--register">
            <el-form
                ref="ruleFormRef"
                :model="ruleForm"
                status-icon
                :rules="rules"
                label-width="0"
                class="auth-form"
            >
                <div class="auth-field">
                    <div class="auth-field__label">
                        {{ $t("username") }}<span>*</span>
                    </div>
                    <el-form-item prop="username">
                        <div class="auth-input">
                            <el-input
                                v-model="ruleForm.username"
                                :placeholder="$t('username')"
                                type="text"
                                autocomplete="off"
                                size="large"
                                @input="onUsernameInput"
                            />
                        </div>
                    </el-form-item>
                </div>

                <div v-if="isNeedPhone" class="auth-field">
                    <div class="auth-field__label">
                        {{ $t("phone_number") }}<span>*</span>
                    </div>
                    <el-form-item prop="phone">
                        <div class="auth-input">
                            <el-input
                                v-model="ruleForm.phone"
                                :placeholder="$t('phone_number')"
                                type="text"
                                autocomplete="off"
                                size="large"
                                @input="onPhoneInput"
                            />
                        </div>
                    </el-form-item>
                </div>

                <div class="auth-field">
                    <div class="auth-field__label">
                        {{ $t("select") }}<span>*</span>
                    </div>
                    <div class="auth-gender-select">
                        <button
                            type="button"
                            class="auth-gender-select__trigger"
                            :class="{
                                'auth-gender-select__trigger--placeholder':
                                    !ruleForm.sex,
                            }"
                            @click="toggleGenderMenu"
                        >
                            <span class="auth-gender-select__value">
                                <span class="auth-gender-emoji">
                                    {{ genderEmoji }}
                                </span>
                                <span>{{ genderLabel }}</span>
                            </span>
                            <span
                                class="auth-gender-select__arrow"
                                :class="{
                                    'auth-gender-select__arrow--open':
                                        genderMenuOpen,
                                }"
                            ></span>
                        </button>

                        <div
                            v-show="genderMenuOpen"
                            class="auth-gender-select__menu"
                        >
                            <button
                                type="button"
                                class="auth-gender-select__option"
                                :class="{
                                    'auth-gender-select__option--active':
                                        ruleForm.sex === 1,
                                }"
                                @click="selectGender(1)"
                            >
                                <span class="auth-gender-select__value">
                                    <span class="auth-gender-emoji">M</span>
                                    <span>{{ $t("male") }}</span>
                                </span>
                                <span
                                    v-if="ruleForm.sex === 1"
                                    class="auth-gender-select__check"
                                >
                                    OK
                                </span>
                            </button>
                            <button
                                type="button"
                                class="auth-gender-select__option"
                                :class="{
                                    'auth-gender-select__option--active':
                                        ruleForm.sex === 2,
                                }"
                                @click="selectGender(2)"
                            >
                                <span class="auth-gender-select__value">
                                    <span class="auth-gender-emoji">F</span>
                                    <span>{{ $t("female") }}</span>
                                </span>
                                <span
                                    v-if="ruleForm.sex === 2"
                                    class="auth-gender-select__check"
                                >
                                    OK
                                </span>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="auth-field">
                    <div class="auth-field__label">
                        {{ $t("transaction_password") }}<span>*</span>
                    </div>
                    <el-form-item prop="tradePassword">
                        <div class="auth-input">
                            <el-input
                                v-model="ruleForm.tradePassword"
                                :placeholder="$t('transaction_password')"
                                :type="showTradePassword ? 'text' : 'password'"
                                maxlength="6"
                                autocomplete="off"
                                size="large"
                                @input="
                                    ruleForm.tradePassword =
                                        ruleForm.tradePassword.replace(
                                            /\D/g,
                                            '',
                                        )
                                "
                            >
                                <template #suffix>
                                    <el-icon
                                        class="auth-eye-icon"
                                        @click.stop="
                                            showTradePassword =
                                                !showTradePassword
                                        "
                                    >
                                        <Hide v-if="showTradePassword" />
                                        <View v-else />
                                    </el-icon>
                                </template>
                            </el-input>
                        </div>
                    </el-form-item>
                </div>

                <div class="auth-field">
                    <div class="auth-field__label">
                        {{ $t("password") }}<span>*</span>
                    </div>
                    <el-form-item prop="password">
                        <div class="auth-input">
                            <el-input
                                v-model="ruleForm.password"
                                :placeholder="$t('password')"
                                :type="showPassword ? 'text' : 'password'"
                                autocomplete="off"
                                size="large"
                            >
                                <template #suffix>
                                    <el-icon
                                        class="auth-eye-icon"
                                        @click.stop="
                                            showPassword = !showPassword
                                        "
                                    >
                                        <Hide v-if="showPassword" />
                                        <View v-else />
                                    </el-icon>
                                </template>
                            </el-input>
                        </div>
                    </el-form-item>
                </div>

                <div class="auth-field">
                    <div class="auth-field__label">
                        {{ $t("confirm_password") }}<span>*</span>
                    </div>
                    <el-form-item prop="agentPassword">
                        <div class="auth-input">
                            <el-input
                                v-model="agentPassword"
                                :placeholder="$t('confirm_password')"
                                :type="
                                    showConfirmPassword ? 'text' : 'password'
                                "
                                autocomplete="off"
                                size="large"
                            >
                                <template #suffix>
                                    <el-icon
                                        class="auth-eye-icon"
                                        @click.stop="
                                            showConfirmPassword =
                                                !showConfirmPassword
                                        "
                                    >
                                        <Hide v-if="showConfirmPassword" />
                                        <View v-else />
                                    </el-icon>
                                </template>
                            </el-input>
                        </div>
                    </el-form-item>
                </div>

                <div class="auth-field">
                    <div class="auth-field__label">
                        {{ $t("invite_code_required") }}
                    </div>
                    <el-form-item prop="inviteCode">
                        <div class="auth-input">
                            <el-input
                                v-model="ruleForm.inviteCode"
                                :placeholder="$t('invite_code_required')"
                                type="text"
                                autocomplete="off"
                                size="large"
                            />
                        </div>
                    </el-form-item>
                </div>

                <div class="auth-agreement">
                    <van-checkbox
                        v-model="checked"
                        checked-color="#4d63ff"
                        shape="round"
                        icon-size="20px"
                    >
                        <span class="auth-agreement__muted">{{
                            $t("i_agree")
                        }}</span>
                        <span class="auth-agreement__link" @click.stop="jump">
                            {{ $t("terms_and_conditions_2") }}
                        </span>
                    </van-checkbox>
                </div>

                <div
                    class="auth-submit"
                    :class="{
                        'auth-submit--disabled':
                            !isRegisterReady || isSubmitting,
                    }"
                    :aria-disabled="!isRegisterReady || isSubmitting"
                    @click="sendCode"
                >
                    {{ $t("register") }}
                </div>

                <div class="auth-footer">
                    <span class="auth-footer__muted">{{
                        $t("need_help")
                    }}</span>
                    <span class="auth-footer__link" @click="customer">
                        {{ $t("need_help_desc") }}
                    </span>
                </div>
            </el-form>
        </div>

        <Lang ref="langRef"></Lang>
        <AppLoadingScreen :visible="isSubmitting || isCustomerLoading" />
    </div>
</template>

<script setup>
import AppLoadingScreen from "@/components/AppLoadingScreen.vue";
import Lang from "@/components/Lang.vue";
import { Hide, View } from "@element-plus/icons-vue";
import { computed, onMounted, reactive, ref } from "vue";
import { useRouter } from "vue-router";
import { useI18n } from "vue-i18n";
import { register, reqBeedPhone, getTradeConfig } from "../../api/apis";
import { showToast } from "@/util/message";
import { useCommonStore } from "@/store/modules/common";
import { useUserStore } from "@/store/modules/user";
import { checkWorkTimeLocal } from "../../util/utils";
import { LANGS } from "@/config/lang";

const onUsernameInput = (val) => {
    ruleForm.username = val.replace(/[^a-zA-Z0-9]/g, "");
};

const onPhoneInput = (val) => {
    ruleForm.phone = val.replace(/\D/g, "");
};

const router = useRouter();
const { t } = useI18n();
const ruleFormRef = ref(null);
const langRef = ref(null);
const commonStore = useCommonStore();
const userStore = useUserStore();
const agentPassword = ref("");
const checked = ref(false);
const switchLeaving = ref(false);
const isSubmitting = ref(false);
const isCustomerLoading = ref(false);
const genderMenuOpen = ref(false);
const showTradePassword = ref(false);
const showPassword = ref(false);
const showConfirmPassword = ref(false);
const needPhone = ref(1);

const ruleForm = reactive({
    username: "",
    phone: "",
    password: "",
    tradePassword: "",
    sex: null,
    inviteCode: "",
});

const REGISTER_FORM_CACHE_KEY = "skye_register_form_cache";
const REGISTER_FORM_CACHE_MAX_AGE = 30 * 60 * 1000;

const rules = computed(() => {
    return {};
});

const currentLang = computed(() => LANGS[commonStore.lang] || LANGS.en);

const isNeedPhone = computed(() => {
    return Number(needPhone.value) === 0;
});

const genderLabel = computed(() => {
    if (ruleForm.sex === 1) return t("male");
    if (ruleForm.sex === 2) return t("female");
    return t("Gender_fomt");
});

const genderEmoji = computed(() => {
    if (ruleForm.sex === 2) return "F";
    return "M";
});

const isRegisterReady = computed(() => {
    return Boolean(
        checked.value &&
        ruleForm.username &&
        (!isNeedPhone.value || ruleForm.phone) &&
        ruleForm.password &&
        ruleForm.sex &&
        agentPassword.value &&
        ruleForm.tradePassword &&
        ruleForm.inviteCode,
    );
});

function getNeedPhoneValue(res) {
    const value =
        res?.data?.needPhone ??
        res?.data?.need_phone ??
        res?.data?.value ??
        res?.data ??
        res?.needPhone ??
        res?.need_phone ??
        1;

    return Number(value) === 0 ? 0 : 1;
}

async function getNeedPhoneConfig() {
    try {
        const res = await reqBeedPhone();
        needPhone.value = getNeedPhoneValue(res);

        if (!isNeedPhone.value) {
            ruleForm.phone = "";
        }
    } catch (error) {
        needPhone.value = 1;
        ruleForm.phone = "";
    }
}

function clearRegisterFormCache() {
    try {
        sessionStorage.removeItem(REGISTER_FORM_CACHE_KEY);
    } catch (error) {}
}

function saveRegisterFormCache() {
    try {
        sessionStorage.setItem(
            REGISTER_FORM_CACHE_KEY,
            JSON.stringify({
                timestamp: Date.now(),
                ruleForm: {
                    username: ruleForm.username || "",
                    phone: ruleForm.phone || "",
                    password: ruleForm.password || "",
                    tradePassword: ruleForm.tradePassword || "",
                    sex: ruleForm.sex,
                    inviteCode: ruleForm.inviteCode || "",
                },
                agentPassword: agentPassword.value || "",
                checked: checked.value,
            }),
        );
    } catch (error) {}
}

function restoreRegisterFormCache() {
    try {
        const cache = sessionStorage.getItem(REGISTER_FORM_CACHE_KEY);
        if (!cache) return false;

        const data = JSON.parse(cache);
        clearRegisterFormCache();

        if (
            !data?.timestamp ||
            Date.now() - Number(data.timestamp) > REGISTER_FORM_CACHE_MAX_AGE
        ) {
            return false;
        }

        const cachedRuleForm = data.ruleForm || {};
        const cachedSex = Number(cachedRuleForm.sex);

        ruleForm.username = cachedRuleForm.username || "";
        ruleForm.phone = cachedRuleForm.phone || "";
        ruleForm.password = cachedRuleForm.password || "";
        ruleForm.tradePassword = cachedRuleForm.tradePassword || "";
        ruleForm.sex = [1, 2].includes(cachedSex) ? cachedSex : null;
        ruleForm.inviteCode = cachedRuleForm.inviteCode || "";
        agentPassword.value = data.agentPassword || "";
        checked.value = Boolean(data.checked);

        return true;
    } catch (error) {
        clearRegisterFormCache();
        return false;
    }
}

function toLogin() {
    if (switchLeaving.value) return;
    clearRegisterFormCache();
    switchLeaving.value = true;
    window.setTimeout(() => {
        router.replace("/account/login");
    }, 180);
}

function toggleGenderMenu() {
    genderMenuOpen.value = !genderMenuOpen.value;
}

function selectGender(value) {
    ruleForm.sex = value;
    genderMenuOpen.value = false;
}

function handleChangeLang() {
    langRef.value.open();
}

function sendCode() {
    if (isSubmitting.value || !isRegisterReady.value) return;

    if (!checked.value) {
        return showToast(t("please_tick_and_agree_to_the_argeement"));
    }

    if (!ruleForm.username) {
        return showToast(t("please_enter_username"));
    }

    const reg = /^[A-Za-z0-9]+$/;
    if (!reg.test(ruleForm.username)) {
        return showToast(t("user_name_input_space_or_special_symbol"));
    }

    if (isNeedPhone.value && !ruleForm.phone) {
        return showToast(t("please_enter_phone_number"));
    }

    if (!ruleForm.password) {
        return showToast(t("please_enter_a_6_digit_password"));
    }

    if (!ruleForm.sex) {
        return showToast(t("gender_cannot_be_empty"));
    }

    if (!agentPassword.value) {
        return showToast(t("please_enter_confirm_password"));
    }

    if (agentPassword.value != ruleForm.password) {
        return showToast(t("passwords_do_not_match"));
    }

    if (!/^\d{6}$/.test(ruleForm.tradePassword)) {
        return showToast(t("please_enter_a_6_digit_transaction_password"));
    }

    if (!ruleForm.inviteCode) {
        return showToast(t("please_enter_invitation_code"));
    }

    const submitForm = {
        ...ruleForm,
    };

    if (!isNeedPhone.value) {
        delete submitForm.phone;
    }

    isSubmitting.value = true;
    register(submitForm)
        .then(() => {
            clearRegisterFormCache();
            showToast(t("registration_successful"));
            return router.push({
                path: "/account/login",
            });
        })
        .catch(() => {})
        .finally(() => {
            isSubmitting.value = false;
        });
}

function getHashParam(key) {
    const hash = window.location.hash;
    const queryString = hash.includes("?") ? hash.split("?")[1] : "";
    const params = new URLSearchParams(queryString);
    return params.get(key);
}

const jump = () => {
    saveRegisterFormCache();
    router.push({
        path: "/tc",
    });
};

const TradeInfor = ref({});

const tradeConfig = async () => {
    const res = await getTradeConfig();
    TradeInfor.value = res.data || {};
    return TradeInfor.value;
};

const ensureTradeConfig = async () => {
    return tradeConfig();
};

const showSupportHoursToast = () => {
    showToast({
        content: t("supportHours"),
        key: "customer-support-hours",
    });
};

const customer = async () => {
    if (isCustomerLoading.value) return;

    isCustomerLoading.value = true;
    try {
        const tradeInfo = await ensureTradeConfig();

        if (tradeInfo?.workTimeStart && tradeInfo?.workTimeEnd) {
            const time = checkWorkTimeLocal(
                tradeInfo.workTimeStart,
                tradeInfo.workTimeEnd,
                userStore.zoneActive?.tzName,
            );

            if (!time) {
                showSupportHoursToast();
                return;
            }
        }

        saveRegisterFormCache();
        await router.push({
            path: "/customer",
        });
    } catch (error) {
        showToast(error?.msg || error?.message || t("network_error"));
    } finally {
        isCustomerLoading.value = false;
    }
};

onMounted(() => {
    restoreRegisterFormCache();

    const code = getHashParam("code");
    if (code) {
        ruleForm.inviteCode = code;
    }

    getNeedPhoneConfig();
});
</script>

<style scoped>
.auth-shell {
    min-height: 100vh;
    background: #161616;
    position: relative;
    overflow-x: hidden;
    color: #ffffff;
}

.auth-shell--register {
    overflow-y: auto;
}

.auth-hero {
    position: relative;
    height: 154px;
}

.auth-hero__image {
    width: 100%;
    height: 154px;
    object-fit: cover;
    display: block;
    opacity: 0.9;
}

.auth-back {
    position: absolute;
    left: 18px;
    top: 36px;
    z-index: 2;
}

.auth-register-title {
    position: absolute;
    left: 50%;
    top: 54px;
    transform: translateX(-50%);
    color: #ffffff;
    font-size: 18px;
    line-height: 24px;
    font-weight: 800;
    letter-spacing: 0.05em;
    text-transform: uppercase;
    white-space: nowrap;
}

.auth-lang {
    position: absolute;
    top: 24px;
    right: 18px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 30px;
    width: 110px;
    padding: 0 11px;
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.08);
    color: #f3f5fb;
    font-size: 11px;
    font-weight: 600;
    z-index: 2;
}

.auth-lang__globe {
    width: 20px;
    height: 20px;
    flex: 0 0 20px;
    background: url("@/static/images/lang/globe.png") center / contain no-repeat;
    font-size: 0;
    line-height: 0;
}

.auth-lang__flag {
    width: 20px;
    height: 14px;
    border-radius: 2px;
    overflow: hidden;
    background: center / contain no-repeat;
    box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.12);
    flex: 0 0 20px;
    font-size: 0;
    line-height: 0;
}

.auth-shell--lang-en .auth-lang__flag {
    background-image: url("@/static/images/lang/en.png");
}

.auth-shell--lang-zh .auth-lang__flag {
    background-image: url("@/static/images/lang/zh.png");
}

.auth-shell--lang-id .auth-lang__flag {
    background-image: url("@/static/images/lang/id.png");
}

.auth-shell--lang-th .auth-lang__flag {
    background-image: url("@/static/images/lang/th.png");
}

.auth-shell--lang-ko .auth-lang__flag {
    background:
        radial-gradient(
            circle at 50% 50%,
            #d83b3b 0 3px,
            #2462b8 3px 6px,
            transparent 6px
        ),
        #ffffff;
}

.auth-lang__text {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.auth-lang__arrow {
    width: 8px;
    height: 8px;
    flex: 0 0 8px;
    margin-left: 1px;
    border-right: 2px solid rgba(255, 255, 255, 0.76);
    border-bottom: 2px solid rgba(255, 255, 255, 0.76);
    transform: rotate(45deg) translateY(-2px);
}

.auth-card {
    position: relative;
    margin: 0 20px;
    padding: 0 0 36px;
}

.auth-form :deep(.el-form-item) {
    margin-bottom: 16px;
}

.auth-form :deep(.el-form-item__content) {
    line-height: normal;
}

.auth-field + .auth-field {
    margin-top: 8px;
}

.auth-field__label {
    margin-bottom: 10px;
    color: #dde1ef;
    font-size: 16px;
    line-height: 22px;
}

.auth-field__label span {
    color: #ff2c2c;
}

.auth-input {
    display: flex;
    align-items: center;
    gap: 0;
    width: 100%;
    height: 58px;
    padding: 0 18px;
    border: 1px solid #c9d0df;
    border-radius: 16px;
    background: #fff;
    overflow: hidden;
}

.auth-input :deep(.el-input) {
    flex: 1;
    min-width: 0;
}

.auth-input :deep(.el-input__wrapper) {
    box-shadow: none !important;
    padding: 0 !important;
    background: transparent !important;
    border: 0 !important;
    border-radius: 0 !important;
}

.auth-input :deep(.el-input__inner) {
    height: 56px;
    font-size: 18px;
    color: #1a1f29;
    border: 0 !important;
    background: transparent !important;
    box-shadow: none !important;
    outline: none !important;
}

.auth-input :deep(.el-input__inner::placeholder) {
    color: #b4bac8;
}

.auth-input :deep(.el-input__wrapper.is-focus) {
    box-shadow: none !important;
}

.auth-eye-icon {
    font-size: 18px;
    color: #6d7482;
    cursor: pointer;
}

.auth-gender-select {
    margin-bottom: 16px;
}

.auth-gender-select__trigger {
    width: 100%;
    height: 58px;
    padding: 0 18px;
    border: 1px solid #c9d0df;
    border-radius: 16px;
    background: #ffffff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: none;
}

.auth-gender-select__value {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    color: #1a1f29;
    font-size: 18px;
}

.auth-gender-select__trigger--placeholder .auth-gender-select__value {
    color: #b4bac8;
}

.auth-gender-emoji {
    font-size: 16px;
    font-weight: 700;
    min-width: 16px;
}

.auth-gender-select__arrow {
    width: 14px;
    height: 14px;
    border-right: 3px solid #252a34;
    border-bottom: 3px solid #252a34;
    transform: rotate(45deg) translateY(-4px);
    transition: transform 0.2s ease;
}

.auth-gender-select__arrow--open {
    transform: rotate(225deg) translateY(-1px);
}

.auth-gender-select__menu {
    margin-top: 10px;
    border-radius: 16px;
    border: 1px solid #dbe7df;
    background: #ffffff;
    overflow: hidden;
}

.auth-gender-select__option {
    width: 100%;
    min-height: 54px;
    padding: 0 18px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    color: #1a1f29;
    border-bottom: 1px solid #eef1f5;
}

.auth-gender-select__option:last-child {
    border-bottom: 0;
}

.auth-gender-select__option--active,
.auth-gender-select__check {
    color: #4d63ff;
}

.auth-agreement {
    margin: 14px 2px 0;
}

.auth-agreement__muted {
    color: #d8dcea;
}

.auth-agreement__link {
    color: #6d84ff;
}

.auth-submit {
    margin-top: 26px;
    height: 60px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #3552ea;
    color: #fff;
    font-size: 18px;
    font-weight: 700;
    letter-spacing: 0.04em;
    text-transform: uppercase;
}

.auth-submit--disabled {
    pointer-events: none;
    background: rgba(53, 82, 234, 0.4);
    box-shadow: none;
    color: #ffffff;
}

.auth-footer {
    margin-top: 24px;
    display: flex;
    justify-content: center;
    gap: 4px;
    font-size: 14px;
    line-height: 20px;
}

.auth-footer__muted {
    color: #d8dcea;
}

.auth-footer__link {
    color: #6d84ff;
}
</style>
