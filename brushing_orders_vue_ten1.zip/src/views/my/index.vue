﻿<template>
    <div class="my-page min-h-[100vh] bg-[#f5faf6] pb-[118px] text-[#111]">
        <PageTopBar :title="$t('my')" />

        <main class="px-[16px] pt-[85px] pb-[16px]">
            <section class="profile-hero relative overflow-hidden text-white">
                <div class="hero-wave hero-wave--top"></div>
                <div class="hero-wave hero-wave--bottom"></div>

                <div class="profile-hero__badge">
                    <img :src="myIcons.level" alt="" />
                    <span>{{ userLevel || "VIP1" }}</span>
                </div>

                <div class="profile-hero__avatar-wrap">
                    <div class="avatar-ring">
                        <div
                            v-if="userInfo.avatar === undefined"
                            class="h-full w-full animate-pulse rounded-full bg-white/20"
                        ></div>
                        <img
                            v-else-if="userInfo.avatar"
                            :src="userInfo.avatar"
                            class="h-full w-full rounded-full object-cover"
                            :alt="$t('user_avatar')"
                            @error="(e) => (e.target.src = userImg)"
                        />
                        <img
                            v-else
                            :src="myIcons.user"
                            class="avatar-fallback h-[38px] w-[38px]"
                            :alt="$t('default_avatar')"
                        />
                    </div>
                    <button class="profile-hero__edit" type="button">
                        <van-icon name="edit" size="16" color="#3155df" />
                    </button>
                </div>

                <div class="profile-hero__name">
                    {{ userInfo.username || "--" }}
                </div>

                <div class="profile-hero__referral">
                    <span>{{ $t("member_invitation_code") }}:</span>
                    <button
                        class="referral-badge"
                        type="button"
                        @click="
                            copyContent(userInfo.inviteCode, {
                                duration: 4,
                            })
                        "
                    >
                        {{ userInfo.inviteCode || "--" }}
                    </button>
                    <img :src="myIcons.copy" class="referral-copy" alt="" />
                </div>

                <div class="profile-hero__score">
                    <span>{{ $t("credit_score") }}:</span>
                    <span>{{ creditScoreDisplay }}</span>
                </div>
                <div class="profile-hero__scorebar">
                    <div
                        class="credit-progress-bar"
                        :style="{ width: creditScorePercent }"
                    ></div>
                </div>

                <div class="profile-hero__stats">
                    <div class="profile-stat">
                        <div class="profile-stat__label">
                            {{ $t("wallet_balance") }}
                        </div>
                        <div class="profile-stat__value">{{ walletBalance }}</div>
                        <div class="profile-stat__unit">USD</div>
                    </div>
                    <div class="profile-stat">
                        <div class="profile-stat__label">
                            {{ $t("home_today_s_earnings") }}
                        </div>
                        <div class="profile-stat__value">{{ rebateAmount }}</div>
                        <div class="profile-stat__unit">USD</div>
                    </div>
                </div>
            </section>

            <section
                class="menu-card mt-[16px] overflow-hidden rounded-[13px] border border-[#cfe9d5] bg-white"
            >
                <div
                    v-for="item in menuItems"
                    :key="item.title"
                    class="menu-row"
                    @click="item.action"
                >
                    <div class="menu-icon">
                        <img
                            :src="item.icon"
                            class="h-[18px] w-[18px]"
                            alt=""
                        />
                    </div>
                    <div class="min-w-0 flex-1">
                        <div class="text-[16px] leading-[20px] text-[#1b261e]">
                            {{ item.title }}
                        </div>
                        <div
                            class="mt-[4px] truncate text-[12px] leading-[16px] text-[#5b8064]"
                        >
                            {{ item.desc }}
                        </div>
                    </div>
                    <van-icon name="arrow" size="16" color="#5f8067" />
                </div>
            </section>

            <button class="logout-btn" type="button" @click="logout">
                <img
                    :src="myIcons.logout"
                    class="mr-[8px] h-[17px] w-[17px]"
                    alt=""
                />
                {{ $t("log_out") }}
            </button>
        </main>
        <ContactUs ref="ContactUsRef"></ContactUs>
        <tradePassword ref="tradePasswordRef"></tradePassword>
        <Lang ref="langRef"></Lang>
        <van-popup
            v-if="!isPc"
            v-model:show="showLogoutPopup"
            position="bottom"
            class="logout-sheet logout-sheet--mobile"
            overlay-class="logout-sheet-overlay logout-sheet-overlay--mobile"
            transition="logout-sheet-slide"
            round
        >
            <div class="logout-sheet__icon">
                <img :src="myIcons.logout" alt="" />
            </div>
            <div class="logout-sheet__title">{{ $t("log_out") }}</div>
            <div class="logout-sheet__desc">
                {{ $t("logout_confirm_desc_1") }}<br />
                {{ $t("logout_confirm_desc_2") }}
            </div>
            <button
                class="logout-sheet__confirm"
                type="button"
                @click="confirmLogout"
            >
                <img :src="myIcons.logout" alt="" />
                {{ $t("confirm_log_out") }}
            </button>
            <button
                class="logout-sheet__cancel"
                type="button"
                @click="showLogoutPopup = false"
            >
                {{ $t("cancel") }}
            </button>
        </van-popup>
        <transition name="logout-desktop-fade">
            <div
                v-if="isPc && showLogoutPopup"
                class="logout-desktop-layer"
                @click.self="showLogoutPopup = false"
            >
                <div class="logout-desktop-card">
                    <div class="logout-sheet__icon">
                        <img :src="myIcons.logout" alt="" />
                    </div>
                    <div class="logout-sheet__title">{{ $t("log_out") }}</div>
                    <div class="logout-sheet__desc">
                        {{ $t("logout_confirm_desc_1") }}<br />
                        {{ $t("logout_confirm_desc_2") }}
                    </div>
                    <button
                        class="logout-sheet__confirm"
                        type="button"
                        @click="confirmLogout"
                    >
                        <img :src="myIcons.logout" alt="" />
                        {{ $t("confirm_log_out") }}
                    </button>
                    <button
                        class="logout-sheet__cancel"
                        type="button"
                        @click="showLogoutPopup = false"
                    >
                        {{ $t("cancel") }}
                    </button>
                </div>
            </div>
        </transition>
    </div>
</template>

<script setup>
import {
    computed,
    onActivated,
    onDeactivated,
    onMounted,
    onUnmounted,
    ref,
} from "vue";
import { useRouter } from "vue-router";
import { useI18n } from "vue-i18n";
import { showToast } from "@/util/message";

import ContactUs from "@/components/ContactUs.vue";
import Lang from "@/components/Lang.vue";
import tradePassword from "@/components/tradePassword.vue";
import { checkWorkTimeLocal, copyContent } from "@/util/utils";
import { getTradeConfig } from "@/api/apis";
import { useUserStore } from "@/store/modules/user";

const router = useRouter();
const userStore = useUserStore();
const { t } = useI18n();
const userImg = new URL("@/static/images/userImg2.png", import.meta.url).href;

const langRef = ref(null);
const ContactUsRef = ref(null);
const tradePasswordRef = ref(null);
const userInfo = ref({});
const userLevel = ref("");
const TradeInfor = ref({});
const showLogoutPopup = ref(false);
const isPc = ref(false);

const myIcons = {
    user: new URL("@/static/images/user-mine.png", import.meta.url).href,
    copy: new URL("@/static/images/copy.png", import.meta.url).href,
    topy: new URL("@/static/images/topy.png", import.meta.url).href,
    profile: new URL("@/static/images/user-mine2.png", import.meta.url).href,
    wallet: new URL("@/static/images/user-wallet.png", import.meta.url).href,
    message: new URL("@/static/images/user-message.png", import.meta.url).href,
    card: new URL("@/static/images/LinkCard.png", import.meta.url).href,
    service: new URL("@/static/images/user-service.png", import.meta.url).href,
    logout: new URL("@/static/images/log-out.png", import.meta.url).href,
    level: new URL("@/static/images/design/vip-level-1.png", import.meta.url)
        .href,
};

const walletBalance = computed(() => {
    const value =
        userInfo.value.totalBalance ??
        Number(userInfo.value?.balance || 0) +
            Number(userInfo.value?.frozenBalance || 0);
    return Number(value || 0).toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
});

const rebateAmount = computed(() =>
    Number(userInfo.value?.commission || 0).toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }),
);

const creditScore = computed(() => {
    const rawScore = Number(userInfo.value?.creditScore ?? 0);
    if (!Number.isFinite(rawScore)) return 0;
    return Math.min(100, Math.max(0, rawScore));
});

const creditScoreDisplay = computed(() => `${Math.round(creditScore.value)}%`);
const creditScorePercent = computed(() => `${creditScore.value}%`);

const menuItems = computed(() => [
    {
        title: t("personal_profile"),
        desc: t("manage_basic_information"),
        icon: myIcons.profile,
        action: () => toPage("/profileItem"),
    },
    {
        title: t("payment_methods"),
        desc: t("configure_recharge_withdrawal"),
        icon: myIcons.wallet,
        action: () => toPage("/paymentMethods"),
    },
    {
        title: t("message_center"),
        desc: t("system_notifications_announcements"),
        icon: myIcons.message,
        action: () => toPage("/notice"),
    },
    {
        title: t("link_your_bank_card"),
        desc: t("bind_bank_card_for_withdrawals"),
        icon: myIcons.card,
        action: () => router.push({ path: "/cardList", query: { type: 1 } }),
    },
    {
        title: t("contact_customer_service"),
        desc: t("get_help_resolve_issues"),
        icon: myIcons.service,
        action: customer,
    },
]);

function toPage(path) {
    router.push({ path });
}

function customer() {
    const time = checkWorkTimeLocal(
        TradeInfor.value.workTimeStart,
        TradeInfor.value.workTimeEnd,
        userStore.zoneActive.tzName,
    );

    if (time) {
        ContactUsRef.value.open();
        return;
    }

    showToast(
        t("supportHours", {
            start: TradeInfor.value.workTimeStart,
            end: TradeInfor.value.workTimeEnd,
        }),
    );
}

function logout() {
    showLogoutPopup.value = true;
}

function confirmLogout() {
    showLogoutPopup.value = false;
    userStore.logout();
}

function updateDeviceMode() {
    isPc.value = window.matchMedia("(min-width: 768px)").matches;
}

function updateHandler() {
    getUserGetInfo({ force: true });
}

function syncUserInfo(info = {}) {
    userInfo.value = info || {};
    userLevel.value = info?.userLevel?.nameEn || "";
}

async function getUserGetInfo(options = {}) {
    const info = await userStore.getUserInfo(options);
    syncUserInfo(info);
    return info;
}

async function tradeConfig() {
    const res = await getTradeConfig();
    TradeInfor.value = res.data || {};
}

onMounted(() => {
    window.addEventListener("updateTrade", updateHandler);
    window.addEventListener("resize", updateDeviceMode);
    updateDeviceMode();
    getUserGetInfo();
    tradeConfig();
});

onActivated(() => {
    window.addEventListener("updateTrade", updateHandler);
});

onUnmounted(() => {
    window.removeEventListener("updateTrade", updateHandler);
    window.removeEventListener("resize", updateDeviceMode);
});

onDeactivated(() => {
    window.removeEventListener("updateTrade", updateHandler);
});
</script>

<style scoped>
.my-page {
    font-family: "Montserrat", "Poppins", sans-serif;
}

.profile-hero {
    min-height: 370px;
    border-radius: 26px;
    padding: 24px 24px 28px;
    background: linear-gradient(135deg, #4e84f4 0%, #3049e1 100%);
    box-shadow: 0 16px 30px rgba(37, 70, 196, 0.22);
}

.credit-progress-bar {
    height: 100%;
    border-radius: inherit;
    background: linear-gradient(90deg, #37d45f 0%, #42c66c 100%);
    transition: width 0.6s cubic-bezier(0.22, 1, 0.36, 1);
}

.hero-wave {
    position: absolute;
    border-radius: 9999px;
    border: 1px solid rgba(84, 163, 255, 0.24);
}

.hero-wave--top {
    left: -30px;
    top: -10px;
    width: 290px;
    height: 290px;
    opacity: 0.45;
}

.hero-wave--bottom {
    right: -80px;
    bottom: 40px;
    width: 320px;
    height: 120px;
    transform: rotate(-18deg);
    opacity: 0.25;
}

.profile-hero__badge {
    position: absolute;
    top: 20px;
    right: 22px;
    text-align: center;
}

.profile-hero__badge img {
    width: 52px;
    height: 52px;
    object-fit: contain;
}

.profile-hero__badge span {
    display: block;
    margin-top: 4px;
    font-size: 13px;
    line-height: 16px;
}

.profile-hero__avatar-wrap {
    position: relative;
    z-index: 1;
    width: fit-content;
    margin: 18px auto 0;
}

.avatar-ring {
    display: flex;
    height: 126px;
    width: 126px;
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    border-radius: 9999px;
    background: rgba(255, 255, 255, 0.22);
    border: 4px solid rgba(255, 255, 255, 0.18);
}

.profile-hero__edit {
    position: absolute;
    right: -4px;
    bottom: 8px;
    width: 42px;
    height: 42px;
    border-radius: 999px;
    background: #ffffff;
    border: 3px solid #3956e0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.profile-hero__name {
    position: relative;
    z-index: 1;
    margin-top: 20px;
    text-align: center;
    font-size: 28px;
    line-height: 34px;
    font-weight: 700;
}

.profile-hero__referral,
.profile-hero__score {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
}

.profile-hero__referral {
    margin-top: 22px;
    justify-content: center;
    gap: 10px;
    font-size: 15px;
}

.referral-badge {
    min-width: 92px;
    height: 38px;
    padding: 0 16px;
    border-radius: 10px;
    background: #33d35f;
    color: #ffffff;
    font-size: 16px;
    font-weight: 700;
}

.referral-copy {
    width: 22px;
    height: 22px;
    filter: brightness(0) invert(1);
    opacity: 0.9;
}

.profile-hero__score {
    margin-top: 28px;
    justify-content: space-between;
    font-size: 16px;
}

.profile-hero__scorebar {
    position: relative;
    z-index: 1;
    margin-top: 14px;
    height: 16px;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.9);
    overflow: hidden;
}

.profile-hero__stats {
    position: relative;
    z-index: 1;
    margin-top: 30px;
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
}

.profile-stat {
    text-align: center;
}

.profile-stat + .profile-stat {
    border-left: 1px dashed rgba(255, 255, 255, 0.22);
}

.profile-stat__label {
    color: rgba(255, 255, 255, 0.85);
    font-size: 14px;
    line-height: 20px;
}

.profile-stat__value {
    margin-top: 14px;
    font-size: 25px;
    line-height: 1;
    font-weight: 700;
}

.profile-stat__unit {
    margin-top: 6px;
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 0.06em;
}

.menu-row {
    display: flex;
    min-height: 92px;
    align-items: center;
    border-bottom: 1px solid #ebeff5;
    padding: 18px 18px;
}

.menu-row:last-child {
    border-bottom: 0;
}

.menu-icon {
    margin-right: 14px;
    display: flex;
    height: 48px;
    width: 48px;
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    border-radius: 999px;
    background: #e8f3ff;
}

.logout-btn {
    margin-top: 16px;
    display: flex;
    height: 54px;
    width: 100%;
    align-items: center;
    justify-content: center;
    border: 1px solid #f8dfdb;
    border-radius: 13px;
    background: #fff3f1;
    color: #f04d45;
    font-size: 16px;
    font-weight: 600;
}

.logout-sheet {
    width: 100%;
    max-width: var(--app-pc-max-width, 375px);
    left: 50% !important;
    transform: translateX(-50%) !important;
    border-radius: 20px 20px 0 0;
    padding: 39px 22px calc(36px + env(safe-area-inset-bottom, 0px));
    background: #ffffff;
    box-sizing: border-box;
}

.logout-sheet--mobile {
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    width: 100vw !important;
    max-width: 100vw !important;
    min-width: 100vw !important;
    transform: none !important;
}

:global(.logout-sheet-overlay) {
    background: rgba(0, 0, 0, 0.42);
    backdrop-filter: blur(4px);
}

:global(.logout-sheet-overlay--mobile) {
    left: 0 !important;
    right: 0 !important;
    top: 0 !important;
    bottom: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    height: 100dvh !important;
}

:global(.logout-sheet-slide-enter-active),
:global(.logout-sheet-slide-leave-active) {
    transition:
        transform 0.24s cubic-bezier(0.22, 1, 0.36, 1),
        opacity 0.24s ease;
}

:global(.logout-sheet-slide-enter-from),
:global(.logout-sheet-slide-leave-to) {
    opacity: 0;
    transform: translate3d(0, 100%, 0) !important;
}

:global(.logout-sheet-slide-enter-to),
:global(.logout-sheet-slide-leave-from) {
    opacity: 1;
    transform: translate3d(0, 0, 0) !important;
}

.logout-sheet__icon {
    width: 78px;
    height: 78px;
    margin: 0 auto;
    border-radius: 50%;
    border: 1px dashed #ffb0aa;
    background: #fff4f2;
    display: flex;
    align-items: center;
    justify-content: center;
}

.logout-sheet__icon img {
    width: 26px;
    height: 26px;
}

.logout-sheet__title {
    margin-top: 18px;
    text-align: center;
    color: #101522;
    font-size: 20px;
    line-height: 26px;
    font-weight: 700;
}

.logout-sheet__desc {
    margin-top: 16px;
    text-align: center;
    color: #62806b;
    font-size: 13px;
    line-height: 22px;
}

.logout-sheet__confirm,
.logout-sheet__cancel {
    width: 100%;
    height: 59px;
    border-radius: 12px;
    font-size: 17px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
}

.logout-sheet__confirm {
    margin-top: 26px;
    background: var(--theme-primary);
    color: #ffffff;
}

.logout-sheet__confirm img {
    width: 22px;
    height: 22px;
    margin-right: 10px;
    filter: brightness(0) invert(1);
}

.logout-sheet__cancel {
    margin-top: 18px;
    color: #d37703;
    border: 1px solid rgba(211, 119, 3, 1);
    border-radius: 14px;
    background: rgba(211, 119, 3, 0.12);
}

.logout-desktop-layer {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 50%;
    z-index: 3000;
    width: var(--app-pc-max-width, 375px);
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.42);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px;
    box-sizing: border-box;
}

.logout-desktop-card {
    width: 100%;
    max-width: calc(var(--app-pc-max-width, 375px) - 32px);
    border-radius: 18px;
    background: #ffffff;
    padding: 34px 22px 28px;
    box-sizing: border-box;
}

.logout-desktop-fade-enter-active,
.logout-desktop-fade-leave-active {
    transition: opacity 0.22s ease;
}

.logout-desktop-fade-enter-active .logout-desktop-card,
.logout-desktop-fade-leave-active .logout-desktop-card {
    transition:
        transform 0.24s cubic-bezier(0.22, 1, 0.36, 1),
        opacity 0.22s ease;
}

.logout-desktop-fade-enter-from,
.logout-desktop-fade-leave-to {
    opacity: 0;
}

.logout-desktop-fade-enter-from .logout-desktop-card,
.logout-desktop-fade-leave-to .logout-desktop-card {
    opacity: 0;
    transform: translateY(14px) scale(0.96);
}
</style>
