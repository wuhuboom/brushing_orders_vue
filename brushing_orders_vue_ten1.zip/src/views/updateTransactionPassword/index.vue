<template>
    <div class="password-page min-h-screen bg-[#eef2fb]">
        <PageTopBar :title="pageTitle" show-back @click-left="onClickLeft" />

        <div class="page-body px-[20px] pt-[92px] pb-[36px]">
            <div class="form-card">
                <div class="field-block">
                    <div class="field-label">
                        Old Transaction Password
                    </div>
                    <van-field
                        v-model="ruleForm.oldTradePassword"
                        :type="showOldPassword ? 'text' : 'password'"
                        maxlength="6"
                        :formatter="onlyNumber"
                        format-trigger="onChange"
                        :placeholder="$t('enter_current_password')"
                        class="custom-field"
                    >
                        <template #left-icon>
                            <img
                                src="@/static/images/auth/auth-trade.png"
                                alt=""
                                class="field-key-image"
                            />
                        </template>
                        <template #right-icon>
                            <van-icon
                                :name="showOldPassword ? 'eye-o' : 'closed-eye'"
                                size="18"
                                color="#7BA78A"
                                @click.stop="showOldPassword = !showOldPassword"
                            />
                        </template>
                    </van-field>
                </div>

                <div class="field-block">
                    <div class="field-label">
                        New Transaction Password
                    </div>
                    <van-field
                        v-model="ruleForm.newTradePassword"
                        :type="showNewPassword ? 'text' : 'password'"
                        maxlength="6"
                        :formatter="onlyNumber"
                        format-trigger="onChange"
                        :placeholder="$t('enter_new_password')"
                        class="custom-field"
                    >
                        <template #left-icon>
                            <img
                                src="@/static/images/auth/auth-trade.png"
                                alt=""
                                class="field-key-image"
                            />
                        </template>
                        <template #right-icon>
                            <van-icon
                                :name="showNewPassword ? 'eye-o' : 'closed-eye'"
                                size="18"
                                color="#7BA78A"
                                @click.stop="showNewPassword = !showNewPassword"
                            />
                        </template>
                    </van-field>
                </div>

                <div class="field-block field-block-last">
                    <div class="field-label">
                        Confirm New Transaction Password
                    </div>
                    <van-field
                        v-model="agentNewPassword"
                        :type="showConfirmPassword ? 'text' : 'password'"
                        maxlength="6"
                        :formatter="onlyNumber"
                        format-trigger="onChange"
                        :placeholder="$t('re_enter_new_password')"
                        class="custom-field"
                    >
                        <template #left-icon>
                            <img
                                src="@/static/images/auth/auth-trade.png"
                                alt=""
                                class="field-key-image"
                            />
                        </template>
                        <template #right-icon>
                            <van-icon
                                :name="
                                    showConfirmPassword ? 'eye-o' : 'closed-eye'
                                "
                                size="18"
                                color="#7BA78A"
                                @click.stop="
                                    showConfirmPassword = !showConfirmPassword
                                "
                            />
                        </template>
                    </van-field>
                </div>
            </div>

            <div class="mt-[18px]">
                <van-button
                    :class="[
                        'submit-btn',
                        { 'submit-btn--active': isFormReady },
                    ]"
                    block
                    @click="submitForm"
                >
                    {{ buttonText }}
                </van-button>
            </div>
        </div>
    </div>
</template>

<script setup>
import { computed, reactive, ref } from "vue";
import { useRoute, useRouter } from "vue-router";
import { useI18n } from "vue-i18n";
import { editTradePassword } from "../../api/apis";
import { showFailToast, showSuccessToast } from "@/util/message";

const router = useRouter();
const route = useRoute();
const { t } = useI18n();

const routePathStackKey = "route-path-stack";
const safeReturnPaths = ["/withdraw", "/profileItem", "/my"];

const agentNewPassword = ref("");
const showOldPassword = ref(false);
const showNewPassword = ref(false);
const showConfirmPassword = ref(false);
const ruleForm = reactive({
    oldTradePassword: "",
    newTradePassword: "",
});

const titleCase = (value) =>
    String(value || "").replace(/\b\w/g, (char) => char.toUpperCase());

const pageTitle = computed(() => titleCase(t("update_transaction_password")));
const titleText = computed(() => titleCase(t("change_transaction_password")));
const buttonText = computed(() => titleCase(t("update_password")));

const isFormReady = computed(
    () =>
        !!ruleForm.oldTradePassword &&
        !!ruleForm.newTradePassword &&
        !!agentNewPassword.value,
);

const onlyNumber = (value) => value.replace(/\D/g, "");

const readRouteStack = () => {
    try {
        const stack = JSON.parse(
            sessionStorage.getItem(routePathStackKey) || "[]",
        );
        return Array.isArray(stack)
            ? stack.filter((path) => typeof path === "string" && path)
            : [];
    } catch (error) {
        console.warn("Failed to read route stack", error);
        return [];
    }
};

const getSafeReturnPath = () => {
    const stack = readRouteStack();
    const currentIndex = stack.lastIndexOf(route.path);
    const previousStack = (
        currentIndex >= 0 ? stack.slice(0, currentIndex) : stack
    )
        .filter((path) => path !== route.path)
        .reverse();
    return (
        previousStack.find((path) => safeReturnPaths.includes(path)) ||
        "/profileItem"
    );
};

const goBackAfterSave = () => {
    router.push({ path: getSafeReturnPath() });
};

const onClickLeft = () => goBackAfterSave();

const submitForm = async () => {
    if (!ruleForm.oldTradePassword)
        return showFailToast(t("please_enter_the_old_password"));
    if (!ruleForm.newTradePassword)
        return showFailToast(t("please_enter_a_new_password"));
    if (ruleForm.newTradePassword.length !== 6) {
        return showFailToast(t("please_enter_a_6_18_digit_password"));
    }
    if (ruleForm.newTradePassword !== agentNewPassword.value) {
        return showFailToast(t("passwords_do_not_match"));
    }
    await editTradePassword(ruleForm);
    showSuccessToast(t("modification_successful"));
    goBackAfterSave();
};
</script>

<style scoped>
.page-body {
    min-height: calc(100vh - 53px);
}

.password-page :deep(.van-nav-bar) {
    background: #000000;
}

.password-page :deep(.van-nav-bar__title) {
    color: #ffffff;
    font-size: 22px;
    font-weight: 600;
}

.password-page :deep(.van-nav-bar .van-icon) {
    color: #ffffff;
}

.password-page :deep(.van-nav-bar::after) {
    border-bottom: none;
}

.form-card {
    background: transparent;
    padding: 0;
}

.field-block {
    margin-bottom: 24px;
}

.field-block-last {
    margin-bottom: 0;
}

.field-label {
    margin-bottom: 12px;
    color: #121212;
    font-size: 18px;
    line-height: 1.3;
    font-weight: 500;
}

.field-key-image {
    width: 16px;
    height: 16px;
}

.custom-field {
    min-height: 94px;
    border: 1px solid #d8e0ee !important;
    border-radius: 18px;
    background: #ffffff !important;
    padding: 8px 18px;
    display: flex;
    align-items: center;
}

.password-page :deep(.custom-field .van-field__left-icon) {
    margin-right: 10px;
}

.password-page :deep(.custom-field .van-field__right-icon) {
    margin-left: 10px;
}

.password-page :deep(.custom-field .van-field__control) {
    color: #111827;
    font-size: 18px;
}

.password-page :deep(.custom-field .van-field__control::placeholder) {
    color: #9aa3b2;
}

.submit-btn {
    height: 58px;
    border: none;
    border-radius: 16px;
    background: #d6dcfa;
    color: #ffffff;
    font-size: 18px;
    font-weight: 600;
}

.submit-btn--active {
    background: linear-gradient(90deg, #3b45df 0%, #3a4be7 100%);
    color: #ffffff;
    box-shadow: none;
}
</style>
