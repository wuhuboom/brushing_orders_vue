<template>
    <header class="page-top-bar">
        <div class="page-top-bar__status">
            <div class="page-top-bar__time">9:41 AM</div>
            <div class="page-top-bar__status-icons" aria-hidden="true">
                <div class="page-top-bar__signal">
                    <span></span><span></span><span></span><span></span>
                </div>
                <div class="page-top-bar__wifi"></div>
                <div class="page-top-bar__battery">
                    <span class="page-top-bar__battery-level"></span>
                </div>
            </div>
        </div>

        <div class="page-top-bar__content">
            <div
                class="page-top-bar__side page-top-bar__side--left"
                @click="handleLeftClick"
            >
                <slot name="left">
                    <van-icon
                        v-if="showBack"
                        name="arrow-left"
                        size="26"
                        color="#ffffff"
                    />
                </slot>
            </div>
            <div class="page-top-bar__title">
                <slot>{{ title }}</slot>
            </div>
            <div
                class="page-top-bar__side page-top-bar__side--right"
                @click="handleRightClick"
            >
                <slot name="right">
                    <span v-if="rightText" class="page-top-bar__right-text">
                        {{ rightText }}
                    </span>
                </slot>
            </div>
        </div>
    </header>
</template>

<script setup>
const props = defineProps({
    title: {
        type: String,
        default: "",
    },
    showBack: {
        type: Boolean,
        default: false,
    },
    rightText: {
        type: String,
        default: "",
    },
});

const emit = defineEmits(["click-left", "click-right"]);

const handleLeftClick = () => {
    if (!props.showBack) return;
    emit("click-left");
};

const handleRightClick = () => {
    if (!props.rightText) return;
    emit("click-right");
};
</script>

<style scoped>
.page-top-bar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 50;
    width: 100%;
    height: 100px;
    overflow: hidden;
    background: #121212;
    color: #ffffff;
}

.page-top-bar::before {
    content: "";
    position: absolute;
    inset: 0;
    background: #121212 url("@/static/images/auth/algofy-register-hero.png") center top /
        cover no-repeat;
    pointer-events: none;
}

@media (min-width: 768px) {
    .page-top-bar {
        left: 50%;
        right: auto;
        max-width: var(--app-pc-max-width, 375px);
        transform: translateX(-50%);
    }
}

.page-top-bar__status,
.page-top-bar__content {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-sizing: border-box;
}

.page-top-bar__status {
    height: 44px;
    padding: 0 16px 0 24px;
}

.page-top-bar__time {
    font-size: 13px;
    line-height: 1;
    font-weight: 700;
    letter-spacing: 0.01em;
}

.page-top-bar__status-icons {
    display: flex;
    align-items: center;
    gap: 8px;
}

.page-top-bar__signal {
    display: flex;
    align-items: flex-end;
    gap: 2px;
    height: 12px;
}

.page-top-bar__signal span {
    display: block;
    width: 3px;
    border-radius: 999px;
    background: #ffffff;
}

.page-top-bar__signal span:nth-child(1) { height: 5px; opacity: 0.7; }
.page-top-bar__signal span:nth-child(2) { height: 7px; opacity: 0.8; }
.page-top-bar__signal span:nth-child(3) { height: 10px; opacity: 0.9; }
.page-top-bar__signal span:nth-child(4) { height: 12px; }

.page-top-bar__wifi {
    position: relative;
    width: 16px;
    height: 11px;
}

.page-top-bar__wifi::before,
.page-top-bar__wifi::after {
    content: "";
    position: absolute;
    left: 50%;
    border: 2px solid transparent;
    border-top-color: #ffffff;
    border-radius: 50%;
    transform: translateX(-50%) rotate(180deg);
}

.page-top-bar__wifi::before {
    top: 1px;
    width: 16px;
    height: 12px;
}

.page-top-bar__wifi::after {
    top: 4px;
    width: 9px;
    height: 7px;
}

.page-top-bar__battery {
    position: relative;
    width: 24px;
    height: 12px;
    border: 1.8px solid #ffffff;
    border-radius: 3px;
    box-sizing: border-box;
}

.page-top-bar__battery::after {
    content: "";
    position: absolute;
    top: 3px;
    right: -3px;
    width: 2px;
    height: 4px;
    border-radius: 0 1px 1px 0;
    background: #ffffff;
}

.page-top-bar__battery-level {
    position: absolute;
    inset: 2px;
    border-radius: 1px;
    background: #ffffff;
}

.page-top-bar__content {
    display: grid;
    grid-template-columns: 72px minmax(0, 1fr) 72px;
    height: 56px;
    padding: 0 10px;
}

.page-top-bar__title {
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 0;
    overflow: hidden;
    color: #ffffff;
    text-align: center;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 18px;
    line-height: 1;
    font-weight: 700;
    letter-spacing: 0.02em;
    text-transform: uppercase;
}

.page-top-bar__side {
    min-width: 0;
    height: 100%;
    display: flex;
    align-items: center;
}

.page-top-bar__side--left {
    justify-content: flex-start;
    padding-left: 4px;
}

.page-top-bar__side--right {
    justify-content: flex-end;
    padding-right: 4px;
}

.page-top-bar__right-text {
    overflow: hidden;
    color: #ffffff;
    font-size: 14px;
    font-weight: 500;
    line-height: 20px;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.page-top-bar :deep(.van-icon) {
    color: #ffffff;
}
</style>
