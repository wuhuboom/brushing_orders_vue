<template>
  <div class="plain-design-page cert-page">
    <header class="design-topbar">
      <button class="design-back" type="button" @click="onClickLeft" aria-label="Back"></button>
      <div class="design-title">CERTIFICATE</div>
      <div class="design-right"></div>
    </header>

    <main class="cert-content">
      <img
        src="@/static/images/certprod2.png"
        class="certificate-image"
        alt="Certificate"
        @click="openContentPreview"
      />
    </main>

    <van-image-preview
      v-model:show="showCertPreview"
      :images="certContentPreviewImages"
      :start-position="0"
      closeable
      close-icon="cross"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue';
import certProductImage from '@/static/images/certprod2.png';

const showCertPreview = ref(false);
const certContentPreviewImages = [certProductImage];

const openContentPreview = () => {
  showCertPreview.value = true;
};

const onClickLeft = () => {
  history.back();
};
</script>

<style scoped>
.plain-design-page {
  min-height: 100vh;
  background: #eef2f8;
  color: #111;
  font-family: inherit;
}

.design-topbar {
  position: sticky;
  top: 0;
  z-index: 30;
  height: 52px;
  display: grid;
  grid-template-columns: 56px 1fr 56px;
  align-items: center;
  background: #030303;
  color: #fff;
}

.design-title {
  text-align: center;
  font-size: 18px;
  line-height: 22px;
  font-weight: 800;
  letter-spacing: 0.02em;
  text-transform: uppercase;
}

.design-back {
  width: 52px;
  height: 52px;
  border: 0;
  background: transparent;
  position: relative;
}

.design-back::before {
  content: '';
  position: absolute;
  left: 19px;
  top: 18px;
  width: 13px;
  height: 13px;
  border-left: 3px solid #fff;
  border-bottom: 3px solid #fff;
  transform: rotate(45deg);
  border-radius: 1px;
}

.cert-content {
  padding: 28px 20px 48px;
}

.certificate-image {
  display: block;
  width: 100%;
  background: #fff;
  object-fit: contain;
}
</style>
