<template>
  <div class="algofy-guide-page">
    <header class="design-topbar">
      <button class="design-back" type="button" @click="onClickLeft" aria-label="Back"></button>
      <div class="design-title">INCOME&nbsp;&nbsp;GUIDE</div>
      <div class="design-right"></div>
    </header>

    <main class="guide-content">
      <section class="guide-intro-card">
        <div class="intro-eyebrow">S&amp;G PROFIT &amp; EARNINGS GUIDE</div>
        <h1>Welcome to Your<br />Income Overview</h1>
        <p>
          Dear users, welcome to the profits and earnings guide. We will
          introduce you to the profits and earnings structure to help you plan
          your work schedule better.
        </p>
      </section>

      <section class="guide-section">
        <h2>(1) Basic Salary</h2>
        <p class="section-subtitle">Cumulative Sign-In Salary Structure</p>
        <div class="white-panel salary-panel">
          <p class="panel-copy">
            The company utilizes a cumulative sign-in system for its salary
            payment structure. Encouraging staff to commit to active mission on
            a daily basis.
          </p>
          <div class="salary-row"><span>Sign In 2 Working Days</span><b>$120</b></div>
          <div class="salary-row"><span>Sign In 4 Working Days</span><b>$1000</b></div>
          <div class="salary-row"><span>Sign In 10 Working Days</span><b>$1400</b></div>
          <div class="salary-row"><span>Sign In 20 Working Days</span><b>$1600</b></div>
          <div class="salary-row"><span>Sign In 30 Working Days</span><b>$2000</b></div>
        </div>
      </section>

      <section class="guide-section">
        <h2>(2) Reset Bonus</h2>
        <p class="section-subtitle">Advance Rewards + Accumulated Deposit Bonuses</p>
        <div class="white-panel bonus-panel">
          <p class="panel-copy">
            Reset rewards is one of the most important sources of extra income.
            You will receive advance rewards($10-$100) bonusreach time you reset
            your account to start first task with $100 USD.
          </p>
          <div class="reset-title">▫ Reset Advance Rewards</div>
          <div class="bonus-row"><span>Amount: $100</span><em>Hot Sale</em><b>+$10</b></div>
          <div class="bonus-row"><span>Amount: $500</span><em>Hot Sale</em><b>+$60</b></div>
          <div class="bonus-row"><span>Amount: $1,000</span><i></i><b>+$120</b></div>
          <div class="bonus-row"><span>Amount: $1,600</span><em>Limited Offer</em><b>+$200</b></div>
          <div class="bonus-row"><span>Amount: $5,500</span><em>Recommended</em><b>+$1200</b></div>
          <div class="bonus-row bonus-row-last"><span>Amount: $10,000</span><i></i><b>+$2400</b></div>

          <div class="deposit-title">Accumulated Deposit Rewards For The Day</div>
          <div class="deposit-head"><span>Advances On Day (+$0)</span><span>Advance Bonus</span></div>
          <div class="deposit-row"><span>1,500 - 9,999</span><b>4%</b></div>
          <div class="deposit-row"><span>10,000 - 19,999</span><b>8%</b></div>
          <div class="deposit-row"><span>20,000 - 49,999</span><b>12%</b></div>
          <div class="deposit-row"><span>50,000+</span><b>20%</b></div>
        </div>
      </section>

      <section class="guide-section daily-section">
        <h2>(3) Daily Profits</h2>
        <p class="section-subtitle">0.5% - 2.5% Of Product Price Per Optimization</p>
        <div class="white-panel daily-panel">
          <p class="panel-copy">
            Daily profits is your main source of income. Each time you optimize
            a product, you will earn a profit between0.5%-2.5%of the product
            price. The amount of profits earned is determined by your VIP level.
            The higher your VIP level, the higher the profits.
          </p>
          <div v-for="item in vipRates" :key="item.label" class="rate-row">
            <span>{{ item.label }}</span>
            <div class="rate-track"><i :style="{ width: item.width }"></i></div>
            <b>{{ item.rate }}</b>
          </div>
        </div>
      </section>

      <button class="guide-upgrade" type="button" @click="goVips">Upgrade VIP to Earn More →</button>
    </main>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router';

const router = useRouter();

const vipRates = [
  { label: 'VIP 1', width: '20%', rate: '0.5%' },
  { label: 'VIP 2', width: '35%', rate: '1%' },
  { label: 'VIP 3', width: '50%', rate: '1.5%' },
  { label: 'VIP 4', width: '65%', rate: '2%' },
  { label: 'VIP 5', width: '80%', rate: '2.5%' },
];

const goVips = () => {
  router.push({ path: '/vips' });
};

const onClickLeft = () => {
  history.back();
};
</script>

<style scoped>
.algofy-guide-page {
  min-height: 100vh;
  background: #f0f2f8;
  color: #111;
  font-family: inherit;
}

.design-topbar {
  position: sticky;
  top: 0;
  z-index: 20;
  height: 52px;
  display: grid;
  grid-template-columns: 56px 1fr 56px;
  align-items: center;
  background: #030303;
  color: #fff;
}

.design-title {
  text-align: center;
  font-size: 13px;
  line-height: 18px;
  font-weight: 800;
  letter-spacing: 0.02em;
}

.design-back {
  width: 52px;
  height: 52px;
  border: 0;
  background: transparent;
  position: relative;
}

.design-back::before {
  content: '';
  position: absolute;
  left: 19px;
  top: 18px;
  width: 13px;
  height: 13px;
  border-left: 3px solid #fff;
  border-bottom: 3px solid #fff;
  transform: rotate(45deg);
  border-radius: 1px;
}

.guide-content {
  padding: 12px 15px 25px;
}

.guide-intro-card {
  min-height: 226px;
  padding: 23px 23px 18px;
  border-radius: 5px;
  background: linear-gradient(135deg, #24419c 0%, #438dff 100%);
  color: #fff;
  box-shadow: 0 2px 6px rgba(44, 82, 177, 0.35);
}

.intro-eyebrow {
  font-size: 12px;
  line-height: 15px;
  opacity: 0.9;
  letter-spacing: 0.01em;
  margin-bottom: 18px;
}

.guide-intro-card h1 {
  margin: 0 0 15px;
  font-size: 24px;
  line-height: 31px;
  font-weight: 800;
}

.guide-intro-card p {
  margin: 0;
  font-size: 14px;
  line-height: 22px;
  color: rgba(255, 255, 255, 0.86);
}

.guide-section {
  margin-top: 18px;
}

.guide-section h2 {
  margin: 0 0 2px;
  font-size: 14px;
  line-height: 18px;
  font-weight: 800;
  color: #111;
}

.section-subtitle {
  margin: 0 0 14px;
  font-size: 12px;
  line-height: 16px;
  color: #7e8796;
  font-weight: 600;
}

.white-panel {
  background: #fff;
  border-radius: 7px;
  padding: 17px 15px;
}

.panel-copy {
  margin: 0 0 22px;
  font-size: 14px;
  line-height: 21px;
  color: #667080;
  font-weight: 600;
}

.salary-panel {
  padding-bottom: 10px;
}

.salary-row,
.bonus-row,
.deposit-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid #e4e7ee;
}

.salary-row {
  min-height: 50px;
  font-size: 13px;
  color: #333b48;
  font-weight: 800;
}

.salary-row:last-child,
.deposit-row:last-child {
  border-bottom: 0;
}

.salary-row b,
.deposit-row b,
.bonus-row b {
  color: #3264f5;
  font-weight: 900;
}

.reset-title {
  margin: 0 0 12px;
  color: #333b48;
  font-size: 13px;
  font-weight: 800;
}

.bonus-row {
  min-height: 45px;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto 45px;
  column-gap: 8px;
  color: #3d4653;
  font-size: 13px;
  font-weight: 800;
}

.bonus-row em {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 65px;
  height: 21px;
  padding: 0 7px;
  border-radius: 4px;
  background: #3345f5;
  color: #fff;
  font-size: 10px;
  line-height: 12px;
  font-style: normal;
  font-weight: 500;
}

.bonus-row b {
  text-align: right;
}

.bonus-row-last {
  border-bottom: 0;
}

.deposit-title {
  margin: 22px 0 12px;
  color: #333b48;
  font-size: 12px;
  line-height: 16px;
  font-weight: 800;
}

.deposit-head {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  margin-bottom: 10px;
}

.deposit-head span {
  height: 32px;
  border-radius: 3px;
  background: #3345f5;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
}

.deposit-row {
  min-height: 51px;
  font-size: 14px;
  color: #667080;
  font-weight: 800;
}

.daily-section {
  margin-top: 21px;
}

.daily-panel {
  padding-bottom: 15px;
}

.daily-panel .panel-copy {
  margin-bottom: 19px;
}

.rate-row {
  display: grid;
  grid-template-columns: 48px 1fr 42px;
  align-items: center;
  gap: 10px;
  min-height: 31px;
  color: #424b58;
  font-size: 13px;
  font-weight: 900;
}

.rate-track {
  height: 7px;
  border-radius: 999px;
  background: #e1e4eb;
  overflow: hidden;
}

.rate-track i {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: #3445f3;
}

.rate-row b {
  text-align: right;
  color: #3445f3;
  font-weight: 900;
}

.guide-upgrade {
  width: 100%;
  height: 51px;
  margin-top: 18px;
  border: 0;
  border-radius: 6px;
  background: #3445f3;
  color: #fff;
  font-size: 16px;
  font-weight: 500;
  box-shadow: 0 3px 6px rgba(45, 72, 214, 0.28);
}
</style>
