<template>
    <div class="my-page">
        <PageTopBar :title="$t('my')" />

        <main class="my-page__main">
            <section class="my-hero">
                <div class="my-hero__badge">
                    <img :src="myIcons.level" alt="" />
                    <span>{{ displayVipLevel }}</span>
                </div>

                <div class="my-hero__avatar-wrap">
                    <div class="my-hero__avatar-shell">
                        <div
                            v-if="userInfo.avatar === undefined"
                            class="my-hero__avatar-loading"
                        ></div>
                        <img
                            v-else-if="userInfo.avatar"
                            :src="userInfo.avatar"
                            class="my-hero__avatar"
                            :alt="$t('user_avatar')"
                            @error="(e) => (e.target.src = defaultAvatar)"
                        />
                        <img
                            v-else
                            :src="defaultAvatar"
                            class="my-hero__avatar"
                            :alt="$t('default_avatar')"
                        />
                    </div>
                    <button class="my-hero__edit" type="button">
                        <img :src="myIcons.edit" alt="" />
                    </button>
                </div>

                <div class="my-hero__name">
                    {{ userInfo.username || '--' }}
                </div>

                <div class="my-hero__row my-hero__row--referral">
                    <span class="my-hero__label">{{ $t('my_referral_code') }}:</span>
                    <button
                        class="my-hero__code"
                        type="button"
                        @click="copyContent(userInfo.inviteCode, { duration: 4 })"
                    >
                        {{ userInfo.inviteCode || '--' }}
                    </button>
                    <button
                        class="my-hero__copy-btn"
                        type="button"
                        @click="copyContent(userInfo.inviteCode, { duration: 4 })"
                    >
                        <img :src="myIcons.copy" alt="" />
                    </button>
                </div>

                <div class="my-hero__row my-hero__row--score">
                    <span class="my-hero__label">{{ $t('credit_score') }}:</span>
                    <span class="my-hero__score-value">{{ creditScoreDisplay }}</span>
                </div>

                <div class="my-hero__progress">
                    <div
                        class="my-hero__progress-bar"
                        :style="{ width: creditScorePercent }"
                    ></div>
                </div>

                <div class="my-hero__stats">
                    <div class="my-stat">
                        <div class="my-stat__label">{{ $t('wallet_amount') }}</div>
                        <div class="my-stat__value">
                            <span>{{ walletBalance }}</span>
                            <em>USD</em>
                        </div>
                    </div>
                    <div class="my-stat my-stat--divider">
                        <div class="my-stat__label">{{ $t('todays_commission') }}</div>
                        <div class="my-stat__value">
                            <span>{{ rebateAmount }}</span>
                            <em>USD</em>
                        </div>
                    </div>
                </div>
            </section>

            <section class="my-menu-card">
                <div
                    v-for="item in menuItems"
                    :key="item.title"
                    class="my-menu-row"
                    @click="item.action"
                >
                    <div class="my-menu-row__icon">
                        <img :src="item.icon" alt="" />
                    </div>
                    <div class="my-menu-row__content">
                        <div class="my-menu-row__title">{{ item.title }}</div>
                        <div class="my-menu-row__desc">{{ item.desc }}</div>
                    </div>
                </div>
            </section>

            <button class="my-logout" type="button" @click="logout">
                <img :src="myIcons.logout" alt="" />
                <span>{{ $t('log_out') }}</span>
            </button>
        </main>

        <ContactUs ref="ContactUsRef"></ContactUs>
        <tradePassword ref="tradePasswordRef"></tradePassword>
        <Lang ref="langRef"></Lang>

        <van-popup
            v-if="!isPc"
            v-model:show="showLogoutPopup"
            position="bottom"
            class="logout-sheet logout-sheet--mobile"
            overlay-class="logout-sheet-overlay logout-sheet-overlay--mobile"
            transition="logout-sheet-slide"
            round
        >
            <div class="logout-sheet__icon">
                <img :src="myIcons.logout" alt="" />
            </div>
            <div class="logout-sheet__title">{{ $t('log_out') }}</div>
            <div class="logout-sheet__desc">
                {{ $t('logout_confirm_desc_1') }}<br />
                {{ $t('logout_confirm_desc_2') }}
            </div>
            <button
                class="logout-sheet__confirm"
                type="button"
                @click="confirmLogout"
            >
                <img :src="myIcons.logout" alt="" />
                {{ $t('confirm_log_out') }}
            </button>
            <button
                class="logout-sheet__cancel"
                type="button"
                @click="showLogoutPopup = false"
            >
                {{ $t('cancel') }}
            </button>
        </van-popup>

        <transition name="logout-desktop-fade">
            <div
                v-if="isPc && showLogoutPopup"
                class="logout-desktop-layer"
                @click.self="showLogoutPopup = false"
            >
                <div class="logout-desktop-card">
                    <div class="logout-sheet__icon">
                        <img :src="myIcons.logout" alt="" />
                    </div>
                    <div class="logout-sheet__title">{{ $t('log_out') }}</div>
                    <div class="logout-sheet__desc">
                        {{ $t('logout_confirm_desc_1') }}<br />
                        {{ $t('logout_confirm_desc_2') }}
                    </div>
                    <button
                        class="logout-sheet__confirm"
                        type="button"
                        @click="confirmLogout"
                    >
                        <img :src="myIcons.logout" alt="" />
                        {{ $t('confirm_log_out') }}
                    </button>
                    <button
                        class="logout-sheet__cancel"
                        type="button"
                        @click="showLogoutPopup = false"
                    >
                        {{ $t('cancel') }}
                    </button>
                </div>
            </div>
        </transition>
    </div>
</template>

<script setup>
import {
    computed,
    onActivated,
    onDeactivated,
    onMounted,
    onUnmounted,
    ref,
} from 'vue';
import { useRouter } from 'vue-router';
import { useI18n } from 'vue-i18n';
import { showToast } from '@/util/message';

import ContactUs from '@/components/ContactUs.vue';
import Lang from '@/components/Lang.vue';
import tradePassword from '@/components/tradePassword.vue';
import { checkWorkTimeLocal, copyContent } from '@/util/utils';
import { getTradeConfig } from '@/api/apis';
import { useUserStore } from '@/store/modules/user';

const router = useRouter();
const userStore = useUserStore();
const { t } = useI18n();

const defaultAvatar = new URL(
    '@/static/images/my-design/my-default-avatar.png',
    import.meta.url,
).href;

const langRef = ref(null);
const ContactUsRef = ref(null);
const tradePasswordRef = ref(null);
const userInfo = ref({});
const userLevel = ref('');
const TradeInfor = ref({});
const showLogoutPopup = ref(false);
const isPc = ref(false);

const myIcons = {
    edit: new URL('@/static/images/my-design/my-edit-icon.png', import.meta.url)
        .href,
    copy: new URL('@/static/images/my-design/my-copy-icon.png', import.meta.url)
        .href,
    profile: new URL(
        '@/static/images/my-design/my-menu-profile.png',
        import.meta.url,
    ).href,
    wallet: new URL(
        '@/static/images/my-design/my-menu-payment.png',
        import.meta.url,
    ).href,
    message: new URL(
        '@/static/images/my-design/my-menu-message.png',
        import.meta.url,
    ).href,
    card: new URL('@/static/images/my-design/my-menu-link.png', import.meta.url)
        .href,
    service: new URL(
        '@/static/images/my-design/my-menu-service.png',
        import.meta.url,
    ).href,
    logout: new URL(
        '@/static/images/my-design/my-logout-icon.png',
        import.meta.url,
    ).href,
    level: new URL('@/static/images/my-design/my-vip-badge.png', import.meta.url)
        .href,
};

const walletBalance = computed(() => {
    const value =
        userInfo.value.totalBalance ??
        Number(userInfo.value?.balance || 0) +
            Number(
                userInfo.value?.frozenBalance ?? userInfo.value?.freezeAmount ?? 0,
            );
    return Number(value || 0).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
});

const rebateAmount = computed(() =>
    Number(userInfo.value?.commission || 0).toLocaleString('en-US', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }),
);

const creditScore = computed(() => {
    const rawScore = Number(userInfo.value?.creditScore ?? 100);
    if (!Number.isFinite(rawScore)) return 100;
    return Math.min(100, Math.max(0, rawScore));
});

const creditScoreDisplay = computed(() => `${Math.round(creditScore.value)}%`);
const creditScorePercent = computed(() => `${creditScore.value}%`);

const displayVipLevel = computed(() => {
    const raw = `${userLevel.value || userInfo.value?.userLevel?.nameEn || 'VIP1'}`
        .trim()
        .replace(/\s+/g, ' ');
    const matched = raw.match(/^VIP\s*(\d+)$/i);
    if (matched) return `VIP ${matched[1]}`;
    return raw || 'VIP 1';
});

const menuItems = computed(() => [
    {
        title: t('personal_profile'),
        desc: t('manage_basic_information'),
        icon: myIcons.profile,
        action: () => toPage('/profileItem'),
    },
    {
        title: t('payment_methods'),
        desc: t('configure_recharge_withdrawal'),
        icon: myIcons.wallet,
        action: () => toPage('/paymentMethods'),
    },
    {
        title: t('message_center'),
        desc: t('system_notifications_announcements'),
        icon: myIcons.message,
        action: () => toPage('/notice'),
    },
    {
        title: t('link_your_bank_card'),
        desc: t('bind_bank_card_for_withdrawals'),
        icon: myIcons.card,
        action: () => router.push({ path: '/cardList', query: { type: 1 } }),
    },
    {
        title: t('contact_customer_service'),
        desc: t('get_help_resolve_issues'),
        icon: myIcons.service,
        action: customer,
    },
]);

function toPage(path) {
    router.push({ path });
}

function customer() {
    const time = checkWorkTimeLocal(
        TradeInfor.value.workTimeStart,
        TradeInfor.value.workTimeEnd,
        userStore.zoneActive.tzName,
    );

    if (time) {
        ContactUsRef.value.open();
        return;
    }

    showToast(
        t('supportHours', {
            start: TradeInfor.value.workTimeStart,
            end: TradeInfor.value.workTimeEnd,
        }),
    );
}

function logout() {
    showLogoutPopup.value = true;
}

function confirmLogout() {
    showLogoutPopup.value = false;
    userStore.logout();
}

function updateDeviceMode() {
    isPc.value = window.matchMedia('(min-width: 768px)').matches;
}

function updateHandler() {
    getUserGetInfo({ force: true });
}

function syncUserInfo(info = {}) {
    userInfo.value = info || {};
    userLevel.value = info?.userLevel?.nameEn || '';
}

async function getUserGetInfo(options = {}) {
    const info = await userStore.getUserInfo(options);
    syncUserInfo(info);
    return info;
}

async function tradeConfig() {
    const res = await getTradeConfig();
    TradeInfor.value = res.data || {};
}

onMounted(() => {
    window.addEventListener('updateTrade', updateHandler);
    window.addEventListener('resize', updateDeviceMode);
    updateDeviceMode();
    getUserGetInfo();
    tradeConfig();
});

onActivated(() => {
    window.addEventListener('updateTrade', updateHandler);
});

onUnmounted(() => {
    window.removeEventListener('updateTrade', updateHandler);
    window.removeEventListener('resize', updateDeviceMode);
});

onDeactivated(() => {
    window.removeEventListener('updateTrade', updateHandler);
});
</script>

<style scoped>
.my-page {
    min-height: 100vh;
    padding-bottom: 118px;
    background: #eef0f5;
    color: #111111;
    font-family: 'Montserrat', 'Poppins', sans-serif;
}

.my-page__main {
    padding: 118px 15px 16px;
}

.my-hero {
    position: relative;
    min-height: 365px;
    padding: 22px 24px 24px;
    border-radius: 16px;
    background: #3545e8 url('@/static/images/my-design/my-hero-bg.png') center /
        cover no-repeat;
    color: #ffffff;
    overflow: hidden;
}

.my-hero__badge {
    position: absolute;
    top: 20px;
    right: 24px;
    text-align: center;
}

.my-hero__badge img {
    width: 44px;
    height: 44px;
    display: block;
    object-fit: contain;
    margin: 0 auto;
}

.my-hero__badge span {
    display: block;
    margin-top: 6px;
    font-size: 12px;
    line-height: 1;
    font-weight: 500;
}

.my-hero__avatar-wrap {
    position: relative;
    width: 110px;
    margin: 18px auto 0;
}

.my-hero__avatar-shell {
    width: 110px;
    height: 110px;
    border-radius: 50%;
    overflow: hidden;
}

.my-hero__avatar,
.my-hero__avatar-loading {
    width: 100%;
    height: 100%;
    display: block;
    object-fit: cover;
    border-radius: 50%;
}

.my-hero__avatar-loading {
    background: rgba(255, 255, 255, 0.2);
    animation: pulse 1.6s ease-in-out infinite;
}

@keyframes pulse {
    0%,
    100% {
        opacity: 0.45;
    }
    50% {
        opacity: 0.8;
    }
}

.my-hero__edit {
    position: absolute;
    right: -4px;
    bottom: 2px;
    width: 40px;
    height: 40px;
    padding: 0;
    border: 0;
    background: transparent;
}

.my-hero__edit img {
    width: 100%;
    height: 100%;
    display: block;
}

.my-hero__name {
    margin-top: 18px;
    text-align: center;
    font-size: 30px;
    line-height: 1.08;
    font-weight: 600;
    letter-spacing: 0.01em;
}

.my-hero__row {
    display: flex;
    align-items: center;
}

.my-hero__row--referral {
    justify-content: center;
    gap: 10px;
    margin-top: 28px;
}

.my-hero__label {
    font-size: 16px;
    line-height: 1.2;
    font-weight: 500;
}

.my-hero__code {
    min-width: 114px;
    height: 42px;
    padding: 0 16px;
    border: 0;
    border-radius: 8px;
    background: #34ca5d;
    color: #ffffff;
    font-size: 18px;
    line-height: 1;
    font-weight: 700;
}

.my-hero__copy-btn {
    width: 28px;
    height: 28px;
    padding: 0;
    border: 0;
    background: transparent;
}

.my-hero__copy-btn img {
    width: 100%;
    height: 100%;
    display: block;
}

.my-hero__row--score {
    justify-content: space-between;
    margin-top: 28px;
}

.my-hero__score-value {
    font-size: 17px;
    line-height: 1;
    font-weight: 600;
}

.my-hero__progress {
    margin-top: 16px;
    height: 12px;
    border-radius: 999px;
    background: #edf1fb;
    overflow: hidden;
}

.my-hero__progress-bar {
    height: 100%;
    border-radius: inherit;
    background: #39c95a;
}

.my-hero__stats {
    display: grid;
    grid-template-columns: 1fr 1fr;
    margin-top: 30px;
}

.my-stat {
    padding: 0 12px;
    text-align: center;
}

.my-stat--divider {
    border-left: 4px dashed rgba(255, 255, 255, 0.18);
}

.my-stat__label {
    color: rgba(255, 255, 255, 0.88);
    font-size: 14px;
    line-height: 1.25;
    font-weight: 500;
}

.my-stat__value {
    display: flex;
    align-items: baseline;
    justify-content: center;
    gap: 10px;
    margin-top: 18px;
}

.my-stat__value span {
    font-size: 27px;
    line-height: 1;
    font-weight: 600;
    letter-spacing: 0.01em;
}

.my-stat__value em {
    font-style: normal;
    font-size: 16px;
    line-height: 1;
    font-weight: 600;
    letter-spacing: 0.03em;
}

.my-menu-card {
    margin-top: 16px;
    background: #ffffff;
    border-radius: 18px;
    overflow: hidden;
}

.my-menu-row {
    display: flex;
    align-items: center;
    min-height: 118px;
    padding: 0 18px;
    border-bottom: 1px solid #edf0f5;
    box-sizing: border-box;
}

.my-menu-row:last-child {
    border-bottom: 0;
}

.my-menu-row__icon {
    flex: 0 0 58px;
    width: 58px;
    height: 58px;
    margin-right: 18px;
}

.my-menu-row__icon img {
    width: 100%;
    height: 100%;
    display: block;
    object-fit: contain;
}

.my-menu-row__content {
    min-width: 0;
}

.my-menu-row__title {
    color: #111111;
    font-size: 18px;
    line-height: 1.2;
    font-weight: 500;
}

.my-menu-row__desc {
    margin-top: 10px;
    color: #7a8190;
    font-size: 13px;
    line-height: 1.2;
    white-space: pre-line;
}

.my-logout {
    width: 100%;
    height: 70px;
    margin-top: 16px;
    border: 0;
    border-radius: 18px;
    background: #f8edee;
    color: #f1574f;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    font-size: 18px;
    line-height: 1;
    font-weight: 600;
}

.my-logout img {
    width: 20px;
    height: 20px;
}

.logout-sheet {
    width: 100%;
    max-width: var(--app-pc-max-width, 375px);
    left: 50% !important;
    transform: translateX(-50%) !important;
    border-radius: 20px 20px 0 0;
    padding: 39px 22px calc(36px + env(safe-area-inset-bottom, 0px));
    background: #ffffff;
    box-sizing: border-box;
}

.logout-sheet--mobile {
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    width: 100vw !important;
    max-width: 100vw !important;
    min-width: 100vw !important;
    transform: none !important;
}

:global(.logout-sheet-overlay) {
    background: rgba(0, 0, 0, 0.42);
    backdrop-filter: blur(4px);
}

:global(.logout-sheet-overlay--mobile) {
    left: 0 !important;
    right: 0 !important;
    top: 0 !important;
    bottom: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    height: 100dvh !important;
}

:global(.logout-sheet-slide-enter-active),
:global(.logout-sheet-slide-leave-active) {
    transition:
        transform 0.24s cubic-bezier(0.22, 1, 0.36, 1),
        opacity 0.24s ease;
}

:global(.logout-sheet-slide-enter-from),
:global(.logout-sheet-slide-leave-to) {
    opacity: 0;
    transform: translate3d(0, 100%, 0) !important;
}

:global(.logout-sheet-slide-enter-to),
:global(.logout-sheet-slide-leave-from) {
    opacity: 1;
    transform: translate3d(0, 0, 0) !important;
}

.logout-sheet__icon {
    width: 78px;
    height: 78px;
    margin: 0 auto;
    border-radius: 50%;
    border: 1px dashed #ffb0aa;
    background: #fff4f2;
    display: flex;
    align-items: center;
    justify-content: center;
}

.logout-sheet__icon img {
    width: 26px;
    height: 26px;
}

.logout-sheet__title {
    margin-top: 18px;
    text-align: center;
    color: #101522;
    font-size: 20px;
    line-height: 26px;
    font-weight: 700;
}

.logout-sheet__desc {
    margin-top: 16px;
    text-align: center;
    color: #62806b;
    font-size: 13px;
    line-height: 22px;
}

.logout-sheet__confirm,
.logout-sheet__cancel {
    width: 100%;
    height: 59px;
    border-radius: 12px;
    font-size: 17px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
}

.logout-sheet__confirm {
    margin-top: 26px;
    background: var(--theme-primary);
    color: #ffffff;
}

.logout-sheet__confirm img {
    width: 22px;
    height: 22px;
    margin-right: 10px;
    filter: brightness(0) invert(1);
}

.logout-sheet__cancel {
    margin-top: 18px;
    color: #d37703;
    border: 1px solid rgba(211, 119, 3, 1);
    border-radius: 14px;
    background: rgba(211, 119, 3, 0.12);
}

.logout-desktop-layer {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 50%;
    z-index: 3000;
    width: var(--app-pc-max-width, 375px);
    transform: translateX(-50%);
    background: rgba(0, 0, 0, 0.42);
    backdrop-filter: blur(4px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 16px;
    box-sizing: border-box;
}

.logout-desktop-card {
    width: 100%;
    max-width: calc(var(--app-pc-max-width, 375px) - 32px);
    border-radius: 18px;
    background: #ffffff;
    padding: 34px 22px 28px;
    box-sizing: border-box;
}

.logout-desktop-fade-enter-active,
.logout-desktop-fade-leave-active {
    transition: opacity 0.22s ease;
}

.logout-desktop-fade-enter-active .logout-desktop-card,
.logout-desktop-fade-leave-active .logout-desktop-card {
    transition:
        transform 0.24s cubic-bezier(0.22, 1, 0.36, 1),
        opacity 0.22s ease;
}

.logout-desktop-fade-enter-from,
.logout-desktop-fade-leave-to {
    opacity: 0;
}

.logout-desktop-fade-enter-from .logout-desktop-card,
.logout-desktop-fade-leave-to .logout-desktop-card {
    opacity: 0;
    transform: translateY(14px) scale(0.96);
}
</style>
