// api.js
import axios from "axios";
import { ElLoading } from "element-plus";
import { showToast } from "@/util/message";
import pinia from "@/store/index.js";
import { useUserStore } from "@/store/modules/user";
import { useCommonStore } from "@/store/modules/common";
import router from "@/router/index.js";
import { errorMessages } from "./errorCodeMap";
import i18n from "../i18n/index.js"; // 引入全局 i18n 实例

let api = null; // 延迟创建 axios 实例
let loading = null;
let isHandlingUnauthorized = false;

const requestLoadingSvg = `
<defs>
  <linearGradient id="appWaveLoadingGradient" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0%" stop-color="#18d6ff"/>
    <stop offset="50%" stop-color="#2f7bff"/>
    <stop offset="100%" stop-color="#3543ec"/>
  </linearGradient>
</defs>
<rect x="8" y="16" width="6" height="12" rx="3" fill="url(#appWaveLoadingGradient)">
  <animate attributeName="height" values="12;32;12" dur="0.9s" begin="-0.36s" repeatCount="indefinite"/>
  <animate attributeName="y" values="16;6;16" dur="0.9s" begin="-0.36s" repeatCount="indefinite"/>
</rect>
<rect x="20" y="12" width="6" height="20" rx="3" fill="url(#appWaveLoadingGradient)">
  <animate attributeName="height" values="16;36;16" dur="0.9s" begin="-0.18s" repeatCount="indefinite"/>
  <animate attributeName="y" values="14;4;14" dur="0.9s" begin="-0.18s" repeatCount="indefinite"/>
</rect>
<rect x="32" y="8" width="6" height="28" rx="3" fill="url(#appWaveLoadingGradient)">
  <animate attributeName="height" values="18;38;18" dur="0.9s" begin="0s" repeatCount="indefinite"/>
  <animate attributeName="y" values="13;3;13" dur="0.9s" begin="0s" repeatCount="indefinite"/>
</rect>
<rect x="44" y="12" width="6" height="20" rx="3" fill="url(#appWaveLoadingGradient)">
  <animate attributeName="height" values="16;36;16" dur="0.9s" begin="0.18s" repeatCount="indefinite"/>
  <animate attributeName="y" values="14;4;14" dur="0.9s" begin="0.18s" repeatCount="indefinite"/>
</rect>
<rect x="56" y="16" width="6" height="12" rx="3" fill="url(#appWaveLoadingGradient)">
  <animate attributeName="height" values="12;32;12" dur="0.9s" begin="0.36s" repeatCount="indefinite"/>
  <animate attributeName="y" values="16;6;16" dur="0.9s" begin="0.36s" repeatCount="indefinite"/>
</rect>`;


// 获取 BASEURL，确保 window.g 已加载
export function getBaseURL() {
  return window.g?.VITE_API_BASE_URL || import.meta.env.VITE_API_BASE_URL;
}

function closeRequestLoading(config = {}) {
  if (config.loading === true && loading) {
    loading.close();
    loading = null;
  }
}

function getResponseCode(data) {
  return data?.code ?? data?.status ?? data?.statusCode;
}

function isUnauthorizedResponse(data, status) {
  return Number(status) === 401 || Number(getResponseCode(data)) === 401;
}

function getResponseMessage(data, fallback = "") {
  return data?.message || data?.msg || fallback;
}

function getTranslatedMessage(data, fallback = "") {
  const code = getResponseCode(data);
  const key = errorMessages[code];
  return (key && i18n.global.t(key)) || getResponseMessage(data, fallback);
}

function clearLoginState() {
  const userStore = useUserStore(pinia);
  userStore.token = "";
  userStore.userInfo = {};
  userStore.allWallet = [];
  userStore.userWallerType = {};
}

function handleUnauthorized() {
  clearLoginState();

  if (isHandlingUnauthorized) return;
  isHandlingUnauthorized = true;

  Promise.resolve()
    .then(() => {
      if (router.currentRoute.value.path === "/account/login") return;
      return router.replace({ path: "/account/login" }).catch(() => {});
    })
    .finally(() => {
      isHandlingUnauthorized = false;
    });
}

// 初始化 axios 实例（在 main.js 等待 config.js 加载后调用）
export function initAPI() {
  if (!api) {
    api = axios.create({
      baseURL: getBaseURL(),
      timeout: 20000,
    });

    // 请求拦截器
    api.interceptors.request.use(
      (config) => {
        if (config.loading === true) {
          if (loading) {
            loading.close();
            loading = null;
          }
          loading = ElLoading.service({
            fullscreen: true,
            background: "#ffffff",
            customClass: "app-wave-loading-mask",
            svg: requestLoadingSvg,
            svgViewBox: "0 0 64 44",
          });
        }

        const userStore = useUserStore(pinia);
        const commonStore = useCommonStore(pinia);

        config.headers = {
          ...config.headers,
          authorization: userStore.token || "",
          lang: commonStore.clientLang,
        };

        // 添加请求参数
        if (config.method === "get") {
          config.params = {
            ...config.params,
          };
        } else {
          config.data = {
            ...config.data,
          };
        }

        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // 响应拦截器
    api.interceptors.response.use(
      (response) => {
        const config = response.config || {};
        closeRequestLoading(config);

        const result = response.data;
        const status = response.status;

        if (isUnauthorizedResponse(result, status)) {
          handleUnauthorized();
          return Promise.reject(result || response);
        }

        if (status >= 200 && status < 300) {
          const code = getResponseCode(result);
          if (Number(code) === 200 || Number(code) === 201) {
            return result;
          }

          if (config.showMsg) showToast(getTranslatedMessage(result));
          return Promise.reject(result);
        }

        if (config.showMsg) showToast(status);
        return Promise.reject(response);
      },
      (error) => {
        const config = error.config || {};
        closeRequestLoading(config);

        const response = error.response || {};
        const result = response.data || error.data;
        const status = response.status ?? error.status;

        if (isUnauthorizedResponse(result, status)) {
          handleUnauthorized();
          return Promise.reject(result || error);
        }

        if (config.showMsg) showToast(getResponseMessage(result, error.message));
        return Promise.reject(result || error);
      }
    );
  }

  return api;
}

// 调试 window.g
export function debugConfig() {
  console.log("window.g:", window.g);
}

export default api; // 注意：在 main.js 调用 initAPI() 后再使用 api
